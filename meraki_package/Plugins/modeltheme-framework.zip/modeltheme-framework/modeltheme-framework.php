<?php
/**
* Plugin Name: ModelTheme Framework
* Plugin URI: http://modeltheme.com/
* Description: ModelTheme Framework required by MODELTHEME Theme.
* Version: 1.2.1
* Author: ModelTheme
* Author http://modeltheme.com/
* Text Domain: modeltheme
*/


$plugin_dir = plugin_dir_path( __FILE__ );








/**

||-> Function: Dynamic Featured Image for 'portfolio' CPT only

*/
function modeltheme_allowed_post_types() {
    return array('portfolio', 'mt_house'); //show DFI only in post
}
add_filter('dfi_post_types', 'modeltheme_allowed_post_types');





/**
||-> Function: ModelTheme Feed
*/
add_action('wp_dashboard_setup', 'modeltheme_dashboard_widgets');
function modeltheme_dashboard_widgets() {
    global $wp_meta_boxes;
    wp_add_dashboard_widget('modeltheme_posts_feed', 'ModelTheme Feed', 'modeltheme_custom_dashboard_help');
}

function modeltheme_custom_dashboard_help() {
    echo '<div class="rss-widget">';
        wp_widget_rss_output(array(
             'url'          => 'http://modeltheme.com/feed/',
             'title'        => 'MODELTHEME_FEED',
             'items'        => 5,
             'show_summary' => 1,
             'show_author'  => 0,
             'show_date'    => 1
        ));
    echo '</div>';
}





/**
||-> Function: require_once() plugin necessary parts
*/
require_once('inc/post-types/post-types.php'); // POST TYPES
require_once('inc/shortcodes/shortcodes.php'); // SHORTCODES
require_once('inc/widgets/widgets.php'); // WIDGETS
require_once('inc/widgets/widgets-theme.php'); // WIDGETS
require_once('inc/metaboxes/metaboxes.php'); // METABOXES
require_once('inc/demo-importer-v2/wbc907-plugin-example.php');
if ( ! class_exists( 'Dynamic_Featured_Image' ) ){
    require_once('inc/dynamic-featured-image/dynamic-featured-image.php'); // DYNAMIC FEATURED IMAGE
}
require_once('inc/mega-menu/modeltheme-mega-menu.php'); // MEGA MENU
require_once('inc/sb-google-maps-vc-addon/sb-google-maps-vc-addon.php'); // GMAPS
require_once('inc/custom-functions.php'); // CUSTOM FUNCTIONS
require "inc/demo-importer-v2/extensions/mt_activator/MTA_API.php"; // CUSTOM FUNCTIONS




/**

||-> Function: LOAD PLUGIN TEXTDOMAIN

*/
function modeltheme_load_textdomain(){
    $domain = 'modeltheme';
    $locale = apply_filters( 'plugin_locale', get_locale(), $domain );

    load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
    load_plugin_textdomain( $domain, FALSE, basename( plugin_dir_path( dirname( __FILE__ ) ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'modeltheme_load_textdomain' );




/**

||-> Function: modeltheme_framework()

*/
function modeltheme_framework() {
    // CSS
    wp_register_style( 'style-shortcodes-inc',  plugin_dir_url( __FILE__ ) . 'inc/shortcodes/shortcodes.css' );
    wp_enqueue_style( 'style-shortcodes-inc' );
    wp_register_style( 'style-mt-mega-menu',  plugin_dir_url( __FILE__ ) . 'css/mt-mega-menu.css' );
    wp_enqueue_style( 'style-mt-mega-menu' );
    wp_register_style( 'style-select2',  plugin_dir_url( __FILE__ ) . 'css/select2.min.css' );
    wp_enqueue_style( 'style-select2' );
    wp_register_style( 'style-animations',  plugin_dir_url( __FILE__ ) . 'css/animations.css' );
    wp_enqueue_style( 'style-animations' );
    
    // SCRIPTS
    wp_enqueue_script( 'classie', plugin_dir_url( __FILE__ ) . 'js/classie.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'js-mt-plugins', plugin_dir_url( __FILE__ ) . 'js/mt-plugins.js', array(), '1.0.0', true );
    wp_enqueue_script( 'select2', plugin_dir_url( __FILE__ ) . 'js/select2.min.js', array(), '1.0.0', true );

    // wp_enqueue_script( 'decorative-particles-app', plugin_dir_url( __FILE__ ) . 'js/mt-decorative-particles/app.js', array(), '1.0.0', true );
    // wp_enqueue_script( 'three', plugin_dir_url( __FILE__ ) . 'js/mt-decorative-particles/three.min.js', array(), '2.0.0', true );
    // wp_enqueue_script( 'TweenMax', plugin_dir_url( __FILE__ ) . 'js/mt-decorative-particles/TweenMax.min.js', array(), '1.0.0', true );
    // wp_enqueue_script( 'decorative-particles-app-demo2', plugin_dir_url( __FILE__ ) . 'js/mt-decorative-particles/demo2.js', array(), '1.0.0', true );

    wp_enqueue_script( 'js-modeltheme-custom', plugin_dir_url( __FILE__ ) . 'js/modeltheme-custom.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'magnific-popup', plugin_dir_url( __FILE__ ) . 'js/mt-video/jquery.magnific-popup.js', array(), '1.0.0', true );
    wp_enqueue_script( 'js-modeltheme-mt-coundown-version2', plugin_dir_url( __FILE__ ) . 'js/mt-coundown-version2/flipclock.js', array('jquery'), '1.0.0', true );
    
}
add_action( 'wp_enqueue_scripts', 'modeltheme_framework' );




/**

||-> Function: modeltheme_enqueue_admin_scripts()

*/
function modeltheme_enqueue_admin_scripts( $hook ) {
    // JS
    wp_enqueue_script( 'js-modeltheme-admin-custom', plugin_dir_url( __FILE__ ) . 'js/modeltheme-custom-admin.js', array(), '1.0.0', true );
    // CSS
    wp_register_style( 'css-modeltheme-custom',  plugin_dir_url( __FILE__ ) . 'css/modeltheme-custom.css' );
    wp_enqueue_style( 'css-modeltheme-custom' );
    wp_register_style( 'css-fontawesome-icons',  plugin_dir_url( __FILE__ ) . 'css/font-awesome.min.css' );
    wp_enqueue_style( 'css-fontawesome-icons' );
    wp_register_style( 'css-simple-line-icons',  plugin_dir_url( __FILE__ ) . 'css/simple-line-icons.css' );
    wp_enqueue_style( 'css-simple-line-icons' );
    /*wp_register_style( 'cryptocoins-icons',  plugin_dir_url( __FILE__ ) . 'fonts/cryptocoins.css' );
    wp_enqueue_style( 'cryptocoins-icons' );*/

}
add_action('admin_enqueue_scripts', 'modeltheme_enqueue_admin_scripts');




    
    

add_image_size( 'mt_1250x700', 1250, 700, true );
add_image_size( 'mt_320x480', 320, 480, true );
add_image_size( 'mt_900x550', 900, 550, true );




/**

||-> Function: modeltheme_cmb_initialize_cmb_meta_boxes

*/
function modeltheme_cmb_initialize_cmb_meta_boxes() {
    if ( ! class_exists( 'cmb_Meta_Box' ) )
        require_once ('init.php');
}
add_action( 'init', 'modeltheme_cmb_initialize_cmb_meta_boxes', 9999 );



/**

||-> Function: modeltheme_cmb_initialize_cmb_meta_boxes

*/
function modeltheme_excerpt_limit($string, $word_limit) {
    $words = explode(' ', $string, ($word_limit + 1));
    if(count($words) > $word_limit) {
        array_pop($words);
    }
    return implode(' ', $words);
}

if ( class_exists( 'WooCommerce' ) ) {
	function wc_custom_lost_password_form( $atts ) {

	    return wc_get_template( 'myaccount/form-lost-password.php', array( 'form' => 'lost_password' ) );

	}
	add_shortcode( 'lost_password_form', 'wc_custom_lost_password_form' );
}





function meraki_login_register(){

    $html = '';

    if (!in_array('login-register-page', get_body_class())) {
        $html .= '<div class="modeltheme-modal" id="modal-log-in">
            <div class="modeltheme-content" id="login-modal-content">
                <h3 class="relative">'.esc_html__('Login to Your Account','modeltheme').'</h3>
                <div class="modal-content row">
                    <div class="col-md-12">
                        
                        <form name="loginform" id="loginform" action="'.wp_login_url().'" method="post">
            
                            <p class="login-username">
                                <label for="user_login">'.esc_html__('Username or Email Address','modeltheme').'</label>
                                <input type="text" name="log" id="user_login" class="input" value="" size="20" placeholder="'.esc_attr__('Username','modeltheme').'">
                            </p>
                            <p class="login-password">
                                <label for="user_pass">'.esc_html__('Password','modeltheme').'</label>
                                <input type="password" name="pwd" id="user_pass" class="input" value="" size="20" placeholder="'.esc_attr__('Password','modeltheme').'">
                            </p>
                            
                            <p class="login-remember">
                                <label>
                                    <input name="rememberme" type="checkbox" id="rememberme" value="forever">
                                    '.esc_html__('Remember Me','modeltheme').'
                                </label>
                            </p>
                            <div class="row-buttons">
                                    <p class="login-submit">
                                        <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="'.esc_attr__('Log In','modeltheme').'">
                                        <input type="hidden" name="redirect_to" value="'.get_site_url().'">
                                    </p>';
                                    if (  get_option('users_can_register')) {
                                        $html .= '<p class="btn-register-p">
                                            <a class="btn btn-register" id="register-modal">'.esc_html__('Register','modeltheme').'</a>
                                        </p>';
                                    } else {
                                        $html .= '<p class="um-notice err text-center">'.esc_html__('Registration is currently disabled','modeltheme').'</p>';
                                    }
                                    $html .= '<p class="woocommerce-LostPassword lost_password">
                                        <a href="'.esc_url(wp_lostpassword_url()).'">'.esc_html__('Lost your password?','modeltheme').'</a>
                                    </p>
                            </div>
                            
                        </form>';
                        
                        if (function_exists('yith_ywsl_constructor')) {
                            $html .= '<div class="separator-modal">'.esc_html__('OR','modeltheme').'</div>';
                            $html .= do_shortcode("[yith_wc_social_login]");
                        }
                        
                    $html .= '</div>
                </div>
            </div>
            <div class="modeltheme-content" id="signup-modal-content">
                <h3 class="relative">'.esc_html__('Personal Details','modeltheme').'</h3>
                <div class="modal-content row">
                    <div class="col-md-12">';
                        if ( class_exists( 'WooCommerce' ) ) {
                            if ( get_option( 'woocommerce_enable_myaccount_registration' ) === 'yes' ) {
                                $html .= '<div class="u-column2 col-2">
                                    <form method="post" class="woocommerce-form woocommerce-form-register register">';

                                    	$username = '';
                                        if (!empty($_POST['username'])){
                                        	$username = wp_unslash( $_POST['username'] );
                                        }
                                    	$firstname = '';
                                        if (!empty($_POST['billing_first_name'])){
                                        	$firstname = $_POST['billing_first_name'];
                                        }
                                    	$lastname = '';
                                        if (!empty($_POST['billing_last_name'])){
                                        	$lastname = $_POST['billing_last_name'];
                                        }
                                    	$email = '';
                                        if (!empty($_POST['email'])){
                                        	$email = wp_unslash( $_POST['email'] );
                                        }

                                        // do_action( 'woocommerce_register_form_start' );
                                        if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) {
                                            $html .= '<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="'.esc_attr($username).'" placeholder="'.esc_attr__( 'Username', 'modeltheme' ).'" />
                                            </p>';
                                        }
                                        $html .= '<p class="form-row form-row-first">
                                            <input type="text" class="input-text" name="billing_first_name" id="billing_first_name" value="'.esc_attr($firstname).'" placeholder="'.esc_attr__( 'First name', 'modeltheme' ).'" />
                                        </p>
                                        <p class="form-row form-row-last">
                                            <input type="text" class="input-text" name="billing_last_name" id="billing_last_name" value="'.esc_attr($lastname).'" placeholder="'.esc_attr__( 'Last name', 'modeltheme' ).'" />
                                        </p>
                                        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="'.esc_attr($email).'" placeholder="'.esc_attr__( 'Email address', 'modeltheme' ).'" />
                                        </p>'; 
                                        if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) {
                                            $html .= '<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" placeholder="'.esc_attr__( 'Password', 'modeltheme' ).'" />
                                            </p>';
                                        }
                                        // do_action( 'woocommerce_register_form' );
                                        $html .= '<p class="woocommerce-FormRow form-row">';
                                            $html .= wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' );
                                            $html .= '<button type="submit" class="woocommerce-Button button" name="register" value="'.esc_attr__( 'Register', 'modeltheme' ).'">'.esc_html__( 'Register', 'modeltheme' ).'</button>
                                        </p>';
                                        // do_action( 'woocommerce_register_form_end' );
                                    $html .= '</form>
                                    <div class="separator-modal">'.esc_html__('OR','modeltheme').'</div>';
                                    if (function_exists('yith_ywsl_constructor')) {
                                        $html .= do_shortcode("[yith_wc_social_login]");
                                    }
                                $html .= '</div>';
                            }
                        }    
                    $html .= '</div>
                </div>            
            </div>
        </div>';
    }

    return $html;
}









/**

||-> ... Custom functions here ...

*/









?>