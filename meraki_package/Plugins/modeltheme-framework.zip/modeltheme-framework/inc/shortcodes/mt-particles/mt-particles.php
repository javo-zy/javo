<?php
/**
||-> Shortcode: Video
*/

function modeltheme_animated_gradient_shortcode($params, $content) {

    extract( shortcode_atts( 
        array(
            'source_vimeo'              => '',
        ), $params ) );

    $html = '';


    $html .= '<div class="mt_animated_gradient_shortcode"></div>';

    
    return $html;
}

add_shortcode('mt_animated_gradient', 'modeltheme_animated_gradient_shortcode');


/**
||-> Map Shortcode in Visual Composer with: vc_map();
*/
if (function_exists('vc_map')) {
    vc_map( array(
     "name" => esc_attr__("MT - Animated Gradient", 'modeltheme'),
     "base" => "mt_animated_gradient",
     "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
     "icon" => "smartowl_shortcode",
     "params" => array(
        array(
          "group" => "Gradient Builder",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("1st Color", 'modeltheme'),
          "param_name" => "color1",
          "value" => "",
          "description" => ""
        ),
        array(
          "group" => "Gradient Builder",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("2nd Color", 'modeltheme'),
          "param_name" => "color2",
          "value" => "",
          "description" => ""
        ),
        array(
          "group" => "Gradient Builder",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("3rd Color", 'modeltheme'),
          "param_name" => "color3",
          "value" => "",
          "description" => ""
        ),
        array(
          "group" => "Gradient Builder",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("4th Color", 'modeltheme'),
          "param_name" => "color4",
          "value" => "",
          "description" => ""
        ),
      )));
}

?>