<?php
/**
* Plugin Name: ModelTheme listings Manager
* Plugin URI: http://modeltheme.com/
* Description: ModelTheme listings Manager required by the Theme.
* Version: 1.2.1
* Author: ModelTheme
* Author http://modeltheme.com/
* Text Domain: mtlisitings
*/
/**
||-> Function: LOAD PLUGIN TEXTDOMAIN
*/
function mtlisitings_load_textdomain(){
    $domain = 'mtlisitings';
    $locale = apply_filters( 'plugin_locale', get_locale(), $domain );
    load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
    load_plugin_textdomain( $domain, FALSE, basename( plugin_dir_path( dirname( __FILE__ ) ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'mtlisitings_load_textdomain' );
/**
||-> Function: Dynamic Featured Image for 'mt_listing' CPT only
*/
function mtlisitings_allowed_post_types() {
    return array('mt_listing', 'mt_event'); //show DFI only in post
}
add_filter('dfi_post_types', 'mtlisitings_allowed_post_types');
/**
||-> Function: mtlisitings_cmb_initialize_cmb_meta_boxes
*/
function mtlisitings_cmb_initialize_cmb_meta_boxes() {
    // CMB v1
    if ( ! class_exists( 'cmb_Meta_Box' ) ){
        require_once ('init.php');
    }
    // CMB v2
    if ( ! class_exists( 'CMB2_Bootstrap_2261' ) ){
        require_once ('inc/cmb2/init.php');
        require_once ('inc/cmb2/example-functions.php');
    }
}
add_action( 'init', 'mtlisitings_cmb_initialize_cmb_meta_boxes', 9999 );
         require_once ('inc/cmb2/init.php');
        // require_once ('inc/cmb2/example-functions.php');
/**
||-> Function: mtlisitings_excerpt_limit
*/
function mtlisitings_excerpt_limit($string, $word_limit) {
    $words = explode(' ', $string, ($word_limit + 1));
    if(count($words) > $word_limit) {
        array_pop($words);
    }
    return implode(' ', $words);
}
/**
||-> Function: require_once() plugin necessary parts
*/
require_once('inc/post-types/post-types.php'); // POST TYPES
require_once('inc/metaboxes/metaboxes.php'); // METABOXES
require_once('inc/metaboxes/metaboxes-taxonomy.php'); // METABOXES FOR TAX's
require_once('inc/frontend-media/frontend-media.php');
//require_once('inc/shortcodes/shortcodes.php'); // SHORTCODES
function mtlisings_shortcodes() {
    require_once('inc/shortcodes/shortcodes.php'); // SHORTCODES
}
add_action( 'init', 'mtlisings_shortcodes', 9999 );
if ( ! class_exists( 'Dynamic_Featured_Image' ) ){
	require_once('inc/dynamic-featured-image/dynamic-featured-image.php'); // DYNAMIC FEATURED IMAGE
}
require_once('inc/redux-options/redux.listings.config.php'); // SHORTCODES

require_once('inc/thumbs-rating/thumbs-rating.php'); // ICO FRONTEND SUBMISSION FORM
/**
||-> Function: mtlisitings_taxonomy_template_from_directory()
*/
function mtlisitings_taxonomy_template_from_directory($template){
    // is a specific custom taxonomy being shown?
    $taxonomy_array = array('mt-listing-category', 'mt-listing-category2', 'mt-listing-type', 'mt-listing-tags');
    foreach ($taxonomy_array as $taxonomy_single) {
        if ( is_tax($taxonomy_single) ) {
            if(file_exists(trailingslashit(plugin_dir_path( __FILE__ ) . 'inc/templates/taxonomy-listing-archive.php'))) {
                $template = trailingslashit(plugin_dir_path( __FILE__ ) . 'inc/templates/taxonomy-listing-archive.php');
            }else {
                $template = plugin_dir_path( __FILE__ ) . 'inc/templates/taxonomy-listing-archive.php';
            }
            break;
        }
    }
    return $template;
}
add_filter('template_include','mtlisitings_taxonomy_template_from_directory');
/* Filter the single_template with our custom function*/
function mtlisitings_listing_single_template($single) {
    global $wp_query, $post;
    /* Checks for single template by post type */
    if ( $post->post_type == 'mt_listing' ) {
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'inc/templates/single/single-listing.php' ) ) {
            return plugin_dir_path( __FILE__ ) . 'inc/templates/single/single-listing.php';
        }
    }
    return $single;
}
add_filter('single_template', 'mtlisitings_listing_single_template');
/**
||-> CHECK IF PLUGIN ACTIVE OR NOT
*/
function mtlisitings_plugin_active( $plugin ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    if ( is_plugin_active( $plugin ) ) {
        return true;
    }
    return false;
}
function mtlisitings_custom_excerpt_length( $length ) {
    return 26;
}
add_filter( 'excerpt_length', 'mtlisitings_custom_excerpt_length', 999 );

/**
||-> Function: mtlisitings_framework()
*/
function mtlisitings_framework() {
    // CSS
    wp_register_style( 'slick-style',  plugin_dir_url( __FILE__ ) . 'css/slick.css' );
    wp_enqueue_style( 'slick-style' );
    wp_register_style( 'mtlisitings-style',  plugin_dir_url( __FILE__ ) . 'inc/shortcodes/shortcodes.css' );
    wp_enqueue_style( 'mtlisitings-style' );
    wp_register_style( 'mtlisitings-frontend',  plugin_dir_url( __FILE__ ) . 'css/mtlisitings-frontend.css' );
    wp_enqueue_style( 'mtlisitings-frontend' );
    // SCRIPTS
    wp_enqueue_script( 'slick-js', plugin_dir_url( __FILE__ ) . 'js/slick.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'jquery-validation', plugin_dir_url( __FILE__ ) . 'js/jquery.validation.js', array(), '1.0.0', true );
    wp_enqueue_script( 'select2', plugin_dir_url( __FILE__ ) . 'js/select2.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'mtlisitings-custom', plugin_dir_url( __FILE__ ) . 'js/mtlisitings-custom.js', array('jquery'), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'mtlisitings_framework' );
if (!class_exists('MTListing_Page_Templates')) {
    class MTListing_Page_Templates {
        /**
         * A reference to an instance of this class.
         */
        private static $instance;
        /**
         * The array of templates that this plugin tracks.
         */
        protected $templates;
        /**
         * Returns an instance of this class. 
         */
        public static function get_instance() {
            if ( null == self::$instance ) {
                self::$instance = new MTListing_Page_Templates();
            } 
            return self::$instance;
        } 
        /**
         * Initializes the plugin by setting filters and administration functions.
         */
        private function __construct() {
            $this->templates = array();
            // Add a filter to the attributes metabox to inject template into the cache.
            if ( version_compare( floatval( get_bloginfo( 'version' ) ), '4.7', '<' ) ) {
                // 4.6 and older
                add_filter(
                    'page_attributes_dropdown_pages_args',
                    array( $this, 'register_project_templates' )
                );
            } else {
                // Add a filter to the wp 4.7 version attributes metabox
                add_filter(
                    'theme_page_templates', array( $this, 'add_new_template' )
                );
            }
            // Add a filter to the save post to inject out template into the page cache
            add_filter(
                'wp_insert_post_data', 
                array( $this, 'register_project_templates' ) 
            );
            // Add a filter to the template include to determine if the page has our 
            // template assigned and return it's path
            add_filter(
                'template_include', 
                array( $this, 'view_project_template') 
            );
            // Add your templates to this array.
            $this->templates = array(
                'inc/templates/template-listings.php' => 'listings List',
                'inc/templates/template-add-edit-listing.php' => 'Add/Edit listing',    
            );
                
        } 
        /**
         * Adds our template to the page dropdown for v4.7+
         *
         */
        public function add_new_template( $posts_templates ) {
            $posts_templates = array_merge( $posts_templates, $this->templates );
            return $posts_templates;
        }
        /**
         * Adds our template to the pages cache in order to trick WordPress
         * into thinking the template file exists where it doens't really exist.
         */
        public function register_project_templates( $atts ) {
            // Create the key used for the themes cache
            $cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );
            // Retrieve the cache list. 
            // If it doesn't exist, or it's empty prepare an array
            $templates = wp_get_theme()->get_page_templates();
            if ( empty( $templates ) ) {
                $templates = array();
            } 
            // New cache, therefore remove the old one
            wp_cache_delete( $cache_key , 'themes');
            // Now add our template to the list of templates by merging our templates
            // with the existing templates array from the cache.
            $templates = array_merge( $templates, $this->templates );
            // Add the modified cache to allow WordPress to pick it up for listing
            // available templates
            wp_cache_add( $cache_key, $templates, 'themes', 1800 );
            return $atts;
        } 
        /**
         * Checks if the template is assigned to the page
         */
        public function view_project_template( $template ) {
            
            // Get global post
            global $post;
            // Return template if post is empty
            if ( ! $post ) {
                return $template;
            }
            // Return default template if we don't have a custom one defined
            if ( ! isset( $this->templates[get_post_meta( 
                $post->ID, '_wp_page_template', true 
            )] ) ) {
                return $template;
            } 
            $file = plugin_dir_path( __FILE__ ). get_post_meta( 
                $post->ID, '_wp_page_template', true
            );
            // Just to be safe, we check if the file exist first
            if ( file_exists( $file ) ) {
                return $file;
            } else {
                echo $file;
            }
            // Return template
            return $template;
        }
    } 
    add_action( 'plugins_loaded', array( 'MTlisting_Page_Templates', 'get_instance' ) );
}
/**
||-> Function: mtlisitings_enqueue_admin_scripts()
*/
function mtlisitings_enqueue_admin_scripts( $hook ) {
    // CSS
    wp_register_style( 'mtlisitings-admin-scripts',  plugin_dir_url( __FILE__ ) . 'css/mtlisitings-custom-admin.css' );
    wp_enqueue_style( 'mtlisitings-admin-scripts' );
}
add_action('admin_enqueue_scripts', 'mtlisitings_enqueue_admin_scripts');


function mtlisitings_convertYoutube($string) {
  return preg_replace(
    "/\s*[a-zA-Z\/\/:\.]*youtu(be.com\/watch\?v=|.be\/)([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i",
    "<iframe width=\"100%\" height=\"400\" src=\"//www.youtube.com/embed/$2\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>",
    $string
  );
}

/* search */
add_action( 'wp_footer', 'ajax_fetch' );
function ajax_fetch() { ?>

<script type="text/javascript">
 function fetch(){

     jQuery.ajax({
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        type: 'post',
        data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
        success: function(data) {
            jQuery('#datafetch').html( data );
        }
    });

}
</script>
<?php
}

 // the ajax function
add_action('wp_ajax_data_fetch' , 'data_fetch');
add_action('wp_ajax_nopriv_data_fetch','data_fetch');

function data_fetch(){
if (  esc_attr( $_POST['keyword'] ) == null ) { die(); }
        $the_query = new WP_Query( array( 'post_type'=> 'mt_listing',  'post_status' => array('publish'), 'post_per_page' =>  2 , 's' => esc_attr( $_POST['keyword'] ) ) );
        $count_tax = 0;
        if( $the_query->have_posts() ) : ?>
            <ul class="search-result">           
                <?php while( $the_query->have_posts() ): $the_query->the_post();  $post_type = get_post_type_object( get_post_type() );?>   
                        <?php if($count_tax < 3) { ?>             
                            <li><a href="<?php echo esc_url( post_permalink() ); ?>"><?php the_title();?></a></li>   
                        <?php } ?> 
                        <?php $count_tax++; ?>     
                <?php endwhile; ?>
            </ul>       
            <?php wp_reset_postdata();  
        
        endif;
    die();
}

/* used in template add - edit  listing */
function get_attachment_id( $url ) {
    $attachment_id = 0;
    $dir = wp_upload_dir();
    if ( false !== strpos( $url, $dir['baseurl'] . '/' ) ) { // Is URL in uploads directory?
        $file = basename( $url );
        $query_args = array(
            'post_type'   => 'attachment',
            'post_status' => 'inherit',
            'fields'      => 'ids',
            'meta_query'  => array(
                array(
                    'value'   => $file,
                    'compare' => 'LIKE',
                    'key'     => '_wp_attachment_metadata',
                ),
            )
        );
        $query = new WP_Query( $query_args );
        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post_id ) {
                $meta = wp_get_attachment_metadata( $post_id );
                $original_file       = basename( $meta['file'] );
                $cropped_image_files = wp_list_pluck( $meta['sizes'], 'file' );
                if ( $original_file === $file || in_array( $file, $cropped_image_files ) ) {
                    $attachment_id = $post_id;
                    break;
                }
            }
        }
    }
    return $attachment_id;
}

/*  */

if ( class_exists( 'WooCommerce' ) ) {
    function allow_contributor_uploads() {
        $contributor = get_role('customer');
        $contributor->add_cap('upload_files');
    }
    add_action('admin_init', 'allow_contributor_uploads');
}


function modeltheme_content_single_share() {
    echo '<div class="single-ico-social-sharer-tooltip"><ul class="single-ico-social-sharer">
        <li class="facebook">
            <a  title="'.esc_html__('Share on Facebook','mtlisitings').'"  href="http://www.facebook.com/share.php?u='.get_permalink().'&amp;title='.get_the_title().'"><i class="fa fa-facebook"></i></a>
        </li>
        <li class="twitter">
            <a  title="'.esc_html__('Share on Twitter','mtlisitings').'"  href="http://twitter.com/home?status='.get_the_title().'+'.get_permalink().'"><i class="fa fa-twitter"></i></a>
        </li>
        <li class="linkedin">
            <a  title="'.esc_html__('Share on LinkedIn','mtlisitings').'"  href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.get_permalink().'&amp;title='.get_the_title().'&amp;source='.get_permalink().'"><i class="fa fa-linkedin"></i></a>
        </li>
        <li class="google-plus">
            <a  title="'.esc_html__('Share on Google','mtlisitings').'"  href="https://plus.google.com/share?url='.get_permalink().'"><i class="fa fa-google"></i></a>
        </li>
        <li class="pinterest">
            <a  title="'.esc_html__('Pin on Pinterest','mtlisitings').'"  href="http://pinterest.com/pin/create/bookmarklet/?media='.get_permalink().'&url='.get_permalink().'&is_video=false&description='.get_permalink().'"><i class="fa fa-pinterest-p"></i></a>
        </li>
        <li class="reddit">
            <a  title="'.esc_html__('Share on Reddit','mtlisitings').'"  href="http://www.reddit.com/submit?url='.get_permalink().'&amp;title='.get_the_title().'"><i class="fa fa-reddit-alien"></i></a>
        </li>
        <li class="tumblr">
            <a  title="'.esc_html__('Share on Tumblr','mtlisitings').'"  href="http://www.tumblr.com/share?v=3&amp;u='.get_permalink().'&amp;t='.get_the_title().'"><i class="fa fa-tumblr"></i></a>
        </li>
    </ul></div>';
}

function toDraft($pid){

$toDraft = $_POST['draft'];
   if($toDraft == 'OFF'){
      echo "The job have been disabled";
      wp_update_post(array('ID' => $pid, 'post_status'   =>  'draft'));
  }

}
function topUBLISH($pid){

$toPublish = $_POST['publish'];
   if($toPublish == 'ON'){
      echo "The job have been published";
      wp_update_post(array('ID' => $pid, 'post_status'   =>  'publish'));
  }

}
?>