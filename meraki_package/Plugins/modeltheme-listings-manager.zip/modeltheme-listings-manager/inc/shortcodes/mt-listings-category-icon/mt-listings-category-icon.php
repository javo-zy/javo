<?php 


/**

||-> Shortcode: Job Types

*/
function modeltheme_shortcode_listings_category_icon($params, $content) {
    extract( shortcode_atts( 
        array(
            'category'            => '',
            'category_title'      => '',
            'image_skill'         => '', 
            'animation'           => ''
        ), $params ) );
    
    $term = get_term_by( 'slug', $category_title, 'mt-listing-type');

    $image_skill      = wp_get_attachment_image_src($image_skill, 65);
    $image_skillsrc  = $image_skill[0];
    $animation_final = '';
    if(!empty($animation)) {
        $animation_final = 'wow ' . $animation;
    }

   

    $html = '';
    $html .= '<div class="listings_category_icon_shortcode ' .$animation_final . '">';

      $html .= '<div class="listings_category_icon_shortcode_holder">';
        $html .= '<a href="'.get_site_url().'/types/'.$category_title.'"><img src="'.esc_attr($image_skillsrc).'" data-src="'.esc_attr($image_skillsrc).'" alt=""></a>';
        $html .= '<h4 class="heading"><a href="'.get_site_url().'/types/'.$category_title.'">'. $category .'</a></h4>';
      $html .= '</div>';

      $html .= '</div>';
    return $html;
}
add_shortcode('mt_listings_category_icon', 'modeltheme_shortcode_listings_category_icon');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    $knowledges = get_posts(array('post_type' => 'mt_listing'));
    $terms = get_terms('mt-listing-type',array('hide_empty' => 0));

    $category = array();

    foreach ($terms as $term) {
         $category[$term->slug] = $term->name;
    }

    $category_title = array();

    foreach ($terms as $term) {
         $category_title[$term->name] = $term->slug;
    }

    vc_map( array(
     "name" => esc_attr__("MT - Job Type Icon", 'mtlisitings'),
     "base" => "mt_listings_category_icon",
     "category" => esc_attr__('MT: ModelTheme', 'mtlisitings'),
     "icon" => "smartowl_shortcode",
     "params" => array(
        array(
               "type" => "dropdown",
               "group" => "Options",
               "holder" => "div",
               "class" => "",
               "heading" => esc_attr__("Select Job Base Type Slug",'mtlisitings'),
               "param_name" => "category",
               "description" => esc_attr__("Please select job base type",'mtlisitings'),
               "std" => '',
               "value" => $category
        ),
        array(
               "type" => "dropdown",
               "group" => "Options",
               "holder" => "div",
               "class" => "",
               "heading" => esc_attr__("Select Job Base Type Title",'mtlisitings'),
               "param_name" => "category_title",
               "description" => esc_attr__("Please select job base type",'mtlisitings'),
               "std" => '',
               "value" => $category_title
        ),
         array(
          "group" => "Options",
          "dependency" => array(
           'element' => 'icon_or_image',
           'value' => array( 'choosed_image' ),
           ),
          "type" => "attach_images",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__( "Choose image", 'mtlisitings' ),
          "param_name" => "image_skill",
          "value" => "",
          "description" => esc_attr__( "Choose image for job type", 'mtlisitings' )
        ),
        array(
          "group" => "Animation",
          "type" => "dropdown",
          "heading" => esc_attr__("Animation", 'mtlisitings'),
          "param_name" => "animation",
          "holder" => "div",
          "class" => "",
          "description" => "",
          "value" => $animations_list
        )
      )
  ));
}

?>