<?php 
/* ------------------------------------------------------------------
[Modeltheme - SHORTCODES]
[Table of contents]
------------------------------------------------------------------ */
include_once( 'mt-ico-filters/mt-icofilters.php' ); # Icofilters
include_once( 'mt-search-listings/mt-listings-searchform.php' ); # Search
include_once( 'mt-listings-category-icon/mt-listings-category-icon.php' ); # Search
include_once( 'mt-listings-category-image/mt-listings-category-image.php' ); # Search
?>