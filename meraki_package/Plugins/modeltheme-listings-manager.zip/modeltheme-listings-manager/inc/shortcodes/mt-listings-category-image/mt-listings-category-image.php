<?php 


/**

||-> Shortcode: listing Category

*/
function modeltheme_shortcode_listings_category_image($params, $content) {
    extract( shortcode_atts( 
        array(
            'category'            => '',
            'category_title'      => '',
            'animation'           => ''
        ), $params ) );
    
    $term = get_term_by( 'slug', $category_title, 'mt-listing-category2');

    $img_id = '';

    $img_id = get_term_meta( $term->term_id, 'category-image-id-v2', true );

    $img_id_1 = '';

    $img_id_1 = get_term_meta( $term->term_id, 'category-image-id', true );

    $thumbnail_src = wp_get_attachment_image_src( $img_id, 'oklahoma_cat_image' );

    $query_count = new WP_Query( array( 'mt-listing-category2' => $term->name ) );
    $count_tax = $query_count->found_posts;
    if($count_tax == 1) {
        $count_string = ' job';
    } else {
        $count_string = ' jobs';
    }

    $thumbnail_src_cat_icon = wp_get_attachment_image_src( $img_id_1, 'oklahoma_cat_icon_image' );

    $html = '';
    $html .= '<div class="listings_category_image_shortcode">';

      $html .= '<div class="listings_category_image_shortcode_holder">';
       if (is_array($thumbnail_src) && isset($thumbnail_src[0])) {
        $html .= '<a href="'.get_site_url().'/categories/'.$category_title.'"><img class="cat-image" alt="cat-image" src="'.$thumbnail_src[0].'"></a>';
        } else {
            $html .= '<a href="'.get_site_url().'/categories/'.$category_title.'"><img class="cat-image" alt="cat-image" src="path_to_default_image/default.jpg"></a>';
        }
        $html .= '<div class="listings_category_footer">';
          $html .= '<div class="category_icon_holder">';
            if (is_array($thumbnail_src_cat_icon) && isset($thumbnail_src_cat_icon[0])) {
                $html .= '<img alt="cat-icon" class="cat-icon" src="'.$thumbnail_src_cat_icon[0].'">';
            } else {
                // Handle the error case, possibly by using a default image or an error message
                $html .= '<img alt="cat-icon" class="cat-icon" src="path_to_default_image/default_cat_icon.jpg">';
            }
          $html .= '</div>';
          $html .= '<h4 class="heading"><a href="'.get_site_url().'/categories/'.$category_title.'">'. $category .'</a></h4>';
          $html .= '<div class="description"><p>'. $count_tax . esc_html($count_string,'mtlisitings') .'</p></div>';
        $html .= '</div>';
      $html .= '</div>';

      $html .= '</div>';
    return $html;
}
add_shortcode('mt_listings_category_image', 'modeltheme_shortcode_listings_category_image');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    $knowledges = get_posts(array('post_type' => 'mt_listing'));
    $terms = get_terms('mt-listing-category2',array('hide_empty' => 0));

    $category = array();

    foreach ($terms as $term) {
         $category[$term->slug] = $term->name;
    }

    $category_title = array();

    foreach ($terms as $term) {
         $category_title[$term->name] = $term->slug;
    }

    vc_map( array(
     "name" => esc_attr__("MT - Job listings Category Image", 'mtlisitings'),
     "base" => "mt_listings_category_image",
     "category" => esc_attr__('MT: ModelTheme', 'mtlisitings'),
     "icon" => "smartowl_shortcode",
     "params" => array(
        array(
               "type" => "dropdown",
               "group" => "Options",
               "holder" => "div",
               "class" => "",
               "heading" => esc_attr__("Select listing Base Category Slug",'mtlisitings'),
               "param_name" => "category",
               "description" => esc_attr__("Please select listing base category",'mtlisitings'),
               "std" => '',
               "value" => $category
        ),
        array(
               "type" => "dropdown",
               "group" => "Options",
               "holder" => "div",
               "class" => "",
               "heading" => esc_attr__("Select listing Base Category Title",'mtlisitings'),
               "param_name" => "category_title",
               "description" => esc_attr__("Please select listing base category",'mtlisitings'),
               "std" => '',
               "value" => $category_title
        ),
        array(
          "group" => "Animation",
          "type" => "dropdown",
          "heading" => esc_attr__("Animation", 'mtlisitings'),
          "param_name" => "animation",
          "std" => 'fadeInUp',
          "holder" => "div",
          "class" => "",
          "description" => "",
          "value" => $animations_list
        )
      )
  ));
}

?>