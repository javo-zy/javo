<?php 
/**
||-> Shortcode: BlogPos01
*/
function modeltheme_shortcode_icofilters($params, $content) {
    extract( shortcode_atts( 
        array(
            'animation'                                =>'',
            'number'                                   =>'',
            'items_per_row'                            =>'',
            'category'                                 =>'',
            'extra_class'                              =>''
        ), $params ) );

    $id = 'mt_ico_filters_'.uniqid();

    
    $html = '';

    if (isset($btn_background_color_normal)) {
      $html .= '<style>';
        $html .= '#'.$id;

        $html .= ' .ico-cat-parent-subtitle a {
                      border: 2px solid '.$btn_background_color_normal.';
                  }';
               $html .=' </style>';
    }
    if (isset($btn_background_color_normal_hover)) {
      $html .= '<style>';
        $html .= '#'.$id;

        $html .= ' .ico-cat-parent-subtitle a:hover {
                      background: '.$btn_background_color_normal_hover.' !important;
                      border: 2px solid '.$btn_background_color_normal_hover.' !important;
                  }';
               $html .=' </style>';
    }

    // STYLE VARIANT


    $html .= '<div id="'.esc_attr($id).'" class="iconfilter-shortcode wow '.$animation.' '.$extra_class.'">';
      $html .= '<div class="row">';
        $html .= '<div class="oklahoma-main-content">';
          $html .= '<section class="oklahoma-gallery">';

          $html .= '<div class="iconfilter-listing">';
       
              // TAXONOMY NAME/LINK
              $html .= '<div class="ico-cat-parent big-parent row">';

                // TAXONOMY POSTS by Current TAXONOMY
                $args_blogposts = array(
                  'posts_per_page'   => $number,
                  'order'            => 'DESC',
                  'post_type'        => 'mt_listing',
                  'tax_query' => array(
                      array(
                          'taxonomy' => 'mt-listing-category2',
                          'field' => 'slug',
                          'terms' => $category
                      )
                  ),
                  'post_status'      => 'publish' 
                ); 
                $blogposts = get_posts($args_blogposts);

                $get_term = get_term_by('slug', $category, 'mt-listing-category2');

                $taxonomy_image_id = get_term_meta ( $get_term->term_id, 'category-image-id', true );
                $tax_img = '';
                if (wp_get_attachment_image ( $taxonomy_image_id, 'thumbnail' )) {
                    $tax_img = wp_get_attachment_image ( $taxonomy_image_id, 'thumbnail' );
                }
            
                

                // START FOREACH
                $i = 1;
                foreach ($blogposts as $blogpost) {
                  #thumbnail
                  $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $blogpost->ID ));
                  $mt_listing_category = get_post_meta( $blogpost->ID, 'mt_listing_category', true ); 
                  $mt_listing_sponsored_status = get_post_meta( $blogpost->ID, 'mt_listing_sponsored_status', true );
                  $mt_listing_salary = get_post_meta( $blogpost->ID, 'mt_listing_salary', true );
                  $mt_listing_company_img = get_post_meta( $blogpost->ID, 'mt_listing_company_img', true );
                  $mt_listing_sponsored_status = get_post_meta( $blogpost->ID, 'mt_listing_sponsored_status', true ); 
                      $mt_listing_sponsored_status_clss = '';
                      if($mt_listing_sponsored_status == 'sponsored_listing') { 
                          $mt_listing_sponsored_status_clss = 'is_sponsored';
                      }
                  $my_excerpt = get_the_excerpt( $blogpost->ID); 
                  ?>
                  <?php if (empty($mt_listing_company_img)) {
                      $post_img = '<img class="blog_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.$blogpost->post_title.'" />';
                  } else  {
                      $post_img = '<img class="blog_post_image" src="'. esc_url($mt_listing_company_img) . '" alt="'.$blogpost->post_title.'" />';
                  }
                  
                  $content_post   = get_post($blogpost->ID);
                  $content        = $content_post->post_content;
                  $content        = apply_filters('the_content', $content);
                  $content        = str_replace(']]>', ']]&gt;', $content);
                  $comments_count = wp_count_comments($blogpost->ID);
                  if($comments_count->approved >= 1) {
                      $comments = 'Comments <a href="'.get_comments_link($blogpost->ID).'">'. $comments_count->approved.'</a>';
                  } else {
                      $comments = 'No comments';
                  }
                  $term_list = wp_get_post_terms($blogpost->ID, 'mt-listing-category');
                  $term_list_types = wp_get_post_terms($blogpost->ID, 'mt-listing-type');
                  $term_list_categories = wp_get_post_terms($blogpost->ID, 'mt-listing-category2');
                  $sticky_class = '';
                  if ( is_sticky($blogpost->ID) ) {
                      $sticky_class = 'is-sticky';
                  }  

                  // TAXONOMY PHOTO/ICON
                  $taxonomy_image_id = get_term_meta ( $term_list_categories[0]->term_id, 'category-image-id', true );

                  $last_item_row = '';
                  if ($items_per_row == 'col-md-12') {
                    $items_per_row_new = 'row-1items';
                  }elseif ($items_per_row == 'col-md-6') {
                    $items_per_row_new = 'row-2items';
                    if ($i%2 == 0) {
                      $last_item_row = 'last_item_row';
                    }
                  }elseif ($items_per_row == 'col-md-4') {
                    $items_per_row_new = 'row-3items';
                    if ($i%3 == 0) {
                      $last_item_row = 'last_item_row';
                    }
                  }elseif ($items_per_row == 'col-md-3') {
                    $items_per_row_new = 'row-4items';
                    if ($i%4 == 0) {
                      $last_item_row = 'last_item_row';
                    }
                  }

                

                  if ($i == 2) {
                      if (($items_per_row == 'col-md-6') && meraki_redux('mt_adplace_ico_list')){
                        if(meraki_redux('mt_adplace_ico_list_adsense_code') != '' && meraki_redux('mt_adplace_ico_list') == 'on_adsense'){
                          echo meraki_redux('mt_adplace_ico_list_adsense_code');
                        }elseif(meraki_redux('mt_adplace_ico_list_img_1_2','url') != '' && meraki_redux('mt_adplace_ico_list') == 'on'){  
                      $html .= '<div class="'.$items_per_row.' '.$items_per_row_new.' adplace-'.$items_per_row_new.'">
                                  <div class="post '.esc_attr($sticky_class).'">
                                        <a href="'. esc_url(meraki_redux('mt_adplace_ico_list_link')) .'" target="_blank">
                                            <img src="'. esc_url(meraki_redux('mt_adplace_ico_list_img_1_2','url')) .'" alt="" />
                                        </a>
                                  </div>
                                </div>
                                <div class="clearfix"></div>';
                      }
                    }
                  }

                  if ($i == 4) {
                    if (($items_per_row == 'col-md-3') && meraki_redux('mt_adplace_ico_list')) {
                       if(meraki_redux('mt_adplace_ico_list_adsense_code') != '' && meraki_redux('mt_adplace_ico_list') == 'on_adsense'){
                          echo meraki_redux('mt_adplace_ico_list_adsense_code');
                        }elseif(meraki_redux('mt_adplace_ico_list_img_slider','url') != '' && meraki_redux('mt_adplace_ico_list') == 'on'){  
                      $html .= '<div class="'.$items_per_row.' '.$items_per_row_new.' adplace-'.$items_per_row_new.'">
                                  <div class="post '.esc_attr($sticky_class).'">
                                        <a href="'. esc_url(meraki_redux('mt_adplace_ico_list_link')) .'" target="_blank">
                                            <img src="'. esc_url(meraki_redux('mt_adplace_ico_list_img_1_4','url')) .'" alt="" />
                                        </a>
                                  </div>
                                </div>
                                <div class="clearfix"></div>';
                    }
                  }
                 }

                  if($items_per_row == 'col-md-12') {

                      
                    $html.='<div class="listing-grid-1item '.$items_per_row.' '.$items_per_row_new.' '.$last_item_row.'  meraki-single-list-item mix '.esc_attr($term_list[0]->slug).' '.$blogpost->post_title.' '.esc_attr($term_list_categories[0]->slug).'">
                              <div class="post '.esc_attr($sticky_class).'">
                                <div class=" '.$mt_listing_sponsored_status_clss.' col-md-2">
                                      <div class="blog_custom_listings thumbnail-name">
                                        <div class="listing-thumbnail">
                                          <a class="relative" href="'.get_permalink($blogpost->ID).'">'.$post_img.'</a>
                                        </div>
                                       
                                      </div>                
                                    </div>
                                <div class="blog_custom_listings '.$mt_listing_sponsored_status_clss.' col-md-10 ">
                                  <div class="row">
                                    
                              

                                    <div class="single_job_info col-md-5 col-xs-6">
                                     <h4 class="listing-name">
                                          <a href="'.get_permalink($blogpost->ID).'" title="'.get_the_title().'">'.$blogpost->post_title.'</a>
                                     </h4>
                                      <div class="subtitle-section">
                                        <div class="row">
                                            <div class="categories-name"><i class="fa fa-map-marker"></i>'. get_the_term_list( $blogpost->ID, 'mt-listing-category', '', ', ') .'</div>
                                            <div class="categories-name"><i class="fa fa-money"></i>'.esc_attr($mt_listing_salary).'</div>
                                          </div>
                                        </div>
                                    </div>

                                    <div class="single_job_button col-md-4 col-xs-6">
                                      <div class="single_list_buttons">
                                        <div class="row"> ';

                                            if($mt_listing_sponsored_status == 'sponsored_listing') { 
                                             $html.='<div class="listing_sponsored_bolt">
                                                 <span class="listing_sponsored_status" title="'.esc_attr__('Sponsored Listing','mtlisitings').'"><i class="fa fa-bolt" aria-hidden="true"></i></span>
                                              </div>';     
                                                  } 
                                            $html.='<div class="list_category">
                                              <span>'. get_the_term_list( $blogpost->ID, 'mt-listing-category2', '', ', ') .'</span>
                                            </div> ';

                                            

                                            $terms = get_the_term_list( $blogpost->ID, 'mt-listing-type' );
                                            $terms = strip_tags( $terms );
                                            $html.='
                                            <div class="list_category" id="'.esc_attr($terms).'">
                                                <span>'. get_the_term_list( $blogpost->ID, 'mt-listing-type', '', ', ') .'</span></div>';

                                            

                                        $html.=' </div>

                                           
                                      </div>
                                    </div>


                                    <div class="col-md-3">
                                      <div class="listing-actions">
                                        <a class="button-winona btn btn-sm" href="'.get_permalink($blogpost->ID).'">'.esc_html__('Apply Now','mtlisitings').'</a>
                                        
                                      </div>
                                    </div>


                                  </div>
                                </div>
                              </div> 
                            </div>'; 
                  } else {
                    $html.='<div class="'.$items_per_row.' '.$items_per_row_new.' '.$last_item_row.' oklahoma-single-list-item mix '.esc_attr($term_list[0]->slug).' '.$blogpost->post_title.' '.esc_attr($term_list_categories[0]->slug).'">
                              <div class="post '.esc_attr($sticky_class).' '.esc_attr($mt_listing_sponsored_status).'">
                                <div class="blog_custom_listings">
                                  <div class="row">
                                    <div class="thumbnail-name">
                                      <div class="oklahoma-img-left pull-left">
                                        <a class="relative" href="'.get_permalink($blogpost->ID).'">'.$post_img.'</a>
                                      </div>';

                                     $html.='<div class="oklahoma-details-title pull-left">

                                                <h4 class="post-name-listings"><a href="'.get_permalink($blogpost->ID).'">'.$blogpost->post_title.'</a>

                                                <div class="listing-grid-star-sponsored">
                                                      <div class="listing-star">'.listing_rating_average($blogpost->ID).'</div>';

                                                        if($mt_listing_sponsored_status == 'sponsored_listing') { 
                                                            $html.='<div class="listing_sponsored_bolt">
                                                              <span class="listing_sponsored_status"><i class="fa fa-bolt" aria-hidden="true"></i></span>
                                                            </div>';      
                                                        } 

                                                $html.='</div>

                                                </h4>';                              
                                     $html.='</div>';
                                    $html.='</div>';

                          $html.='<div class="oklahoma-details pull-left">';
                                      
                                    if (($items_per_row == 'col-md-12')) {
                                      $html .= '<p class="oklahoma-details-content">'.esc_attr($my_excerpt).'</p>';
                                    }elseif ($items_per_row == 'col-md-4') {
                                      $html .= '<p class="oklahoma-details-content">'.mtlisitings_excerpt_limit($my_excerpt, 8).' (...)</p>';
                                    }elseif ($items_per_row == 'col-md-3') {
                                      $html .= '<p class="oklahoma-details-content">'.mtlisitings_excerpt_limit($my_excerpt, 20).' (...)</p>';
                                    }elseif ($items_per_row == 'col-md-6') {
                                      $html .= '<p class="oklahoma-details-content">'.mtlisitings_excerpt_limit($my_excerpt, 12).' (...)</p>';
                                    }

                                    $html.='<div class="listings_details">                                
                  
                                      <div class="clearfix"></div>
                                      <div class="oklahoma-metas">
                                        <div class="oklahoma-metas-single-meta pull-left ico-type">
                                          <div><i class="fa fa-map-marker"></i> '.esc_attr($term_list[0]->name).'</div>
                                        </div>
                                        
                                        <div class="oklahoma-metas-single-meta pull-left ico-category">
                                          <div>' . esc_attr($term_list_categories[0]->name).'</div>
                                        </div>
                                      </div>
                                    </div>


                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>';
                  }
                $i++;
                }

                $html .= '<div class="clearfix"></div>';

                
                $html .= '<div class="clearfix"></div>';


              $html .= '</div>';

            $html .= '</div>';
          $html .= '</section>';
        $html .= '</div>';
      $html .= '</div>';
    $html .= '</div>';
    return $html;
}
add_shortcode('icofilters', 'modeltheme_shortcode_icofilters');
/**
||-> Map Shortcode in Visual Composer with: vc_map();
*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {
  require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

  $post_category_tax = get_terms('mt-listing-category2');
  $post_type_tax = get_terms('mt-listing-type');
  $post_category = array();
  foreach ( $post_category_tax as $term ) {
    $post_category[$term->name] = $term->slug;
  }

  vc_map( array(
     "name" => esc_attr__("MT - Job Listing Grid", 'mtlisitings'),
     "base" => "icofilters",
     "category" => esc_attr__('MT: ModelTheme', 'mtlisitings'),
     "icon" => "smartowl_shortcode",
     "params" => array(
        array(
          "group" => "Options",
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__( "Number of posts", 'mtlisitings' ),
          "param_name" => "number",
          "value" => "",
          "description" => esc_attr__( "Enter number of blog post to show.", 'mtlisitings' )
        ),
        array(
            "group" => "Options",
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => esc_attr__("Items Per Row", 'mtlisitings'),
            "param_name" => "items_per_row",
            "std" => '',
            "description" => "",
            "value" => array(
                esc_attr__('1 Items/Row', 'mtlisitings')         => 'col-md-12',
                esc_attr__('2 Items/Row', 'mtlisitings')         => 'col-md-6',
                esc_attr__('3 Items/Row', 'mtlisitings')         => 'col-md-4',
                esc_attr__('4 Items/Row', 'mtlisitings')         => 'col-md-3',
            )
        ),
        array(
          "group" => "Options",
          "type" => "textfield",
          "heading" => __("Extra class name", 'mtlisitings'),
          "param_name" => "extra_class",
          "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'mtlisitings')
        ),
        array(
           "type" => "dropdown",
           "group" => "Options",
           "holder" => "div",
           "class" => "",
           "heading" => esc_attr__("Select Job Category",'mtlisitings'),
           "param_name" => "category",
           "description" => esc_attr__("Please select blog category",'mtlisitings'),
           "std" => 'Default value',
           "value" => $post_category
        ),
        array(
          "group" => "Animation",
          "type" => "dropdown",
          "heading" => esc_attr__("Animation", 'mtlisitings'),
          "param_name" => "animation",
          "std" => 'fadeInLeft',
          "holder" => "div",
          "class" => "",
          "description" => "",
          "value" => $animations_list
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "Title color", 'mtlisitings' ),
          "param_name" => "title_color",
          "value" => ""
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "Description color", 'mtlisitings' ),
          "param_name" => "desc_color",
          "value" => ""
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "Title Background", 'mtlisitings' ),
          "param_name" => "title_bg",
          "value" => ""
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "'View All...' Button Background", 'mtlisitings' ),
          "param_name" => "btn_background_color_normal",
          "value" => ""
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "'View All...' Button Background Hover", 'mtlisitings' ),
          "param_name" => "btn_background_color_normal_hover",
          "value" => ""
        )
      )
  ));
}
?>