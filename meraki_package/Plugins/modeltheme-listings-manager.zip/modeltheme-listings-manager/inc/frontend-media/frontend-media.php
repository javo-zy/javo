<?php
/*--------------------------------------------------
Author Dashboard Custom field [image]
--------------------------------------------------*/
  




/**
 * Class wrapper for Front End Media example
 */
class Front_End_Media {
	/**
	 * A simple call to init when constructed
	 */
	function __construct() {
		add_action( 'init', array( $this, 'init' ) );
	}
	function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_filter( 'ajax_query_attachments_args', array( $this, 'filter_media' ) );
		add_shortcode( 'frontend-button', array( $this, 'frontend_shortcode' ) );
	}
	/**
	 * Call wp_enqueue_media() to load up all the scripts we need for media uploader
	 */
	function enqueue_scripts() {
		wp_enqueue_media();
		wp_enqueue_script( 'media-lib-uploader-js', plugin_dir_url( __FILE__ ) . 'js/media-lib-uploader.js', array('jquery'), '1.0.0', true );
	}
	/**
	 * This filter insures users only see their own media
	 */
	function filter_media( $query ) {
		// admins get to see everything
		if ( ! current_user_can( 'manage_options' ) )
			$query['customer'] = get_current_user_id();
		return $query;
	}
	function frontend_shortcode( $args ) {
	    $current_user = wp_get_current_user();

		$allowed_roles = array('editor', 'administrator', 'author', 'customer');
		if( array_intersect($allowed_roles, $current_user->roles ) ) {  
			$str = __( 'Select photo', 'mtlisitings' );
			return '
			
			<div class="form-group">  
				<div class="upload-images col-md-4">
					<label>'.__('Featured Image','mtlisitings').'</label>
					<div class="spacer-upload">
						<div class="text">' . $str . '</div>
					</div>			
				</div>
				<div class="clearfix"></div>
				<small class="field-description">'.__( 'This image will be shown on job options.', 'mtlisitings' ).'</small>
				<input type="hidden" id="user_pic_custom" name="mt_listing_image[]" value="" />
				<div class="group_pictures_holder row"></div><div class="clearfix"></div>
				<input type="hidden" id="group_pictures" name="group_pictures" value="" />
			</div>

			';
		}
		return __( 'Please Login To Upload', 'mtlisitings' );
	}
}
new Front_End_Media();


?>