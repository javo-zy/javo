<?php
/**
||-> CPT - [Job]
*/
function mtlisitings_listings_custom_post() {
    register_post_type('mt_listing', array(
                        'label' => __('Jobs','mtlisitings'),
                        'description' => '',
                        'public' => true,
                        'show_ui' => true,
                        'show_in_menu' => true,
                        'capability_type' => 'post',
                        'map_meta_cap' => true,
                        'hierarchical' => false,
                        'rewrite' => array('slug' => 'jobs', 'with_front' => true),
                        'query_var' => true,
                        'menu_position' => '1',
                        'menu_icon' => 'dashicons-performance',
                        'supports' => array('title','editor','thumbnail','author','excerpt', 'comments'),
                        'labels' => array (
                            'name' => __('Jobs','mtlisitings'),
                            'singular_name' => __('Job','mtlisitings'),
                            'menu_name' => __('MT Jobs','mtlisitings'),
                            'add_new' => __('Add Job','mtlisitings'),
                            'add_new_item' => __('Add New Job','mtlisitings'),
                            'edit' => __('Edit','mtlisitings'),
                            'edit_item' => __('Edit Job','mtlisitings'),
                            'new_item' => __('New Job','mtlisitings'),
                            'view' => __('View Job','mtlisitings'),
                            'view_item' => __('View Job','mtlisitings'),
                            'search_items' => __('Search Jobs','mtlisitings'),
                            'not_found' => __('No Jobs Found','mtlisitings'),
                            'not_found_in_trash' => __('No Jobs Found in Trash','mtlisitings'),
                            'parent' => __('Parent Job','mtlisitings'),
                            )
                        ) 
                    ); 
}
add_action('init', 'mtlisitings_listings_custom_post');
/**
||-> CPT - [listing] Taxonomy ICO Types
*/
function mtlisitings_listings_category_custom_post() {
    
    $labels = array(
        'name'                       => _x( 'Locations', 'Taxonomy General Name', 'mtlisitings' ),
        'singular_name'              => _x( 'Location', 'Taxonomy Singular Name', 'mtlisitings' ),
        'menu_name'                  => __( 'Locations', 'mtlisitings' ),
        'all_items'                  => __( 'All Items', 'mtlisitings' ),
        'parent_item'                => __( 'Parent Item', 'mtlisitings' ),
        'parent_item_colon'          => __( 'Parent Item:', 'mtlisitings' ),
        'new_item_name'              => __( 'New Item Name', 'mtlisitings' ),
        'add_new_item'               => __( 'Add New Item', 'mtlisitings' ),
        'edit_item'                  => __( 'Edit Item', 'mtlisitings' ),
        'update_item'                => __( 'Update Item', 'mtlisitings' ),
        'view_item'                  => __( 'View Item', 'mtlisitings' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'mtlisitings' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'mtlisitings' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'mtlisitings' ),
        'popular_items'              => __( 'Popular Items', 'mtlisitings' ),
        'search_items'               => __( 'Search Items', 'mtlisitings' ),
        'not_found'                  => __( 'Not Found', 'mtlisitings' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'locations' ),
    );
    register_taxonomy( 'mt-listing-category', array( 'mt_listing' ), $args );
}
add_action( 'init', 'mtlisitings_listings_category_custom_post' );

/**
||-> CPT - [listing] Taxonomy ICO Types
*/
function mtlisitings_listings_types_custom_post() {
    
    $labels = array(
        'name'                       => _x( 'Job Types', 'Taxonomy General Name', 'mtlisitings' ),
        'singular_name'              => _x( 'Job Type', 'Taxonomy Singular Name', 'mtlisitings' ),
        'menu_name'                  => __( 'Types', 'mtlisitings' ),
        'all_items'                  => __( 'All Items', 'mtlisitings' ),
        'parent_item'                => __( 'Parent Item', 'mtlisitings' ),
        'parent_item_colon'          => __( 'Parent Item:', 'mtlisitings' ),
        'new_item_name'              => __( 'New Item Name', 'mtlisitings' ),
        'add_new_item'               => __( 'Add New Item', 'mtlisitings' ),
        'edit_item'                  => __( 'Edit Item', 'mtlisitings' ),
        'update_item'                => __( 'Update Item', 'mtlisitings' ),
        'view_item'                  => __( 'View Item', 'mtlisitings' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'mtlisitings' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'mtlisitings' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'mtlisitings' ),
        'popular_items'              => __( 'Popular Items', 'mtlisitings' ),
        'search_items'               => __( 'Search Items', 'mtlisitings' ),
        'not_found'                  => __( 'Not Found', 'mtlisitings' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'types' ),
    );
    register_taxonomy( 'mt-listing-type', array( 'mt_listing' ), $args );
}
add_action( 'init', 'mtlisitings_listings_types_custom_post' );


/**
||-> CPT - [listing] Taxonomy category
*/
function mtlisitings_listings_category2_custom_post() {
    
    $labels = array(
        'name'                       => _x( 'Categories', 'Taxonomy General Name', 'mtlisitings' ),
        'singular_name'              => _x( 'Categories', 'Taxonomy Singular Name', 'mtlisitings' ),
        'menu_name'                  => __( 'Categories', 'mtlisitings' ),
        'all_items'                  => __( 'All Items', 'mtlisitings' ),
        'parent_item'                => __( 'Parent Item', 'mtlisitings' ),
        'parent_item_colon'          => __( 'Parent Item:', 'mtlisitings' ),
        'new_item_name'              => __( 'New Item Name', 'mtlisitings' ),
        'add_new_item'               => __( 'Add New Item', 'mtlisitings' ),
        'edit_item'                  => __( 'Edit Item', 'mtlisitings' ),
        'update_item'                => __( 'Update Item', 'mtlisitings' ),
        'view_item'                  => __( 'View Item', 'mtlisitings' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'mtlisitings' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'mtlisitings' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'mtlisitings' ),
        'popular_items'              => __( 'Popular Items', 'mtlisitings' ),
        'search_items'               => __( 'Search Items', 'mtlisitings' ),
        'not_found'                  => __( 'Not Found', 'mtlisitings' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'categories' ),
    );
    register_taxonomy( 'mt-listing-category2', array( 'mt_listing' ), $args );
}
add_action( 'init', 'mtlisitings_listings_category2_custom_post' );

/**
||-> CPT - [listing] Taxonomy Amenities
*/
function mtlisitings_listings_tags_custom_post() {
    
    $labels = array(
        'name'                       => _x( 'Tags', 'Taxonomy General Name', 'mtlisitings' ),
        'singular_name'              => _x( 'Tags', 'Taxonomy Singular Name', 'mtlisitings' ),
        'menu_name'                  => __( 'Tags', 'mtlisitings' ),
        'all_items'                  => __( 'All Items', 'mtlisitings' ),
        'parent_item'                => __( 'Parent Item', 'mtlisitings' ),
        'parent_item_colon'          => __( 'Parent Item:', 'mtlisitings' ),
        'new_item_name'              => __( 'New Item Name', 'mtlisitings' ),
        'add_new_item'               => __( 'Add New Item', 'mtlisitings' ),
        'edit_item'                  => __( 'Edit Item', 'mtlisitings' ),
        'update_item'                => __( 'Update Item', 'mtlisitings' ),
        'view_item'                  => __( 'View Item', 'mtlisitings' ),
        'separate_items_with_commas' => __( 'Separate items with commas', 'mtlisitings' ),
        'add_or_remove_items'        => __( 'Add or remove items', 'mtlisitings' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'mtlisitings' ),
        'popular_items'              => __( 'Popular Items', 'mtlisitings' ),
        'search_items'               => __( 'Search Items', 'mtlisitings' ),
        'not_found'                  => __( 'Not Found', 'mtlisitings' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'tags' ),
    );
    register_taxonomy( 'mt-listing-tags', array( 'mt_listing' ), $args );
}
add_action( 'init', 'mtlisitings_listings_tags_custom_post' );


/**
||-> CPT - [Applications]
*/
function mtlisitings_applications_custom_post() {
    register_post_type('mt_application', array(
                        'label' => __('MT Applications','mtlisitings'),
                        'description' => '',
                        'public' => true,
                        'show_ui' => true,
                        'show_in_menu' => true,
                        'capability_type' => 'post',
                        'map_meta_cap' => true,
                        'hierarchical' => false,
                        'rewrite' => array('slug' => 'application', 'with_front' => true),
                        'query_var' => true,
                        'menu_position' => '1',
                        'menu_icon' => 'dashicons-performance',
                        'supports' => array('title','editor','author'),
                        'labels' => array (
                            'name' => __('Applications','mtlisitings'),
                            'singular_name' => __('Application','mtlisitings'),
                            'menu_name' => __('MT Job Applications','mtlisitings'),
                            'add_new' => __('Add Application','mtlisitings'),
                            'add_new_item' => __('Add New Application','mtlisitings'),
                            'edit' => __('Edit','mtlisitings'),
                            'edit_item' => __('Edit Application','mtlisitings'),
                            'new_item' => __('New Application','mtlisitings'),
                            'view' => __('View Application','mtlisitings'),
                            'view_item' => __('View Application','mtlisitings'),
                            'search_items' => __('Search Application','mtlisitings'),
                            'not_found' => __('No Applications Found','mtlisitings'),
                            'not_found_in_trash' => __('No Applications Found in Trash','mtlisitings'),
                            'parent' => __('Parent Application','mtlisitings'),
                            )
                        ) 
                    ); 
}
add_action('init', 'mtlisitings_applications_custom_post');

add_action( 'submitpost_box', function() {
    global $post;
    if ( isset( $post->post_type ) && in_array( $post->post_type, array( 'mt_listing') ) ) {
        $post->post_type_original = $post->post_type;
        $post->post_type = 'post';
    }
} );
?>