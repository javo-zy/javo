<?php

function mtlisitings_extend_redux_tabs($sections)
	{
	$sections[] = array(
		'title' => esc_html__('MT Jobs Settings', 'mtlisitings') ,
		'id' => 'mt_listings',
		'icon' => 'el el-icon-comment'
	);
	$sections[] = array(
		'title' => esc_html__('General', 'mtlisitings') ,
		'id' => 'mt_listings_settings_currency',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_listings_submit_ico_status',
                'type'     => 'switch', 
                'title'    => esc_html__('Submit Job Button', 'mtlisitings'),
                'subtitle' => esc_html__('Enable or disable "Submit Job Button".', 'mtlisitings'),
                'default'  => false,
                'on'       => esc_html__( 'Enabled', 'mtlisitings' ),
                'off'      => esc_html__( 'Disabled', 'mtlisitings' )
            ),
			array(
				'id' => 'mt_listings_submit_ico_page',
				'type' => 'text',
				'title' => esc_html__('Header Submit Job Button Page', 'mtlisitings') ,
				'subtitle' => esc_html__('Select Page for the Header Submit Job Button.', 'mtlisitings'),
                'required' => array( 'mt_listings_submit_ico_status', '=', true ),
                'default'  => '#',
			),
			array(
                'id'       => 'mt_listings_devmode',
                'type'     => 'switch', 
                'title'    => esc_html__('Developer Mode Status', 'mtlisitings'),
                'subtitle' => esc_html__('Enable or disable the right to disable jobs. ', 'mtlisitings'),
                'default'  => true,
            ),
			array(
                'id'   => 'mt_divider_preloader_styling',
                'type' => 'info',
                'class' => 'mt_divider',
                'desc' => wp_kses_post( '<h3>My Account Page</h3>' )
            ),
            array(
                'id' => 'mt_listings_account_link1_title',
                'type' => 'text',
                'title' => esc_html__('My Account Link 1 Title', 'mtlisitings') ,
                'subtitle' => esc_html__('Select tab name for My account Link 1', 'mtlisitings'),
                'default'  => 'Submit FREE Listing',
            ),
            array(
                'id' => 'mt_listings_account_link1',
                'type' => 'text',
                'title' => esc_html__('My Account Link 1 URL', 'mtlisitings') ,
                'subtitle' => esc_html__('Type your URL for My account page Link 1', 'mtlisitings'),
                'desc' => esc_html__('For example: "https://meraki.modeltheme.com/listing"', 'mtlisitings'),
                'default'  => 'https://meraki.modeltheme.com/listing',
            ),
            array(
                'id' => 'mt_listings_account_link2_title',
                'type' => 'text',
                'title' => esc_html__('My Account Link 2 Title', 'mtlisitings') ,
                'subtitle' => esc_html__('Select tab name for My account Link 2', 'mtlisitings'),
                'default'  => 'Submit Sponsored Listing',
            ),
            array(
                'id' => 'mt_listings_account_link2',
                'type' => 'text',
                'title' => esc_html__('My Account Link 2 URL', 'mtlisitings') ,
                'subtitle' => esc_html__('Type your URL for My account page Link 2', 'mtlisitings'),
                'desc' => esc_html__('For example: "https://meraki.modeltheme.com/pricing-table/"', 'mtlisitings'),
                'default'  => '',
            ),

		),
	);

	// Archive Job Pages
	$sections[] = array(
		'title' => esc_html__('Archive Jobs Pages', 'mtlisitings') ,
		'id' => 'mt_listings_settings_archive',
		'subsection' => true,
		'fields' => array(
			array(
		        'id'       => 'mt_listings_layout',
		        'type'     => 'image_select',
		        'compiler' => true,
		        'title'    => esc_html__( 'Jobs Archive Layout', 'mtlisitings' ),
		        'subtitle' => esc_html__( 'Select Jobs Archive layout.', 'mtlisitings' ),
		        'options'  => array(
		            'mt_listings_left_sidebar' => array(
		                'alt' => esc_html__('2 Columns - Left sidebar', 'mtlisitings' ),
		                'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-left.jpg'
		            ),
		            'mt_listings_fullwidth' => array(
		                'alt' => esc_html__('1 Column - Full width', 'mtlisitings' ),
		                'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-no.jpg'
		            ),
		            'mt_listings_right_sidebar' => array(
		                'alt' => esc_html__('2 Columns - Right sidebar', 'mtlisitings' ),
		                'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-right.jpg'
		            )
		        ),
		        'default'  => 'mt_listings_right_sidebar'
		    ),
			array(
		        'id'       => 'mt_listings_layout_sidebar',
		        'type'     => 'select',
		        'data'     => 'sidebars',
		        'title'    => esc_html__( 'Job Archive Sidebar', 'mtlisitings' ),
		        'subtitle' => esc_html__( 'Select Job Archive Sidebar.', 'mtlisitings' ),
		        'default'   => 'sidebar-1',
		        'required' => array('mt_listings_layout', '!=', 'mt_listings_fullwidth'),
		    ),
		),
	);

	// Sponsored Listing Package
	$sections[] = array(
		'title' => esc_html__('Sponsored Job Package', 'mtlisitings') ,
		'id' => 'mt_listings_settings_package',
		'subsection' => true,
		'fields' => array(
            array(
                'id' => 'mt_premium_package_productid',
                'type' => 'text',
                'title' => esc_html__('Set WooCommerce Product ID for the Sponsored package feature', 'mtlisitings'),
                'subtitle' => esc_html__('Learn how to get the Product ID: https://bit.ly/2RW8b0n', 'mtlisitings'),
                'default' => ''
            ),
		),
	);


	// Single Listing Page
	$sections[] = array(
		'title' => esc_html__('Single Job Page', 'mtlisitings') ,
		'id' => 'mt_listings_settings_single',
		'subsection' => true,
		'fields' => array(
			array(
				'id' => 'mt_related_listings',
				'type' => 'switch',
				'title' => esc_html__('Related Jobs', 'mtlisitings') ,
				'subtitle' => esc_html__('Enable or disable related Jobs', 'mtlisitings') ,
				'default' => true,
			),
			array(
                'id' => 'mt_job_icon',
                'type' => 'media',
                'url' => true,
                'title' => esc_html__('Single Job icon', 'mtlisitings'),
                'compiler' => 'true',
                'default' => array('url' => get_template_directory_uri().'/images/job-check.png'),
            ),
			
		),
	);

	// Single Listing Page
	$sections[] = array(
		'title' => esc_html__('API KEY Maps', 'mtlisitings') ,
		'id' => 'mt_listings_settings_api',
		'subsection' => true,
		'fields' => array(
			array(
                'id' => 'mt_listings_api_key',
                'type' => 'text',
                'title' => esc_html__('Set the API key for maps', 'mtlisitings'),
                'subtitle' => esc_html__('', 'mtlisitings'),
                'default' => ''
            ),
		),
	);

	$sections[] = array(
		'title' => esc_html__('MT AdPlaces', 'mtlisitings') ,
		'id' => 'mt_adplaces',
		'icon' => 'el el-cogs'
	);
	$sections[] = array(
		'title' => esc_html__('AdPlace Single ICO Listing', 'mtlisitings') ,
		'id' => 'mt_adplaces_1',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_adplace_single',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - ICO Listing - Top/Bottom', 'mtlisitings' ),
                'subtitle' => esc_html__( 'Select your "AdPlace ICO Listing - Top/Bottom"', 'mtlisitings' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off' 		 => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_single_sidebar_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace Sidebar URL', 'mtlisitings'),
                'subtitle' => esc_html__('Type your AdPlace ICO Listing - Sidebar URL.', 'mtlisitings'),
                'required' => array( 'mt_adplace_single', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlisitings'),
                'default' => 'https://'
            ),
			array(
				'id' => 'mt_adplace_single_sidebar_img',
				'type' => 'media',
				'title' => esc_html__('Choose image for AdPlace Sidebar', 'mtlisitings'),
				'subtitle' => esc_html__('Use the upload button to import media.', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_single', '=', 'on' )
			),
		),
	);

	

	$sections[] = array(
		'title' => esc_html__('AdPlace Blog Post', 'mtlisitings') ,
		'id' => 'mt_adplaces_blog_post',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_adplace_blog_post',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - Blog Post', 'mtlisitings' ),
                'subtitle' => esc_html__( 'Select your "AdPlace content blog post"', 'mtlisitings' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off' 		 => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_blog_post_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace URL', 'mtlisitings'),
                'subtitle' => esc_html__('Type your AdPlace blog post URL.', 'mtlisitings'),
                'required' => array( 'mt_adplace_blog_post', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlisitings'),
                'default' => 'https://'
            ),
			array(
				'id' => 'mt_adplace_blog_post_img',
				'type' => 'media',
				'title' => esc_html__('Choose image for AdPlace Blog Post', 'mtlisitings'),
				'subtitle' => esc_html__('Use the upload button to import media.', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_blog_post', '=', 'on' )
			),
            array(
                'id' => 'mt_adplace_blog_post_adsense_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'mtlisitings'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'mtlisitings'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'mtlisitings'),
                'required' => array( 'mt_adplace_blog_post', '=', 'on_adsense' ),
                'default' => ''
            ),
		),
	);

	$sections[] = array(
		'title' => esc_html__('AdPlace Search', 'mtlisitings') ,
		'id' => 'mt_adplaces_search',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_adplace_search',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - Search', 'mtlisitings' ),
                'subtitle' => esc_html__( 'Select your "AdPlace Search"', 'mtlisitings' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off' 		 => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_search_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace URL', 'mtlisitings'),
                'subtitle' => esc_html__('Type your AdPlace Search URL.', 'mtlisitings'),
                'required' => array( 'mt_adplace_search', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlisitings'),
                'default' => 'https://'
            ),
			array(
				'id' => 'mt_adplace_search_img',
				'type' => 'media',
				'title' => esc_html__('Choose image for AdPlace Search', 'mtlisitings'),
				'subtitle' => esc_html__('Use the upload button to import media.', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_search', '=', 'on' )
			),
            array(
                'id' => 'mt_adplace_search_adsense_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'mtlisitings'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'mtlisitings'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'mtlisitings'),
                'required' => array( 'mt_adplace_search', '=', 'on_adsense' ),
                'default' => ''
            ),
		),
	);

	$sections[] = array(
		'title' => esc_html__('AdPlace Category', 'mtlisitings') ,
		'id' => 'mt_adplaces_category',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_adplace_category',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - Category', 'mtlisitings' ),
                'subtitle' => esc_html__( 'Select your "AdPlace Category"', 'mtlisitings' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off' 		 => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_category_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace URL', 'mtlisitings'),
                'subtitle' => esc_html__('Type your AdPlace Category URL.', 'mtlisitings'),
                'required' => array( 'mt_adplace_category', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlisitings'),
                'default' => 'https://'
            ),
			array(
				'id' => 'mt_adplace_category_img',
				'type' => 'media',
				'title' => esc_html__('Choose image for AdPlace Search', 'mtlisitings'),
				'subtitle' => esc_html__('Use the upload button to import media.', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_category', '=', 'on' )
			),
            array(
                'id' => 'mt_adsense_category_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'mtlisitings'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'mtlisitings'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'mtlisitings'),
                'required' => array( 'mt_adplace_category', '=', 'on_adsense' ),
                'default' => ''
            ),
		),
	);

	$sections[] = array(
		'title' => esc_html__('AdPlace ICO List', 'mtlisitings') ,
		'id' => 'mt_adplaces_ico_list',
		'subsection' => true,
		'fields' => array(
            array(
                'id'       => 'mt_adplace_ico_list',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - ICO List', 'mtlisitings' ),
                'subtitle' => esc_html__( 'Select your "AdPlace ICO List"', 'mtlisitings' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off' 		 => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_ico_list_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace URL', 'mtlisitings'),
                'subtitle' => esc_html__('Type your AdPlace ICO List URL.', 'mtlisitings'),
                'required' => array( 'mt_adplace_ico_list', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlisitings'),
                'default' => 'https://'
            ),
        
			array(
				'id' => 'mt_adplace_ico_list_img_1_2',
				'type' => 'media',
				'url' => true,
				'title' => esc_html__('Choose image for AdPlace ICO List 2 ICOs / Row', 'mtlisitings'),
				'subtitle' => esc_html__('Upload Image (1/2) - When the grid shows 2 ICOs / Row', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_ico_list', '=', 'on' )
			),
			array(
				'id' => 'mt_adplace_ico_list_img_1_3',
				'type' => 'media',
				'url' => true,
				'title' => esc_html__('Choose image for AdPlace ICO List 3 ICOs / Row', 'mtlisitings'),
				'subtitle' => esc_html__('Upload Image (1/3) - When the grid shows 3 ICOs / Row', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_ico_list', '=', 'on' )
			),
			array(
				'id' => 'mt_adplace_ico_list_img_1_4',
				'type' => 'media',
				'url' => true,
				'title' => esc_html__('Choose image for AdPlace ICO List 4 ICOs / Row', 'mtlisitings'),
				'subtitle' => esc_html__('Upload Image (1/4) - When the grid shows 4 ICOs / Row', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_ico_list', '=', 'on' )
			),
			array(
				'id' => 'mt_adplace_ico_list_img_slider',
				'type' => 'media',
				'title' => esc_html__('Choose image for AdPlace ICO List Slider', 'mtlisitings'),
				'subtitle' => esc_html__('Upload Image When the grid shows 4 ICO / Row', 'mtlisitings'),
				'compiler' => 'true',
				'required' => array( 'mt_adplace_ico_list', '=', 'on' )
			),
            array(
                'id' => 'mt_adplace_ico_list_adsense_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'mtlisitings'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'mtlisitings'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'mtlisitings'),
                'required' => array( 'mt_adplace_ico_list', '=', 'on_adsense' ),
                'default' => ''
            ),
		),
	);


	return $sections;
	}

// In this example OPT_NAME is the returned opt_name.
add_filter("redux/options/redux_demo/sections", 'mtlisitings_extend_redux_tabs');

?>