<?php
// Silence is golden
