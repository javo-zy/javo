<?php
/**
 * The template for displaying search results pages.
 */
get_header(); 

?>

<?php 

$listing_term_style = get_term_meta( get_queried_object_id(), 'listing_term_style', true );
$term_style = '';
$term_column_map = '';
$term_column_listings = '';
$term_column_single_listing = '';
if(empty($listing_term_style) || $listing_term_style == 'style1') {
    $term_style = 'term-style1';
    $term_column_single_listing = 'col-md-3';
} elseif($listing_term_style == 'style2') {
    $term_style = 'term-style2 row';
    $term_column_map = 'col-md-5';
    $term_column_listings = 'col-md-7';
    $term_column_single_listing = 'col-md-4';
}
?>
<div class="taxonomy-listing-page <?php echo esc_attr($term_style); ?>">
<?php if ( have_posts() ) : ?>

        <!-- MAP PINS ON ARCHIVE -->
        <?php if(function_exists('modeltheme_framework')){ ?>
            <!-- MAP LOCATION -->
            <div class="mt_listings_page mt_listing_map_location <?php echo esc_attr($term_column_map); ?>">
            <?php 

                $gmap_pin = '';
                $api_key = meraki_redux('mt_listings_api_key');
                // Start Map
                $gmap_pin .= '[sbvcgmap map_width="100" map_height="500" zoom="12" scrollwheel="no" pancontrol="no" scalecontrol="no" scalecontrol="no" streetviewcontrol="no" zoomcontrol="yes"  maptypecontrol="no" overviewmapcontrol="no" searchradius="500"  scrollwheel="no sbvcgmap_title="Google Maps" mapstyles="style-55"   sbvcgmap_apikey="'.$api_key.'"]';

                    while ( have_posts() ) : the_post();

                        $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'meraki_listing_archive_thumbnail' );
              
                        if ($thumbnail_src) {
                            $listing_img_pin = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.get_the_title().'" />';
                        } else {
                            $listing_img_pin = '';
                        }

                        $mt_listing_location_address = get_post_meta( get_the_ID(), 'mt_listing_location_address', true );
                        $mt_listing_location_address_pin = '';
                        if($mt_listing_location_address) { 
                            $mt_listing_location_address_pin = $mt_listing_location_address;
                        } 

                        // Get the current category ID, e.g. if we're on a category archive page
                        $categories = wp_get_post_terms(get_the_ID(), 'mt-listing-category2', array("fields" => "all"));
                        foreach($categories as $category) {
                            if ($category) {
                                $image_id = get_term_meta ( $category->term_id, 'category-image-id-v3', true );
                                $mt_map_coordinates = get_post_meta( get_the_ID(), 'mt_map_coordinates', true );
                                if (isset($mt_map_coordinates) && !empty($mt_map_coordinates)) {
                                    if (isset($image_id) && !empty($image_id)) {
                                        $gmap_pin .= '[sbvcgmap_marker animation="DROP" address="'.esc_attr($mt_map_coordinates).'" icon="'.esc_attr($image_id).'"]'.$listing_img_pin.'<a href="'.get_the_permalink().'">'.get_the_title().'</a><p>'.$mt_listing_location_address_pin.'</p>[/sbvcgmap_marker]';
                                    }
                                }
                            }
                        }
                    endwhile;
                // End Map
                $gmap_pin .= '[/sbvcgmap]';
                echo do_shortcode($gmap_pin);
            ?>
            </div>
        <?php } ?>

<?php endif; ?>

<!-- Page content -->
<div class="high-padding-top <?php echo esc_attr($term_column_listings); ?>">
    <!-- Blog content -->

    <?php if(empty($listing_term_style) || $listing_term_style == 'style1') { ?>
        <div class="container">
            <div class="row">
    <?php } ?>

            <div class="mt-listing-search-taxonomy">
                <form method="GET" action="<?php echo home_url( '/' ); ?>">
                  <input type="hidden" name="post_type" value="mt_listing" />

                    <div class="checkboxes-categories col-md-12">  
                        <h3 class="checkboxes-categories-title"><?php echo esc_html__('Sort by Categories ','mtlisitings') ?></h3>                           
                        <?php $terms_c = get_terms( 'mt-listing-category2' );
                        foreach ($terms_c as $term) { ?>
                            <label class="checkbox-inline">
                                <?php 
                                    $checkboxes = '';
                                    $checked = '';
                                    if(isset($_GET['mt-listing-category2'])) {
                                        $checkboxes = $_GET["mt-listing-category2"]; 
                                        if(!empty($checkboxes)) {    
                                            if(is_array($checkboxes)) {
                                                foreach ($checkboxes as $checkbox) {
                                                    if($checkbox == $term->slug) {
                                                        $checked = 'checked';
                                                    }                           
                                                } 
                                            } else {
                                                if($checkboxes == $term->slug) {
                                                     $checked = 'checked';
                                                }
                                            }                                                           
                                        }
                                    }
                                    
                                ?>
                                <input type="checkbox" name="mt-listing-category2[]" <?php echo $checked; ?> value="<?php echo $term->slug; ?>">
                                <span class="checkmark"></span>
                                <?php echo $term->name; ?>
                            </label>
                        <?php } ?>                     
                    </div>

                    <div class="state-search col-md-4">
                      <input type="search" class="search-field form-control" placeholder="<?php echo esc_attr_x( 'What are you searching ...', 'mtlisitings' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                    </div>
 
                    
                    <div class="select-locations col-md-4">
                      <select name="mt-listing-category" class="select-car-category form-control">';
                        <option value=''><?php echo esc_attr__('Locations', 'mtlisitings'); ?></option>
                        <?php
                            $terms_l = get_terms( 'mt-listing-category' );
                            foreach ($terms_l as $term) {
                                if ($term->parent == 0) { ?>
                                    <option value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
                                <?php }
                            }
                        ?>
                      </select>
                    </div> 

                    
                    <div class="state-submit col-md-4 submit">
                        <button type="submit" class="form-control btn btn-success"><?php echo esc_html__('Search', 'mtlisitings'); ?></button>
                    </div> 

                </form>

            </div>

            <div class="main-content">

                
                <?php if ( have_posts() ) : ?>
                    <div class="row">
                        <?php /* Start the Loop */ ?>
                        <?php $i = 1; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php include('content-listing-archive.php');  ?>

                            <?php $i++; ?>

                        <?php endwhile; ?>

                        <div class="modeltheme-pagination-holder col-md-12">             
                            <div class="modeltheme-pagination pagination">             
                                <?php the_posts_pagination(); ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <?php get_template_part( 'content', 'none' ); ?>
                <?php endif; ?>
            </div>
    <?php if(empty($listing_term_style) || $listing_term_style == 'style1') { ?>        
       </div>
    </div>
    <?php } ?>
</div>
</div>
<?php get_footer(); ?>