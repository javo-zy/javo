<?php 
/**
* Template for Listings
* Used in: taxonomy-mt-car-category.php, taxonomy-mt-car-features.php, taxonomy-mt-car-type.php, search.php
**/
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>

  <?php 
      global  $dynamic_featured_image;
      $featured_images = $dynamic_featured_image->get_featured_images( get_the_ID() ); 
  ?>

  <div class="mt_listing_header_section container">
    <div class="listing_header_section col-md-10">
    <?php 
        $term = wp_get_object_terms( get_the_ID(), 'mt-listing-category2', array( 'fields' => 'all' ) );
        if($term) {
          $img_id_1 = get_term_meta( $term[0]->term_id, 'category-image-id', true );
        }
        
    ?>

    <?php if(!empty($img_id_1)) { ?>
      <div class="category_icon_holder">
        <img class="cat-icon" src="<?php echo wp_get_attachment_url($img_id_1); ?>">
      </div>
    <?php } ?>

    <h1 class="list_title">
      <?php echo get_the_title(); ?>
    </h1>

    <div class="clearfix"></div>

    <p class="list_description">
      <?php echo the_content(); ?>
    </p>

    <div class="single_list_share_this">

      <div class="list_share_this">
        <span><?php echo esc_html__('Share this ','mtlisitings'); ?><i class="fa fa-share-alt"></i></span>
      </div>

      <?php 
      echo '<div class="single-ico-social-sharer-tooltip"><ul class="single-ico-social-sharer">
        <li class="facebook">
            <a  title="'.esc_html__('Share on Facebook','mtlisitings').'"  href="http://www.facebook.com/share.php?u='.get_permalink().'&amp;title='.get_the_title().'"><i class="fa fa-facebook"></i></a>
        </li>
        <li class="twitter">
            <a  title="'.esc_html__('Share on Twitter','mtlisitings').'"  href="http://twitter.com/home?status='.get_the_title().'+'.get_permalink().'"><i class="fa fa-twitter"></i></a>
        </li>
        <li class="linkedin">
            <a  title="'.esc_html__('Share on LinkedIn','mtlisitings').'"  href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.get_permalink().'&amp;title='.get_the_title().'&amp;source='.get_permalink().'"><i class="fa fa-linkedin"></i></a>
        </li>
        <li class="google-plus">
            <a  title="'.esc_html__('Share on Google','mtlisitings').'"  href="https://plus.google.com/share?url='.get_permalink().'"><i class="fa fa-google"></i></a>
        </li>
        <li class="pinterest">
            <a  title="'.esc_html__('Pin on Pinterest','mtlisitings').'"  href="http://pinterest.com/pin/create/bookmarklet/?media='.get_permalink().'&url='.get_permalink().'&is_video=false&description='.get_permalink().'"><i class="fa fa-pinterest-p"></i></a>
        </li>
        <li class="reddit">
            <a  title="'.esc_html__('Share on Reddit','mtlisitings').'"  href="http://www.reddit.com/submit?url='.get_permalink().'&amp;title='.get_the_title().'"><i class="fa fa-reddit-alien"></i></a>
        </li>
        <li class="tumblr">
            <a  title="'.esc_html__('Share on Tumblr','mtlisitings').'"  href="http://www.tumblr.com/share?v=3&amp;u='.get_permalink().'&amp;t='.get_the_title().'"><i class="fa fa-tumblr"></i></a>
        </li>
      </ul></div>'; ?>

    </div>
    <?php $mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); ?> 
    <?php $mt_listing_sponsored_status_clss = ''; ?>
    <?php if($mt_listing_sponsored_status == 'sponsored_listing') { ?>
        <div class="listing_sponsored_bolt">
          <span class="listing_sponsored_status" title="Sponsored Listing"><i class="fa fa-bolt" aria-hidden="true"></i></span>
        </div>      
    <?php } ?>
  </div>
    <div class="embed col-md-2 col-xs-12">
        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#embed-modal" id="frontend-button"><?php echo esc_html__('Apply Now','mtlisitings') ?></button>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="embed-modal" role="dialog">
      <div class="modal-dialog">
      
        <!-- Modal content-->
        <div class="embed-modal-content modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><?php echo esc_html__('Apply For This Job','mtlisitings'); ?></h4>
          </div>
          <div class="modal-body">
              <div class="modal-body-view">
                  <?php require_once( ABSPATH . 'wp-content/plugins/modeltheme-listings-manager/inc/templates/template-add-edit-application.php' );?>
                  </div>
              </div>
              
          </div>
        </div>
        
      </div>
    </div>

  

    <?php $mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); ?> 
    <?php $mt_listing_sponsored_status_clss = ''; ?> 
    <?php $mt_listing_type = get_post_meta( get_the_ID(), 'mt_listing_type', true ); ?> 
    <?php $mt_listing_salary = get_post_meta( get_the_ID(), 'mt_listing_salary', true ); ?>
    <?php $mt_listing_level = get_post_meta( get_the_ID(), 'mt_listing_level', true ); ?> 
    <?php $mt_listing_experience = get_post_meta( get_the_ID(), 'mt_listing_experience', true ); ?>
    <?php $mt_job_icon = get_post_meta( get_the_ID(), 'smartowl_header_custom_logo', true ); ?> 
    <?php $categories = get_the_term_list( get_the_ID(), 'mt-listing-category2', '', ', ' ); ?>
    <?php $types = get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', ' ); ?>

  </div>

  <div class="mt_listing_content_parent">
    <div class="mt_listing_content container">
      <div class="row">

        <div class="col-md-8 mt_listing_content_section_part">

          <div class="mt_information_listing_section">

              <h3 class="mt_listing_content_heading"><?php echo esc_html__('Job Information','mtlisitings'); ?></h3>

                <div class="row about_job_content">
                    <div class="col-md-4 col-xs-4 single-info-job">
                      <div class="col-md-4">
                        <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                      </div>
                      <div class="col-md-8">
                          <h4><?php echo esc_html('Category','mtlisitings'); ?></h4>
                          <p class="amenities-item"><?php echo $categories ?></p>
                      </div>
                    </div>

                    <?php if(($mt_listing_type)) { ?>
                        <div class="col-md-4 col-xs-4 single-info-job">
                            <div class="col-md-4">
                              <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                            </div>

                            <div class="col-md-8">
                              <h4><?php echo esc_html('Job Type','mtlisitings'); ?></h4>
                              <p class="amenities-item"><?php echo $types ?></p>
                            </div>
                        </div>
                    <?php } ?>

                    <div class="col-md-4 col-xs-4 single-info-job">
                      <div class="col-md-4">
                          <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                      </div>
                      <div class="col-md-8">
                          <h4><?php echo esc_html('Posted on','mtlisitings'); ?></h4>
                          <p class="amenities-item"><?php echo get_the_date(); ?></p>
                      </div>
                    </div>

                    <?php if(($mt_listing_salary)) { ?>
                        <div class="col-md-4 col-xs-4 single-info-job">
                          <div class="col-md-4">
                             <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                          </div>
                          <div class="col-md-8">
                              <h4><?php echo esc_html('Salary','mtlisitings'); ?></h4>
                              <p class="amenities-item"><?php echo ($mt_listing_salary); ?></p>
                          </div>
                        </div>
                    <?php } ?>

                    <?php if(($mt_listing_level)) { ?>
                        <div class="col-md-4 col-xs-4 single-info-job">
                          <div class="col-md-4">
                             <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                          </div>
                          <div class="col-md-8">
                              <h4><?php echo esc_html('Job Level','mtlisitings'); ?></h4>
                              <p class="amenities-item"><?php echo ($mt_listing_level); ?></p>
                          </div>
                        </div>
                    <?php } ?>

                    <?php if(($mt_listing_experience)) { ?>
                        <div class="col-md-4 col-xs-4 single-info-job">
                          <div class="col-md-4">
                              <img src="<?php echo esc_url(meraki_redux('mt_job_icon','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                          </div>
                          <div class="col-md-8">
                              <h4><?php echo esc_html('Experience','mtlisitings'); ?></h4>
                              <p class="amenities-item"><?php echo ($mt_listing_experience); ?></p>
                          </div>
                        </div>
                    <?php } ?>

                </div>

          </div>

          <div class="about_listing_section">

            <?php $mt_listing_about_listing_title = get_post_meta( get_the_ID(), 'mt_listing_about_listing_title', true ); ?>
            <?php $mt_listing_description_long = get_post_meta( get_the_ID(), 'mt_listing_description_long', true ); ?>

            <h3 class="mt_listing_content_heading"><?php echo esc_html__('Best Canditate', 'mtlisitings'); ?></h3>
            
            <?php if(empty(get_the_excerpt()) || empty(the_content())) { ?>
              <div class="alert alert-success">
                  <strong><?php esc_html__('This Listing has no description! ', 'mtlisitings') ?></strong>
                  <?php esc_html__(' Please add description to this specify listing.', 'mtlisitings'); ?>
              </div>
            <?php } else { ?>
              <div class="mt_listing_content_description_job"><?php echo $mt_listing_description_long; ?></div>
            <?php } ?>

          </div>

          <div class="listing_features_section">

            <?php $mt_listing_listing_features_title = get_post_meta( get_the_ID(), 'mt_listing_listing_features_title', true ); ?>
            <?php $term_list = wp_get_post_terms( get_the_ID() , 'mt-listing-amenities', array("fields" => "all")); ?>
            <?php $mt_listing_listing_features_description = get_post_meta( get_the_ID(), 'mt_listing_listing_features_description', true ); ?>


            <?php if(!empty($mt_listing_listing_features_title)) { ?>
              <h3 class="mt_listing_content_heading"><?php echo $mt_listing_listing_features_title; ?></h3>
            <?php } else { ?>
              <h3 class="mt_listing_content_heading"><?php echo esc_html__('Listing Features','mtlisitings'); ?></h3>
            <?php } ?>

            <div class="mt_listing_content_description"><p><?php echo $mt_listing_listing_features_description; ?></p></div>


            <?php if(empty($term_list)) { ?>
              <div class="alert alert-success">
                  <strong><?php esc_html__('This Listing has no listing features! ', 'mtlisitings') ?></strong>
                  <?php esc_html__(' Please add listing features to this specify listing.', 'mtlisitings'); ?>
              </div>
            <?php } ?>


          </div>

          <div class="listing_features_section">

              <?php $mt_listing_description_company = get_post_meta( get_the_ID(), 'mt_listing_description_company', true ); ?>
              <?php $mt_listing_company_name = get_post_meta( get_the_ID(), 'mt_listing_company_name', true ); ?>
              <?php $mt_listing_image = get_post_meta( get_the_ID(), 'mt_listing_image', true ); ?>

              <?php if(!empty($mt_listing_company_name)) { ?>
                <h3 class="mt_listing_content_heading">About <?php echo $mt_listing_company_name; ?></h3>
              <?php } else { ?>
              <h3 class="mt_listing_content_heading"><?php echo esc_html__('About Company','mtlisitings'); ?></h3>
            <?php } ?>

              <div class="mt_listing_content_description"><p><?php echo $mt_listing_description_company; ?></p></div>

          </div>
          <div class="listing_tags_section">

            <?php $tags_list = wp_get_post_terms( get_the_ID() , 'mt-listing-tags', array("fields" => "all")); ?>
            
            <h3 class="mt_listing_content_heading"><?php esc_html__('Jobs Tags', 'mtlisitings') ?></h3>

            <?php if(empty($tags_list)) { ?>
              <div class="alert alert-success">
                  <strong><?php esc_html__('This Listing has no tags! ', 'mtlisitings') ?></strong>
                  <?php esc_html__(' Please add tags to this specify listing.', 'mtlisitings'); ?>
              </div>
            <?php } ?>

            <?php foreach ($tags_list as $tag) { ?>
                  <a class="button-winona btn btn-sm"href="<?php echo get_term_link($tag->slug, 'mt-listing-tags'); ?>"><i class="fa fa-tag" aria-hidden="true"></i> <?php echo $tag->name; ?></a>
            <?php } ?>

          </div>
          

        </div> <!-- mt_listing_content_section_part -->

        <div class="col-md-4 mt_listing_content_sidebar_part">
          <div class="mt_listing_content_sidebar_part_author_listing">

              <div class="mt_listing_content_sidebar_part_author_listing_inner">
                <?php $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),350); ?>
                <a class="author_listing_avatar" href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )); ?>">
                     <img class="post_image" src="<?php echo esc_url($thumbnail_src[0]) ?>"  />
                </a>
              </div>

              <?php $phone = get_user_meta(get_the_author_meta( 'ID' ),'billing_phone',true);  ?>
              <?php $email = get_user_meta(get_the_author_meta( 'ID' ),'billing_email',true);  ?>
              <?php $mt_user_facebook = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_facebook',true);  ?>
              <?php $mt_user_instagram = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_instagram',true);  ?>
              <?php $mt_user_youtube = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_youtube',true);  ?>
              <?php $mt_listing_company_name = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_youtube',true);  ?>


              <?php if($phone || $email) { ?>

                <div class="mt_listing_content_sidebar_bottompart_author_listing_inner">
                  <h4 class="mt_listing_content_heading">
                    <h3><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )); ?>">
                      <?php echo esc_html(get_the_author()); ?>           
                    </a></h3>
                  </h4>
                  <ul class="listing-details-author-info">
                    <li><i class="fa fa-phone" aria-hidden="true"></i> <?php echo esc_html($phone); ?></li>
                    <li><i class="fa fa-envelope"></i><a href="mailto:<?php echo esc_html($email); ?>"><?php echo esc_html($email); ?></a></li>
                  </ul>
                </div>
              <?php } ?>


            </div>
          <div class="mt_listing_content_sidebar_part_contact_info">
            <?php if(function_exists('modeltheme_framework')){ ?>
                <!-- MAP LOCATION -->
                <div class="mt_listings_page mt_listing_map_location">
                <?php 

                    $gmap_pin = '';

                    $api_key = '';
                    $api_key = meraki_redux('mt_listings_api_key');
                    // Start Map
                    $gmap_pin .= '[sbvcgmap sbvcgmap_apikey="'.$api_key.'" pancontrol="no" scalecontrol="no" streetviewcontrol="no" maptypecontrol="no" overviewmapcontrol="no" map_width="100" map_height="340" mapstyles="style-55" zoom="12" scrollwheel="no" searchradius="500" sbvcgmap_title="Google Maps"]';
                            // Get the current category ID, e.g. if we're on a category archive page
                            $category = wp_get_post_terms(get_the_ID(), 'mt-listing-category2', array("fields" => "all"));
                            if ($category) {
                                $image_id = get_term_meta ( $category[0]->term_id, 'category-image-id-v3', true );
                                $mt_map_coordinates = get_post_meta( get_the_ID(), 'mt_map_coordinates', true );
                                if (isset($mt_map_coordinates) && !empty($mt_map_coordinates)) {
                                    if (isset($image_id) && !empty($image_id)) {
                                        $gmap_pin .= '[sbvcgmap_marker animation="DROP" address="'.esc_attr($mt_map_coordinates).'" icon="'.esc_attr($image_id).'"]<a href="'.get_the_permalink().'">'.get_the_title().'</a>[/sbvcgmap_marker]';
                                    }
                                }
                            }
                    // End Map
                    $gmap_pin .= '[/sbvcgmap]';
                    echo do_shortcode($gmap_pin);
                ?>
                </div>
            <?php } ?>
            <div class="mt_listing_content_sidebar_part_contact_info_details">
              <?php $locations = wp_get_post_terms( get_the_ID() , 'mt-listing-category', array("fields" => "all")); ?>

              <?php foreach ($locations as $location) { ?>
                <h3 class="mt_listing_content_heading""><?php echo $location->name; ?></h3>
              <?php } ?>

              <?php $mt_listing_location_address = get_post_meta( get_the_ID(), 'mt_listing_location_address', true ); ?>
              <?php $mt_listing_phone_number = get_post_meta( get_the_ID(), 'mt_listing_phone_number', true ); ?>
              <?php $mt_listing_mail_address = get_post_meta( get_the_ID(), 'mt_listing_mail_address', true ); ?>
              <?php $mt_listing_website_listing = get_post_meta( get_the_ID(), 'mt_listing_website_listing', true ); ?>

              <?php if($mt_listing_location_address) { ?>
                <p><?php echo $mt_listing_location_address; ?></p>
              <?php } ?>

              <?php if(empty($mt_listing_phone_number) || empty($mt_listing_mail_address) || empty($mt_listing_website_listing)) { ?>
                <div class="alert alert-success">
                    <strong><?php esc_html__('This Listing has no contact details! ', 'mtlisitings') ?></strong>
                    <?php esc_html__(' Please add contact details to this specify listing.', 'mtlisitings'); ?>
                </div>
              <?php } ?>

            </div>

          </div> <!-- mt_listing_content_sidebar_part_contact_info -->

            


            


        </div> <!-- mt_listing_content_sidebar_part -->
        
      </div> <!-- row -->
    </div> <!-- mt_listing_content -->
  </div> <!-- mt_listing_content_parent -->



</article>