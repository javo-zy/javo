<?php
/**
 * Template Name: Add/Edit application
 *
 */
require_once( ABSPATH . 'wp-admin/includes/post.php' );
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/media.php' );
require_once(ABSPATH . 'wp-admin/includes/admin.php');
$success_messaje = '';
global $current_user;
$wordpress_loop_argument = array('post_type' => 'mt_application', 'posts_per_page' => -1);
$wordpress_loop = new WP_Query( $wordpress_loop_argument );
 
	if (isset($_POST['add-application'])) {
		
		if (isset($_GET['application_id'])) {
			$my_application = array(
			  'ID'           =>  $_GET['application_id'],
			  'post_title'    => $_POST['mt_applicant_name'],
			  'post_content'  => $_POST['details'],
			  'post_type'     => 'mt_application'
			);
			
			$pid = wp_update_post( $my_application );
			$success_messaje = '<div class="alert alert-success"><strong>'.esc_html__('The application named "'.$_POST['mt_applicant_name'].'" is updated','mtlisitings').'</strong></div>';	
		} else {
			$my_application = array(
			  'post_title'    => $_POST['mt_applicant_name'],
			  'post_content'  => $_POST['details'],
			  'post_status'   => 'publish',
			  'post_type'     => 'mt_application'
			);
			$pid = wp_insert_post( $my_application );
			$success_messaje = '<div class="alert alert-success"><strong>'.esc_html__('The application sent by "'.$_POST['mt_applicant_name'].'" have been sent succesfully!','mtlisitings').'</strong></div>';	
		}
		/* Applicant email */
		if (isset($_POST['mt_applicant_email'])) {
			update_post_meta($pid,'mt_applicant_email',$_POST['mt_applicant_email']);
		}
		/* Applicant phone number */
		if (isset($_POST['mt_applicant_phone'])) {
			update_post_meta($pid,'mt_applicant_phone',$_POST['mt_applicant_phone']);
		}
		/* Applicant attachment */
	    if (isset($_POST['mt_applicant_attach'])) {
			update_post_meta($pid,'mt_applicant_attach',$_POST['mt_applicant_attach']);
		}

		if (isset($_POST['job-id'])) {
    		update_post_meta($pid,'mt_application_listing',$_POST['job-id']);
  		}
		/* application Image */
		if(isset($_POST['group_pictures'])) {
			$group_pictures_string = $_POST['group_pictures'];
			$group_pictures_array = explode(',', $group_pictures_string);
					
			$count = 0;
			foreach ($group_pictures_array as $picture_id) {
				
				if($count == 0) {
					$image_name = wp_get_attachment_url($picture_id);  
			        $filetype = wp_check_filetype( basename( $image_name ), null );
			        $wp_upload_dir = wp_upload_dir();
			        $attachment = array(
			            'guid'           => $wp_upload_dir['url'] . '/' . basename( $image_name ), 
			            'post_mime_type' => $filetype['type'],
			            'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $image_name ) ),
			            'post_content'   => '',
			            'post_status'    => 'inherit'
			        );
			        $attach_id = get_attachment_id($image_name);
					if (is_numeric($attach_id)) {
					    update_option('option_image', $attach_id);
					    update_post_meta($pid, '_mt_listing_image', $attach_id);
					}
			        
			        $attach_data = wp_generate_attachment_metadata( $attach_id, $image_name );
			        wp_update_attachment_metadata( $attach_id, $attach_data );       
			        set_post_thumbnail( $pid, $attach_id );
				
				} else {
				    echo 'Rest: '. $picture_id;
				}
				$count++;
			}
			
 		}
	
	} ?>
				<?php if (isset($_GET['application_id'])) { ?>
					<?php $application_id = $_GET['application_id']; ?>	
					<form id="add-new-listing" class="add-new-listing-form" method="POST" enctype="multipart/form-data">
						<div class="succes-message"><?php echo wp_kses_post($success_messaje); ?></div>
						<div class="form-group">
							<label for="mt_applicant_name"><?php  echo esc_html__('Your Name','mtlisitings'); ?></label>
							<input type="text" class="form-control listing-title" name="mt_applicant_name" value="<?php echo esc_attr(get_the_title($application_id)); ?>" placeholder="<?php esc_attr__('Your Event Name','mtlisitings'); ?>">
						</div>
						<div class="form-group">
							<label for="mt_applicant_email"><?php  echo esc_html__('Your Email','mtlisitings'); ?></label>
							<?php $mt_email = get_post_meta( $application_id, 'mt_applicant_email', true ); ?>
							<input type="text" class="form-control listing-title" name="mt_applicant_email" value="<?php echo $mt_email; ?>" placeholder="<?php esc_attr__('Email address','mtlisitings'); ?>">
						</div>
						<div class="form-group">
							<label for="mt_applicant_phone"><?php  echo esc_html__('Your Phone Number','mtlisitings'); ?></label>
							<?php $mt_phone = get_post_meta( $application_id, 'mt_applicant_phone', true ); ?>
							<input type="text" class="form-control listing-title" name="mt_applicant_phone" value="<?php echo $mt_phone; ?>" placeholder="<?php esc_attr__('Phone Number','mtlisitings'); ?>">
						</div>	
						<div class="form-group">
							<label for="details"><?php echo esc_html__('Description','mtlisitings'); ?></label>
							<textarea class="form-control" placeholder="<?php esc_attr__('Enter details about your event','mtlisitings'); ?>" name="details"><?php echo get_post_field('post_content', $application_id); ?></textarea>
						</div>	
						<div class="form-group pull-right">
							<button type="submit" class="button-listing" name="add-application" class="btn btn-success"><?php echo esc_attr__('Update application','mtlisitings')?></button>
						</div>
					</form>
				<?php } else { ?>
					<form id="add-new-listing" method="POST" enctype="multipart/form-data">
						<?php echo wp_kses_post($success_messaje); ?>
						<div class="form-group">
							<input type="hidden" name="job-id" value="<?php echo get_the_ID(); ?>">
							<input type="text" class="form-control application-title" name="mt_applicant_name" value="" placeholder="<?php echo esc_attr__( 'Your Name', 'mtlisitings' ); ?>">
							<input type="hidden" name="job-com" value="<?php echo get_the_author(); ?>">
						</div>
						<div class="form-group">
							<input type="text" class="form-control application-title" name="mt_applicant_email" value="" placeholder="<?php echo esc_attr__( 'Your Email', 'mtlisitings' ); ?>">
						</div>
						<div class="form-group">
							<input type="text" class="form-control application-title" name="mt_applicant_phone" value="" placeholder="<?php echo esc_attr__( 'Your Phone Number', 'mtlisitings' ); ?>">
						</div>
						<div class="form-group">
							<textarea class="form-control" placeholder="<?php echo esc_attr__( 'A few words about you', 'mtlisitings' ); ?>" name="details"></textarea>
						</div>	
						<div class="form-group">

							<?php $allowed_roles = array('editor', 'administrator', 'author', 'customer'); ?>
							<?php if( array_intersect($allowed_roles, $current_user->roles ) ) { ?>
								<input id="upload_image_button" class="button-attachment" type="button" value="<?php echo esc_attr__( 'Upload', 'mtlisitings' ); ?>" /> 
        						<input id="upload_image" type="text" size="36" name="mt_applicant_attach" value="<?php echo esc_attr__( 'Attach CV', 'mtlisitings' ); ?>" />
        					<?php } ?>

							<?php
							add_action('admin_enqueue_scripts', 'my_admin_scripts');

							function my_admin_scripts() {
							    if (isset($_GET['page']) && $_GET['page'] == 'my_plugin_page') {
							        wp_enqueue_media();
							        wp_register_script('my-admin-js', WP_PLUGIN_URL.'/my-plugin/my-admin.js', array('jquery'));
							        wp_enqueue_script('my-admin-js');
							    }
							}
							?>
							<script>
							    jQuery(document).ready(function($){
							    var custom_uploader;

							    $('#upload_image_button').click(function(e) {
							        e.preventDefault();
							        //If the uploader object has already been created, reopen the dialog
							        if (custom_uploader) {
							            custom_uploader.open();
							            return;
							        }
							        //Extend the wp.media object
							        custom_uploader = wp.media.frames.file_frame = wp.media({
							            title: 'Choose Document',
							            button: {
							                text: 'Choose Document'
							            },
							            multiple: true
							        });
							        //When a file is selected, grab the URL and set it as the text field's value
							        custom_uploader.on('select', function() {
							            console.log(custom_uploader.state().get('selection').toJSON());
							            attachment = custom_uploader.state().get('selection').first().toJSON();
							            $('#upload_image').val(attachment.url);
							        });
							        //Open the uploader dialog
							        custom_uploader.open();
							    });
							});
						</script>
						</div>
						<div class="form-group pull-right">
							<button type="submit" class="button-listing" name="add-application" class="btn btn-success"><?php echo esc_attr__('Submit Application','mtlisitings') ?></button>
						</div>
					</form>
				<?php } ?>
