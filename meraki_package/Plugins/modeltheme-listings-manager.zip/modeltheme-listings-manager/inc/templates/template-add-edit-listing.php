<?php
/**
 * Template Name: Add/Edit Listing
 *
 */

require_once( ABSPATH . 'wp-admin/includes/post.php' );
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/media.php' );
require_once(ABSPATH . 'wp-admin/includes/admin.php');

$success_messaje = '';

if ( is_user_logged_in() ){ 

	$current_user = wp_get_current_user();
	if (isset($_POST['add-listing'])) {
		
		if (isset($_GET['listing_id'])) {

			$my_listing = array(
			  'ID'           =>  $_GET['listing_id'],
			  'post_title'    => $_POST['mt_listing_name'],
			  'post_content'  => $_POST['details'],
			  'post_author'   => $current_user->ID,
			  'post_type'     => 'mt_listing'
			);
			
			$pid = wp_update_post( $my_listing );

			$success_messaje = '<div class="alert alert-success"><strong>'.esc_html__('The Job named "'.$_POST['mt_listing_name'].'" is updated','mtlisitings').'</strong></div>';	

		} else {

			$my_listing = array(
			  'post_title'    => $_POST['mt_listing_name'],
			  'post_content'  => $_POST['details'],
			  'post_status'   => 'publish',
			  'post_author'   => $current_user->ID,
			  'post_type'     => 'mt_listing'
			);

			$pid = wp_insert_post( $my_listing );

			$success_messaje = '<div class="alert alert-success"><strong>'.esc_html__('Your Job named "'.$_POST['mt_listing_name'].'" have been posted on the website.','mtlisitings').'</strong></div>';	

		}

		$script_concatanate = '';

		/* Listing Features Title */
		if (isset($_POST['mt_listing_features_title'])) {
			update_post_meta($pid,'mt_listing_listing_features_title',$_POST['mt_listing_features_title']);
		}

		/* Listing Features Description */
		if (isset($_POST['mt_listing_features_description'])) {
			update_post_meta($pid,'mt_listing_listing_features_description',$_POST['mt_listing_features_description']);
		}

		/* Best Canditate Description */
		if (isset($_POST['mt_listing_description_long'])) {
			update_post_meta($pid,'mt_listing_description_long',$_POST['mt_listing_description_long']);
		}

		/* Job openings Description */
		if (isset($_POST['mt_listing_salary'])) {
			update_post_meta($pid,'mt_listing_salary',$_POST['mt_listing_salary']);
		}

		/* Job level Description */
		if (isset($_POST['mt_listing_level'])) {
			update_post_meta($pid,'mt_listing_level',$_POST['mt_listing_level']);
		}

		/* Job openings Description */
		if (isset($_POST['mt_listing_experience'])) {
			update_post_meta($pid,'mt_listing_experience',$_POST['mt_listing_experience']);
		}

		/* Name of company */
		if (isset($_POST['mt_listing_company_name'])) {
			update_post_meta($pid,'mt_listing_company_name',$_POST['mt_listing_company_name']);
		}

		/* About company */
		if (isset($_POST['mt_listing_description_company'])) {
			update_post_meta($pid,'mt_listing_description_company',$_POST['mt_listing_description_company']);
		}

		/* Listing amenities */
		if(!empty($_POST['mt-features'])){
			$features_array = array();
			foreach($_POST['mt-features'] as $feature){
				$features_array[] = $feature;
			}
			$features_array = array_map( 'intval', $features_array );
			wp_set_object_terms( $pid, $features_array, 'mt-listing-amenities', false );
					
		}

		/* Listing tags */
		if(!empty($_POST['mt-tags'])){
			$tags_array = array();
			foreach($_POST['mt-tags'] as $tag){
				$tags_array[] = $tag;
			}
			$tags_array = array_map( 'intval', $tags_array );
			wp_set_object_terms( $pid, $tags_array, 'mt-listing-tags', false );
		
		}
		// Check if $_GET isset
	    if ( class_exists( 'ReduxFrameworkPlugin' )  && function_exists('mtlisitings_framework')) {
		    if (isset($_GET['postid'])) {
		    	// disable the post.
		    	// this sends the post to trash.
				echo meraki_delete_post($_GET['postid'], $devmode = meraki_redux('mt_listings_devmode'));
			}
	    }

		/* Listing locations */
		if ( $_POST['listing_locations'] != 0 ) {
			wp_set_object_terms( $pid, intval($_POST['listing_locations']), 'mt-listing-category', false );
		} 

		/* Listing locations input */
		if ( $_POST['listing_locations_other']) {
			wp_insert_term($_POST['listing_locations_other'], 'mt-listing-category');
			wp_set_object_terms( $pid, $_POST['listing_locations_other'], 'mt-listing-category', false );
		}

		/* Listing category select */
		if ( $_POST['listing_categories'] != 0 ) {
			wp_set_object_terms( $pid, intval($_POST['listing_categories']), 'mt-listing-category2', false );
		} 

		/* Listing category input */
		if ( $_POST['listing_categories_other']) {
			wp_insert_term($_POST['listing_categories_other'], 'mt-listing-category2');
			wp_set_object_terms( $pid, $_POST['listing_categories_other'], 'mt-listing-category2', false );
		}

		/* Listing type select */
		if ( $_POST['listing_types'] != 0 ) {
			wp_set_object_terms( $pid, intval($_POST['listing_types']), 'mt-listing-type', false );
		} 

		/* Listing location address */
		if (isset($_POST['listing_location_address'])) {
			update_post_meta($pid,'mt_listing_location_address',$_POST['listing_location_address']);
		}

		/* Listing location coordinates */
		if (isset($_POST['listing_location_coordinates'])) {
			update_post_meta($pid,'mt_map_coordinates',$_POST['listing_location_coordinates']);
		}

		/* Listing location phone number */
		if (isset($_POST['listing_phone_number'])) {
			update_post_meta($pid,'mt_listing_phone_number',$_POST['listing_phone_number']);
		}

		/* Listing location mail address */
		if (isset($_POST['listing_mail_address'])) {
			update_post_meta($pid,'mt_listing_mail_address',$_POST['listing_mail_address']);
		}

		/* Listing mail address */
		if (isset($_POST['listing_website_link'])) {
			update_post_meta($pid,'mt_listing_website_listing',$_POST['listing_website_link']);
		}

		/* Listing facebook link */
		if (isset($_POST['listing_facebook_link'])) {
			update_post_meta($pid,'mt_listing_facebook',$_POST['listing_facebook_link']);
		}

		/* Listing linkedin link */
		if (isset($_POST['listing_linkedin_link'])) {
			update_post_meta($pid,'mt_listing_linkedin',$_POST['listing_linkedin_link']);
		}

		/* Listing twitter link */
		if (isset($_POST['listing_twitter_link'])) {
			update_post_meta($pid,'mt_listing_twitter',$_POST['listing_twitter_link']);
		}

		/* Listing facebook link */
		if (isset($_POST['listing_youtube_link'])) {
			update_post_meta($pid,'mt_listing_youtube',$_POST['listing_youtube_link']);
		}

		/* Listing Video Presentation */
		if (isset($_POST['mt_listing_video_presentation'])) {
			update_post_meta($pid,'mt_video_tour',$_POST['mt_listing_video_presentation']);
		}

		/* Listing Image */

		if(isset($_POST['group_pictures'])) {
			$group_pictures_string = $_POST['group_pictures'];
			$group_pictures_array = explode(',', $group_pictures_string);
					
			$count = 0;
			foreach ($group_pictures_array as $picture_id) {
				
				if($count == 0) {

					$image_name = wp_get_attachment_url($picture_id);  
			        $filetype = wp_check_filetype( basename( $image_name ), null );
			        $wp_upload_dir = wp_upload_dir();
			        $attachment = array(
			            'guid'           => $wp_upload_dir['url'] . '/' . basename( $image_name ), 
			            'post_mime_type' => $filetype['type'],
			            'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $image_name ) ),
			            'post_content'   => '',
			            'post_status'    => 'inherit'
			        );


			        $attach_id = get_attachment_id($image_name);
					if (is_numeric($attach_id)) {
					    update_option('option_image', $attach_id);
					    update_post_meta($pid, '_mt_listing_image', $attach_id);
					}

			        //$attach_id = wp_insert_attachment( $attachment, $wp_upload_dir['path'] .'/'. $image_name, $pid );
			        
			        $attach_data = wp_generate_attachment_metadata( $attach_id, $image_name );

			        wp_update_attachment_metadata( $attach_id, $attach_data );       

			        set_post_thumbnail( $pid, $attach_id );
				
				} else {

				    //echo 'Rest: '. $picture_id;

				}
				$count++;
			}
			
 		}

	}
}else{ ?>
	<script type="text/javascript">
		window.location.href = "<?php echo get_permalink( meraki_redux('mt_listings_account_link2') ); ?>";
	</script>
<?php } ?>


<?php get_header(); ?>

<?php echo wp_kses_post(meraki_header_title_breadcrumbs()); ?>

<div id="main-content" class="main-content">

	<div id="primary" class="content-area">

		<div id="content" class="site-content container high-padding">

			<div class="row">

				<?php if (isset($_GET['listing_id'])) { ?>

					<?php $listing_id = $_GET['listing_id']; ?>	

					<form id="listing-role" class="add-new-listing-form" action="" method="POST" >

						<?php if (isset($_POST['draft'])) { ?>
						<div class="succes-message">
										<?php toDraft($listing_id); ?>
						 </div><?php } else if (isset($_POST['publish'])){?>
						 <div class="approved-message">
										<?php toPublish($listing_id); ?>
						 </div><?php }?>

						<div class="form-group">
							<label for="details"><?php echo esc_html__('Disable/Enable your Job','mtlisitings'); ?></label>
							<div class="clearfix">
								<label class="switch">
								<div class="slider round">
									<input type="submit" class="slider round" value="OFF" name="draft">
										
										<span class="off"><?php echo esc_html__('OFF','mtlisitings') ?></span>
									</div>
								</label>
								<label class="switch">
								<div class="slider round green">
									<input type="submit"  class="slider round" value="ON" name="publish">
										
										<span class="off"><?php echo esc_html__('ON','mtlisitings') ?></span>
									</div>
								</label>
							</div>
						</div>
					</form>
					

					<form id="add-new-listing" class="add-new-listing-form" method="POST" enctype="multipart/form-data">

						<div class="form-group">
							<label for="mt_listing_name"><?php  echo esc_html__('Job Opening Title','mtlisitings'); ?></label>
							<input type="text" class="form-control listing-title" name="mt_listing_name" value="<?php echo esc_attr(get_the_title($listing_id)); ?>" value="" placeholder="<?php esc_attr__('Your Job Title','mtlisitings'); ?>">
						</div>	

						<div class="form-group">
							<label for="details"><?php echo esc_html__('Description','mtlisitings'); ?></label>
							<textarea class="form-control" placeholder="<?php esc_attr__('Enter details about your listing','mtlisitings'); ?>" name="details"><?php echo get_post_field('post_content', $listing_id); ?></textarea>
						</div>					
						
						<div class="form-group">           
							<label for="listing_categories"><?php echo esc_html__('Job Category','mtlisitings'); ?></label>	 <br>	    
	                        <select id="listing_categories" class="listing-select" name="listing_categories">
	                            <?php
	                                
	                                $categories = get_terms( 'mt-listing-category2', array('hide_empty'=>false) );
	                                
	                                foreach ($categories as $category) {

	                                	$current_categories = wp_get_post_terms( $listing_id, array( 'mt-listing-category2' ) );
	                                	
	                                	foreach ( $current_categories as $current_category ) {                                		
	                                		
	                                		if($current_category->name == $category->name) {	                                			
	                                			echo "<option value='{$category->term_id}' selected>{$category->name}</option>";
	                                		
	                                		} else {
	                                			echo "<option value='{$category->term_id}'>{$category->name}</option>";
	                                		}
								
										} 
																				
	                                }
	                                
	                            ?>
	                        </select>
	                        <input id="other-category-input" type="text" name="listing_categories_other">
	                    </div> 

	                    
                    
	                    <div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Job Requirements Title','mtlisitings'); ?></label>
							<?php $mt_listing_listing_features_title = get_post_meta( $listing_id, 'mt_listing_listing_features_title', true ); ?>
							<input type="text" class="form-control" name="mt_listing_features_title" value="<?php echo $mt_listing_listing_features_title; ?>" placeholder="<?php echo esc_attr__('Your Job Requirements Title','mtlisitings'); ?>">
						</div>

						
						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Job Requirements Description','mtlisitings'); ?></label>
							<?php $mt_listing_listing_features_description = get_post_meta( $listing_id, 'mt_listing_listing_features_description', true ); ?>
							<textarea class="form-control" placeholder="<?php echo esc_attr__('Your Job Requirements Description','mtlisitings'); ?>" name="mt_listing_features_description"><?php echo $mt_listing_listing_features_description; ?></textarea>
						</div>

						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Best Canditate Description','mtlisitings'); ?></label>
							<?php $mt_listing_description_long = get_post_meta( $listing_id, 'mt_listing_description_long', true ); ?>
							<textarea class="form-control" placeholder="<?php echo esc_attr__('Best Canditate Description','mtlisitings'); ?>" name="mt_listing_description_long"><?php echo $mt_listing_description_long; ?></textarea>
						</div>


						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Salary','mtlisitings'); ?></label>
							<?php $mt_listing_salary = get_post_meta( $listing_id, 'mt_listing_salary', true ); ?>
							<input type="text" class="form-control" name="mt_listing_salary" value="<?php echo $mt_listing_salary; ?>" placeholder="<?php echo esc_attr__('Salary','mtlisitings'); ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Job Level','mtlisitings'); ?></label>
							<?php $mt_listing_level = get_post_meta( $listing_id, 'mt_listing_level', true ); ?>
							<input type="text" class="form-control" name="mt_listing_level" value="<?php echo $mt_listing_level; ?>" placeholder="<?php echo esc_attr__('Your Job Level','mtlisitings'); ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Job Experience','mtlisitings'); ?></label>
							<?php $mt_listing_experience = get_post_meta( $listing_id, 'mt_listing_experience', true ); ?>
							<input type="text" class="form-control" name="mt_listing_experience" value="<?php echo $mt_listing_experience; ?>" placeholder="<?php echo esc_attr__('Your Job Experience','mtlisitings'); ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Company Name','mtlisitings'); ?></label>
							<?php $mt_listing_company_name = get_post_meta( $listing_id, 'mt_listing_company_name', true ); ?>
							<input type="text" class="form-control" name="mt_listing_company_name" value="<?php echo $mt_listing_company_name; ?>" placeholder="<?php echo esc_attr__('Your Company Name','mtlisitings'); ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('About company','mtlisitings'); ?></label>
							<?php $mt_listing_description_company = get_post_meta( $listing_id, 'mt_listing_description_company', true ); ?>
							<textarea class="form-control" placeholder="<?php echo esc_attr__('About company','mtlisitings'); ?>" name="mt_listing_description_company"><?php echo $mt_listing_description_company; ?></textarea>
						</div>

						<div class="form-group styling-checkboxes">
							<label for="mt-tags"><?php echo esc_html__('Check tags','mtlisitings'); ?></label> <br>	

							<?php $tags = get_terms( 'mt-listing-tags', array('hide_empty' => false) );

		                        foreach ($tags as $tag) { ?>

		                        	<?php $attr = ""; ?>
		                        	<?php if( has_term( $tag->name, 'mt-listing-tags',  $listing_id) ) { ?>
		                        		<?php $attr = "checked"; ?>
		                        	<?php } ?>
		                        		
	                        		<label class="checkbox-inline">
		                                <input type="checkbox" name="mt-tags[]" value="<?php echo $tag->term_id; ?>" <?php echo $attr; ?>>
		                                <?php echo $tag->name; ?>
		                                <span class="checkmark"></span>
	                            	</label>		                          	                        		
		                        
		                        <?php } ?>

						</div>

						<div class="form-group">           
							<label for="listing_locations"><?php echo esc_html__('Locations','mtlisitings'); ?></label>	 <br>	    
	                        <select id="listing_locations" class="listing-select" name="listing_locations">
	                            <?php
	                                
	                                $locations = get_terms( 'mt-listing-category', array('hide_empty'=>false) );
	                                
	                                foreach ($locations as $location) {

	                                	$current_locations = wp_get_post_terms( $listing_id, array( 'mt-listing-category' ) );
	                                	
	                                	foreach ( $current_locations as $current_location ) {                                		
	                                		
	                                		if($current_location->name == $location->name) {	                                			
	                                			echo "<option value='{$location->term_id}' selected>{$location->name}</option>";
	                                		
	                                		} else {
	                                			echo "<option value='{$location->term_id}'>{$location->name}</option>";
	                                		}									
										} 

	                                }
	                            ?>
	                        </select>
	                        <input id="other-location-input" type="text" name="listing_locations_other">
	                    </div> 

	                    <div class="row">
		                	<div class="col-md-6">
			                    <div class="form-group">
									<label for="listing_location_address"><?php echo esc_html__('Location Address','mtlisitings'); ?></label>	 <br>
									<?php $mt_listing_location_address = get_post_meta( $listing_id, 'mt_listing_location_address', true ); ?>
									<input type="text" class="form-control listing-location-address" name="listing_location_address" value="<?php echo $mt_listing_location_address; ?>" placeholder="<?php echo esc_attr__('e.g Domneasca Street 8002155', 'mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
							<div class="form-group">
								<label for="listing_location_coordinates"><?php echo esc_html__('Location Coordinates','mtlisitings'); ?></label>	 <br>
								<?php $mt_map_coordinates = get_post_meta( $listing_id, 'mt_map_coordinates', true ); ?>
								<input type="text" class="form-control listing-location-coordinates" name="listing_location_coordinates" value="<?php echo $mt_map_coordinates; ?>" placeholder="<?php echo esc_attr__('e.g 37.718831, -122.452403','mtlisitings') ?>">
							</div>
							</div>
						</div>

						
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_phone_number"><?php echo esc_html__('Phone Number','mtlisitings'); ?></label>	 <br>
									<?php $mt_listing_phone_number = get_post_meta( $listing_id, 'mt_listing_phone_number', true ); ?>
									<input type="text" class="form-control listing-phone-number" name="listing_phone_number" value="<?php echo $mt_listing_phone_number; ?>" placeholder="<?php echo esc_attr__('e.g (8800) 4433 89895','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_mail_address"><?php echo esc_html__('Mail Address','mtlisitings'); ?></label>	 <br>
									<?php $mt_listing_mail_address = get_post_meta( $listing_id, 'mt_listing_mail_address', true ); ?>
									<input type="text" class="form-control listing-mail-address" name="listing_mail_address" value="<?php echo $mt_listing_mail_address; ?>" placeholder="<?php echo esc_attr__('e.g company@example.com','mtlisitings') ?>">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="listing_website_link"><?php echo esc_html__('Website link','mtlisitings'); ?></label>	 <br>
							<?php $mt_listing_website_listing = get_post_meta( $listing_id, 'mt_listing_website_listing', true ); ?>
							<input type="text" class="form-control listing-website-link" name="listing_website_link" value="<?php echo $mt_listing_website_listing; ?>" placeholder="<?php echo esc_attr__('e.g https:\\meraki.com','mtlisitings') ?>">
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_facebook_link"><?php echo esc_html__('Facebook link','mtlisitings'); ?></label>	<br>
									<?php $mt_listing_facebook = get_post_meta( $listing_id, 'mt_listing_facebook', true ); ?>
									<input type="text" class="form-control listing-facebook-link" name="listing_facebook_link" value="<?php echo $mt_listing_facebook; ?>" placeholder="<?php echo esc_attr__('https://www.facebook.com/username','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_linkedin_link"><?php echo esc_html__('Linkedin link','mtlisitings'); ?></label>	<br>
									<?php $mt_listing_linkedin = get_post_meta( $listing_id, 'mt_listing_linkedin', true ); ?>
									<input type="text" class="form-control listing-linkedin-link" name="listing_linkedin_link" value="<?php echo $mt_listing_linkedin; ?>" placeholder="<?php echo esc_attr__('https://www.linkedin.com/username','mtlisitings') ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_twitter_link"><?php echo esc_html__('Twitter link','mtlisitings') ?></label>	 <br>
									<?php $mt_listing_twitter = get_post_meta( $listing_id, 'mt_listing_twitter', true ); ?>
									<input type="text" class="form-control listing-twitter-link" name="listing_twitter_link" value="<?php echo $mt_listing_twitter; ?>" placeholder="<?php echo esc_attr__('https://twitter.com/username','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_youtube_link"><?php echo esc_html__('Youtube link','mtlisitings') ?></label>	 <br>
									<?php $mt_listing_youtube = get_post_meta( $listing_id, 'mt_listing_youtube', true ); ?>
									<input type="text" class="form-control listing-youtube-link" name="listing_youtube_link" value="<?php echo $mt_listing_youtube; ?>" placeholder="<?php echo esc_attr__('https://www.youtube.com/username','mtlisitings') ?>">
								</div>  
							</div> 
						</div>    

						<div class="form-group">
							<label for="mt_listing_video_presentation"><?php echo esc_html__('Video Presentation link','mtlisitings') ?></label>
							<?php $mt_video_tour = get_post_meta( $listing_id, 'mt_video_tour', true ); ?>
							<input type="text" class="form-control" name="mt_listing_video_presentation" value="<?php echo $mt_video_tour; ?>" placeholder="<?php echo esc_attr__('e.g https://youtu.be/YoxHEBeF6s0','mtlisitings') ?>">
						</div>

						<?php echo do_shortcode('[frontend-button]'); ?>

						<div class="form-group pull-right">
							<button type="submit" class="button-listing" name="add-listing" class="btn btn-success"><?php echo esc_html__('Update Job','mtlisitings') ?></button>
						</div>

					</form>

				<?php } else { ?>

					<form id="add-new-listing" method="POST" enctype="multipart/form-data">

						<?php echo wp_kses_post($success_messaje); ?>

						<div class="form-group">
							<label for="mt_listing_name"><?php echo esc_html__('Opening Job Title','mtlisitings') ?></label>
							<input type="text" class="form-control listing-title" name="mt_listing_name" value="" placeholder="<?php echo esc_attr__('Your job title','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="details"><?php echo esc_html__('Description','mtlisitings') ?></label>
							<textarea class="form-control" placeholder="<?php echo esc_attr__('A few words about the job opening','mtlisitings') ?>" name="details"></textarea>
						</div>

						<div class="form-group">           
							<label for="listing_categories"><?php echo esc_html__('Job Category','mtlisitings') ?></label>	 <br>	    
	                        <select id="listing_categories" class="listing-select" name="listing_categories">
	                            <option value=""><?php echo esc_attr__('Choose one category','mtlisitings') ?></option>
	                            <?php
	                                $categories = get_terms( 'mt-listing-category2', array('hide_empty'=>false) );
	                                foreach ($categories as $category) {
	                                    echo "<option value='{$category->term_id}'>{$category->name}</option>";
	                                }
	                            ?>
	                        </select>
	                        <input id="other-category-input" type="text" name="listing_categories_other">
	                    </div> 

	                    <div class="form-group">           
							<label for="listing_categories"><?php echo esc_html__('Job Type','mtlisitings') ?></label>	 <br>	    
	                        <select id="listing_types" class="listing-select" name="listing_types">
	                            <option value=""><?php echo esc_attr__('Choose one type','mtlisitings') ?></option>
	                            <?php
	                                $types = get_terms( 'mt-listing-type', array('hide_empty'=>false) );
	                                foreach ($types as $type) {
	                                    echo "<option value='{$type->term_id}'>{$type->name}</option>";
	                                }
	                            ?>
	                        </select>
	                   
	                    </div> 

	                    <div class="form-group">
							<label for="mt_listing_features_title"><?php echo esc_html__('Job Requirements Title','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_features_title" value="" placeholder="<?php echo esc_attr__('Your Job Requirements Title','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_features_description"><?php echo esc_html__('Job Requirements Description','mtlisitings') ?></label>
							<textarea class="form-control"  placeholder="<?php echo esc_attr__('Your Job Requirements Description','mtlisitings') ?>" name="mt_listing_features_description"></textarea>
						</div>

						<div class="form-group">
							<label for="mt_listing_features_description"><?php echo esc_html__('Best canditate Description','mtlisitings') ?></label>
							<textarea class="form-control"  placeholder="<?php echo esc_attr__('- good English abbilities, etc.','mtlisitings') ?>" name="mt_listing_description_long"></textarea>
						</div>
					

						<div class="form-group">
							<label for="mt_listing_nr_open"><?php echo esc_html__('Salary','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_salary" value="" placeholder="<?php echo esc_attr__('Salary','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_level"><?php echo esc_html__('Job Level','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_level" value="" placeholder="<?php echo esc_attr__('Your Job Level','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_experience"><?php echo esc_html__('Job Experience','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_experience" value="" placeholder="<?php echo esc_attr__('Your Job Experience','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_company_name"><?php echo esc_html__('Company Name','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_company_name" value="" placeholder="<?php echo esc_attr__('Your Company Name','mtlisitings') ?>">
						</div>

						<div class="form-group">
							<label for="mt_listing_description_company"><?php echo esc_html__('About Company','mtlisitings') ?></label>
							<textarea class="form-control"  placeholder="<?php echo esc_attr__('Your company description','mtlisitings') ?>" name="mt_listing_description_company"></textarea>
						</div>

						<div class="form-group styling-checkboxes">			
							<label for="mt-tags"><?php echo esc_html__('Check tags','mtlisitings') ?></label>	 <br>	
							<?php $tags = get_terms( 'mt-listing-tags' );
	                        foreach ($tags as $tag) { ?>
	                            <label class="checkbox-inline">
	                                <input type="checkbox" name="mt-tags[]" value="<?php echo $tag->term_id; ?>">
	                                <?php echo $tag->name; ?>
	                                <span class="checkmark"></span>
	                            </label>
	                        <?php } ?>
						</div>

						<div class="form-group">           
							<label for="mt-tags"><?php echo esc_html__('Locations','mtlisitings') ?></label>	 <br>	    
	                        <select id="listing_locations" class="listing-select" name="listing_locations">
	                            <option value="0"><?php echo esc_attr__('Select Locations','mtlisitings') ?></option>
	                            <?php
	                                $locations = get_terms( 'mt-listing-category', array('hide_empty'=>false) );
	                                foreach ($locations as $location) {
	                                    echo "<option value='{$location->term_id}'>{$location->name}</option>";
	                                }
	                            ?>
	                        </select>
	                        <input id="other-location-input" type="text" name="listing_locations_other">
	                    </div>
						
						<div class="row">
		                	<div class="col-md-6">
			                    <div class="form-group">
									<label for="listing_location_address"><?php echo esc_html__('Location Address','mtlisitings') ?></label>	 <br>
									<input type="text" class="form-control listing-location-address" name="listing_location_address" value="" placeholder="<?php echo esc_attr__('e.g Domneasca Street 8002155','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
							<div class="form-group">
								<label for="listing_location_coordinates"><?php echo esc_html__('Location Coordinates','mtlisitings') ?></label>	 <br>
								<input type="text" class="form-control listing-location-coordinates" name="listing_location_coordinates" value="" placeholder="<?php echo esc_attr__('e.g 37.718831, -122.452403','mtlisitings') ?>">
							</div>
							</div>
						</div>					    

						<?php echo do_shortcode('[frontend-button]'); ?>

						 

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_phone_number"><?php echo esc_html__('Phone Number','mtlisitings'); ?></label>	 <br>
									<input type="text" class="form-control listing-phone-number" name="listing_phone_number" value="" placeholder="<?php echo esc_attr__('e.g (8800) 4433 89895','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_mail_address"><?php echo esc_html__('Mail Address','mtlisitings'); ?></label>	 <br>
									<input type="text" class="form-control listing-mail-address" name="listing_mail_address" value="" placeholder="<?php echo esc_attr__('e.g company@example.com','mtlisitings') ?>">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="listing_website_link"><?php echo esc_html__('Website link','mtlisitings'); ?></label>	 <br>
							<input type="text" class="form-control listing-website-link" name="listing_website_link" value="" placeholder="<?php echo esc_attr__('e.g https://meraki.com','mtlisitings') ?>">
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_facebook_link"><?php echo esc_html__('Facebook link','mtlisitings'); ?></label>	<br>
									<input type="text" class="form-control listing-facebook-link" name="listing_facebook_link" value="" placeholder="<?php echo esc_attr__('https://www.facebook.com/username','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_linkedin_link"><?php echo esc_html__('Linkedin link','mtlisitings'); ?></label>	<br>
									<input type="text" class="form-control listing-linkedin-link" name="listing_linkedin_link" value="" placeholder="<?php echo esc_attr__('https://www.linkedin.com/username','mtlisitings') ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_twitter_link"><?php echo esc_html__('Twitter link','mtlisitings') ?></label>	 <br>
									<input type="text" class="form-control listing-twitter-link" name="listing_twitter_link" value="" placeholder="<?php echo esc_attr__('https://twitter.com/username','mtlisitings') ?>">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="listing_youtube_link"><?php echo esc_html__('Youtube link','mtlisitings') ?></label>	 <br>
									<input type="text" class="form-control listing-youtube-link" name="listing_youtube_link" value="" placeholder="https://www.youtube.com/username">
								</div>  
							</div> 
						</div>    

						<div class="form-group">
							<label for="mt_listing_video_presentation"><?php echo esc_html__('Video Presentation link','mtlisitings') ?></label>
							<input type="text" class="form-control" name="mt_listing_video_presentation" value="" placeholder="<?php echo esc_attr__('e.g https://youtu.be/YoxHEBeF6s0','mtlisitings') ?>">
						</div>

						
				
						<div class="form-group pull-right">
							<button type="submit" class="button-listing" name="add-listing" class="btn btn-success"><?php echo esc_html__('Add Job','mtlisitings') ?></button>
						</div>

					</form>

				<?php } ?>

			</div>

			<div class="clearfix"></div>

		</div>
	</div>
</div>


<?php get_footer();