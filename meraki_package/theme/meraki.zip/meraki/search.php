<?php
/**
 * The template for displaying search results.
 *
 */

get_header(); 


// theme_ini
$theme_init = new meraki_init_class;

$search_scope = 'posts';
if (meraki_redux('mt_search_scope') == 'jobs') {
    $search_scope = 'jobs';
}else{
    $search_scope = 'posts';
}
?>

<!-- HEADER TITLE BREADCRUBS SECTION -->
<?php echo wp_kses_post(meraki_header_title_breadcrumbs()); ?>


<?php if( isset($_GET['post_type'])){ ?>
    <?php if ( have_posts() ) : ?>

            <!-- MAP PINS ON ARCHIVE -->
            <?php if(function_exists('modeltheme_framework')){ ?>
                <!-- MAP LOCATION -->
                <div class="mt_listings_page mt_listing_map_location">
                <?php 

                    $gmap_pin = '';
                    $api_key = meraki_redux('mt_listings_api_key');
                    // Start Map
                    $gmap_pin .= '[sbvcgmap map_width="100" map_height="500" zoom="12" scrollwheel="no" pancontrol="no" scalecontrol="no" scalecontrol="no" streetviewcontrol="no" zoomcontrol="no"  maptypecontrol="no" overviewmapcontrol="no" searchradius="500"  scrollwheel="no sbvcgmap_title="Google Maps" mapstyles="style-55"   sbvcgmap_apikey="'. esc_attr($api_key).'"]';

                        while ( have_posts() ) : the_post();

                            $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'meraki_listing_archive_thumbnail' );
                  
                            if ($thumbnail_src) {
                                $listing_img_pin = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.get_the_title().'" />';
                            } else {
                                $listing_img_pin = '';
                            }

                            $mt_listing_location_address = get_post_meta( get_the_ID(), 'mt_listing_location_address', true );
                            $mt_listing_location_address_pin = '';
                            if($mt_listing_location_address) { 
                                $mt_listing_location_address_pin = $mt_listing_location_address;
                            } 

                            // Get the current category ID, e.g. if we're on a category archive page
                            $categories = wp_get_post_terms(get_the_ID(), 'mt-listing-category2', array("fields" => "all"));
                            foreach($categories as $category) {
                                if ($category) {
                                    $image_id = get_term_meta ( $category->term_id, 'category-image-id-v3', true );
                                    $mt_map_coordinates = get_post_meta( get_the_ID(), 'mt_map_coordinates', true );
                                    if (isset($mt_map_coordinates) && !empty($mt_map_coordinates)) {
                                        if (isset($image_id) && !empty($image_id)) {
                                            $gmap_pin .= '[sbvcgmap_marker animation="DROP" address="'.esc_attr($mt_map_coordinates).'" icon="'.esc_attr($image_id).'"]'.$listing_img_pin.'<a href="'.get_the_permalink().'">'.get_the_title().'</a><p>'.esc_attr($mt_listing_location_address_pin).'</p>[/sbvcgmap_marker]';
                                        }
                                    }
                                }
                            }
                        endwhile;
                    // End Map
                    $gmap_pin .= '[/sbvcgmap]';
                    echo do_shortcode($gmap_pin);
                ?>
                </div>
            <?php } ?>

    <?php endif; ?>
<?php } ?>

    

    <!-- Page content -->
    <div class="high-padding">
        <!-- Blog content -->
        <div class="container blog-posts search-post"> 
            <div class="row">

                <div class="col-md-12 main-content">
                <?php if ( have_posts() ) : ?>
                    <div class="row">

                        <?php /* Start the Loop */ ?>
                        <?php $i = 1; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php /* Loop - Variant 1 */ ?>

                            <?php if ( class_exists('ReduxFrameworkPlugin')) { ?>
                                <?php if ( !isset($_GET['post_type'])) { ?>
                                    <?php get_template_part( 'content', 'icosearch' ); ?>
                                <?php }elseif( $search_scope == 'mt_listing' && isset($_GET['post_type'])){ ?>
                                    <?php get_template_part( 'content', 'icosearch' ); ?>
                                <?php }else{ ?>
                                    <?php get_template_part( 'content', 'icosearch' ); ?>
                                <?php } ?>
                            <?php }else{ ?>
                                <?php get_template_part( 'content', 'blogloop-v5' ); ?>
                            <?php } ?>

                            <?php /* AD PLace*/ ?>
                            <?php 
                            if ( class_exists( 'ReduxFrameworkPlugin' ) && function_exists('mtlistings_framework')) {
	                            if($i == 2) {
	                                if (meraki_redux('mt_adplace_search')){
	                                    if(meraki_redux('mt_adplace_search_adsense_code') != '' && meraki_redux('mt_adplace_search') == 'on_adsense'){
	                                      echo meraki_redux('mt_adplace_search_adsense_code');
	                                    }elseif(meraki_redux('mt_adplace_search_img','url') != '' && meraki_redux('mt_adplace_search') == 'on'){  
	                                        echo '<div class="col-md-3" single-listing list-view listing-taxonomy-shortcode adplace-category">
	                                            <div class="adplace-search">
	                                                    <a href="'. esc_url(meraki_redux('mt_adplace_search_link')) .'" target="_blank">
	                                                        <img src="'. esc_url(meraki_redux('mt_adplace_search_img','url')) .'" alt="search-img" />
	                                                    </a>
	                                            </div>
	                                        </div>';
	                                  }
	                                }
	                            }
                            } ?>
                            <?php $i++; ?>

                        <?php endwhile; ?>

                        <div class="modeltheme-pagination-holder col-md-12">             
                            <div class="modeltheme-pagination pagination">             
                                <?php the_posts_pagination(); ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <?php get_template_part( 'content', 'none' ); ?>
                <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
<?php get_footer(); ?>