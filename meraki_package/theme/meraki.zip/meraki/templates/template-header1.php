<?php
global $meraki_redux;
global $woocommerce;
$myaccount_page_url = '#';
if ( class_exists( 'WooCommerce' ) ) {
  $cart_url = wc_get_cart_url();
  $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
  $count = WC()->cart->cart_contents_count;
    
  if ( $myaccount_page_id ) {
    $myaccount_page_url = get_permalink( $myaccount_page_id );
  }else{
    $myaccount_page_url = '#';
  }
}else{
    $myaccount_page_url = '#';
}
?>
<header class="header1">
  <!-- BOTTOM BAR -->
  <nav class="navbar navbar-default logo-infos" id="modeltheme-main-head">
    <div class="container">
      <div class="row">
        <!-- LOGO -->
        <div class="navbar-header col-md-3">
          <!-- NAVIGATION BURGER MENU -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
          </button>
          <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { 
            
          $custom_header_activated = get_post_meta( get_the_ID(), 'smartowl_custom_header_options_status', true );
          $header_v = get_post_meta( get_the_ID(), 'smartowl_header_custom_variant', true );
          $custom_logo_url = get_post_meta( get_the_ID(), 'smartowl_header_custom_logo', true );
          if($custom_header_activated == 'yes' && isset($custom_logo_url) && !empty($custom_logo_url)) { ?>
            <div class="logo">
                <a href="<?php echo esc_url(get_site_url()); ?>">
                    <img src="<?php echo esc_url($custom_logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                </a>
            </div>
          <?php } else {
            if(meraki_redux('mt_logo','url')){ ?>
              <div class="logo">
                  <a href="<?php echo esc_url(get_site_url()); ?>">
                      <img src="<?php echo esc_url(meraki_redux('mt_logo','url')); ?>" alt="<?php echo esc_attr(get_bloginfo()); ?>" />
                  </a>
              </div>
            <?php }else{ ?>
              <div class="logo no-logo">
                  <a href="<?php echo esc_url(get_site_url()); ?>">
                    <?php echo esc_html(get_bloginfo()); ?>
                  </a>
              </div>
            <?php } ?>
          <?php } ?>
          <?php }else{ ?>
            <div class="logo no-logo">
                <a href="<?php echo esc_url(get_site_url()); ?>">
                  <?php echo esc_html(get_bloginfo()); ?>
                </a>
            </div>
          <?php } ?>
          <!-- SEARCH FORM -->
          
        </div>
        <!-- NAV MENU -->
        <div id="navbar" class="navbar-collapse collapse col-md-9">
          <ul class="menu nav navbar-nav pull-right nav-effect nav-menu">
            <?php
              if ( has_nav_menu( 'primary' ) ) {
                $defaults = array(
                  'menu'            => '',
                  'container'       => false,
                  'container_class' => '',
                  'container_id'    => '',
                  'menu_class'      => 'menu',
                  'menu_id'         => '',
                  'echo'            => true,
                  'fallback_cb'     => false,
                  'before'          => '',
                  'after'           => '',
                  'link_before'     => '',
                  'link_after'      => '',
                  'items_wrap'      => '%3$s',
                  'depth'           => 0,
                  'walker'          => ''
                );
                $defaults['theme_location'] = 'primary';
                wp_nav_menu( $defaults );
              }else{
                echo '<p class="no-menu text-left">';
                  echo esc_html__('Primary navigation menu is missing.', 'meraki');
                echo '</p>';
              }
            ?>           
            <?php if ( function_exists('modeltheme_framework')) { ?>
              <?php $classes = get_body_class();
                if (!in_array('login-register-page',$classes)) { ?> 
                  <?php if (is_user_logged_in()) { ?> 
                    <?php if(class_exists( 'WooCommerce' )){ ?>  
                    <div id="dropdown-user-profile" class="ddmenu">
                      <a class="profile"><i class="fa fa-user"></i></a>
                      <ul>
                        <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'dashboard_acc'); ?>"><i class="icon-layers icons"></i> <?php echo esc_html__('My Dashboard','meraki'); ?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'listings'); ?>"><i class="icon-list icons"></i> <?php echo esc_html__('My Jobs','meraki'); ?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'applications'); ?>"><i class="icon-calendar icons"></i> <?php echo esc_html__('My Applicants','meraki'); ?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'orders'); ?>"><i class="icon-bag icons"></i> <?php echo esc_html__('My Orders','meraki'); ?></a></li>
                        <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'edit-account'); ?>"><i class="icon-user icons"></i> <?php echo esc_html__('Account Details','meraki'); ?></a></li>
                        <div class="dropdown-divider"></div>
                        <li><a href="<?php echo esc_url(wp_logout_url( home_url() )); ?>"><i class="icon-logout icons"></i> <?php echo esc_html__('Log Out','meraki'); ?></a></li>
                      </ul>
                    </div>
                    <?php } ?>
                  <?php } else { ?>
                    <li id="nav-menu-login" class="nav-menu-account meraki-logoin"><a href="<?php echo esc_url('#'); ?>" data-modal="modal-log-in" class="modeltheme-trigger"><?php echo esc_html__('Login','meraki'); ?><i class="fa fa-sign-in"></i></a>
                  <?php } ?>
                <?php } ?>
              <?php } ?>
              <?php if ( class_exists( 'WooCommerce' ) ) { ?>
                  <li class="shop_cart_li menu-item">
                    <a class="shop_cart" href="<?php echo esc_url(wc_get_cart_url()); ?>">
                      <i class="fa fa-shopping-basket" aria-hidden="true"></i><span class="cart-contents-count"><?php echo esc_html( $count ); ?></span>
                    </a>
                    <div class="header_mini_cart">
                      <?php the_widget( 'WC_Widget_Cart' ); ?>
                    </div>
                  </li>
         
              <?php } ?>
            <?php if ( function_exists('modeltheme_framework')) {   
              $submit_ico = '#';
              if (function_exists('mtlistings_framework')) {
                if (meraki_redux('mt_listings_submit_ico_page')) {
                  $submit_ico = meraki_redux('mt_listings_submit_ico_page');
                }
              }
              if ( class_exists( 'WooCommerce' ) ) { 
                if (is_account_page()) { ?>
                  <li id="nav-menu-list" class="nav-menu-account"><a href="<?php echo get_site_url(); ?>"><?php echo esc_html__('Back to Home', 'meraki'); ?></a></li>
                  <?php } else {
                    if (function_exists('mtlistings_framework')) {
                      if (meraki_redux('mt_listings_submit_ico_status') == TRUE) { ?>
                        <li id="nav-menu-list" class="nav-menu-account"><a href="<?php echo esc_url( $submit_ico ); ?>"><?php echo esc_html__('Add Job', 'meraki'); ?></a></li>
                      <?php } 
                    } 
                }     
              } ?> 
          
            <?php } ?> 
          </ul>
          
        </div>
      </div>
    </div>
  </nav>
</header>
