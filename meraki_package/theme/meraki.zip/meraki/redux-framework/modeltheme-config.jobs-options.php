<?php
// JOBS TAB
$meraki_jobs_tab = array(
    'title' => esc_html__('MT Jobs Settings', 'meraki') ,
    'id' => 'mt_listings',
    'icon' => 'el el-icon-comment'
);
// General Settings
$meraki_jobs_subtab_general = array(
    'title' => esc_html__('General', 'meraki') ,
    'id' => 'mt_listings_settings_currency',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_listings_submit_ico_status',
            'type'     => 'switch', 
            'title'    => esc_html__('Submit Job Button', 'meraki'),
            'subtitle' => esc_html__('Enable or disable "Submit Job Button".', 'meraki'),
            'default'  => false,
            'on'       => esc_html__( 'Enabled', 'meraki' ),
            'off'      => esc_html__( 'Disabled', 'meraki' )
        ),
        array(
            'id' => 'mt_listings_submit_ico_page',
            'type' => 'text',
            'title' => esc_html__('Header Submit Job Button Page', 'meraki') ,
            'subtitle' => esc_html__('Select Page for the Header Submit Job Button.', 'meraki'),
            'required' => array( 'mt_listings_submit_ico_status', '=', true ),
            'default'  => '#',
        ),
        array(
            'id'       => 'mt_listings_devmode',
            'type'     => 'switch', 
            'title'    => esc_html__('Developer Mode Status', 'meraki'),
            'subtitle' => esc_html__('Enable or disable the right to disable jobs. ', 'meraki'),
            'default'  => true,
        ),
        array(
            'id'   => 'mt_divider_preloader_styling',
            'type' => 'info',
            'class' => 'mt_divider',
            'desc' => wp_kses_post( '<h3>My Account Page</h3>' )
        ),
        array(
            'id' => 'mt_listings_account_link1_title',
            'type' => 'text',
            'title' => esc_html__('My Account Link 1 Title', 'meraki') ,
            'subtitle' => esc_html__('Select tab name for My account Link 1', 'meraki'),
            'default'  => 'Submit FREE Listing',
        ),
        array(
            'id' => 'mt_listings_account_link1',
            'type' => 'text',
            'title' => esc_html__('My Account Link 1 URL', 'meraki') ,
            'subtitle' => esc_html__('Type your URL for My account page Link 1', 'meraki'),
            'desc' => esc_html__('For example: "https://meraki.modeltheme.com/listing"', 'meraki'),
            'default'  => 'https://meraki.modeltheme.com/listing',
        ),
        array(
            'id' => 'mt_listings_account_link2_title',
            'type' => 'text',
            'title' => esc_html__('My Account Link 2 Title', 'meraki') ,
            'subtitle' => esc_html__('Select tab name for My account Link 2', 'meraki'),
            'default'  => 'Submit Sponsored Listing',
        ),
        array(
            'id' => 'mt_listings_account_link2',
            'type' => 'text',
            'title' => esc_html__('My Account Link 2 URL', 'meraki') ,
            'subtitle' => esc_html__('Type your URL for My account page Link 2', 'meraki'),
            'desc' => esc_html__('For example: "https://meraki.modeltheme.com/pricing-table/"', 'meraki'),
            'default'  => '',
        ),

    ),
);
// Archive Job Pages
$meraki_jobs_subtab_archive = array(
    'title' => esc_html__('Archive Jobs Pages', 'meraki') ,
    'id' => 'mt_listings_settings_archive',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_listings_layout',
            'type'     => 'image_select',
            'compiler' => true,
            'title'    => esc_html__( 'Jobs Archive Layout', 'meraki' ),
            'subtitle' => esc_html__( 'Select Jobs Archive layout.', 'meraki' ),
            'options'  => array(
                'mt_listings_left_sidebar' => array(
                    'alt' => esc_html__('2 Columns - Left sidebar', 'meraki' ),
                    'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-left.jpg'
                ),
                'mt_listings_fullwidth' => array(
                    'alt' => esc_html__('1 Column - Full width', 'meraki' ),
                    'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-no.jpg'
                ),
                'mt_listings_right_sidebar' => array(
                    'alt' => esc_html__('2 Columns - Right sidebar', 'meraki' ),
                    'img' => get_template_directory_uri().'/redux-framework/assets/sidebar-right.jpg'
                )
            ),
            'default'  => 'mt_listings_right_sidebar'
        ),
        array(
            'id'       => 'mt_listings_layout_sidebar',
            'type'     => 'select',
            'data'     => 'sidebars',
            'title'    => esc_html__( 'Job Archive Sidebar', 'meraki' ),
            'subtitle' => esc_html__( 'Select Job Archive Sidebar.', 'meraki' ),
            'default'   => 'sidebar-1',
            'required' => array('mt_listings_layout', '!=', 'mt_listings_fullwidth'),
        ),
    ),
);
// Sponsored Listing Package
$meraki_jobs_subtab_sponsored_job = array(
    'title' => esc_html__('Sponsored Job Package', 'meraki') ,
    'id' => 'mt_listings_settings_package',
    'subsection' => true,
    'fields' => array(
        array(
            'id' => 'mt_premium_package_productid',
            'type' => 'text',
            'title' => esc_html__('Set WooCommerce Product ID for the Sponsored package feature', 'meraki'),
            'subtitle' => esc_html__('Learn how to get the Product ID: https://bit.ly/2RW8b0n', 'meraki'),
            'default' => ''
        ),
    ),
);
// Single Listing Page
$meraki_jobs_subtab_single = array(
    'title' => esc_html__('Single Job Page', 'meraki') ,
    'id' => 'mt_listings_settings_single',
    'subsection' => true,
    'fields' => array(
        array(
            'id' => 'mt_related_listings',
            'type' => 'switch',
            'title' => esc_html__('Related Jobs', 'meraki') ,
            'subtitle' => esc_html__('Enable or disable related Jobs', 'meraki') ,
            'default' => true,
        ),
        array(
            'id' => 'mt_job_icon',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Single Job icon', 'meraki'),
            'compiler' => 'true',
            'default' => array('url' => get_template_directory_uri().'/images/job-check.png'),
        ),
        
    ),
);
// Api key
$meraki_jobs_subtab_api_key = array(
    'title' => esc_html__('API KEY Maps', 'meraki') ,
    'id' => 'mt_listings_settings_api',
    'subsection' => true,
    'fields' => array(
        array(
            'id' => 'mt_listings_api_key',
            'type' => 'text',
            'title' => esc_html__('Set the API key for maps', 'meraki'),
            'subtitle' => esc_html__('', 'meraki'),
            'default' => ''
        ),
    ),
);



// ADPLACES TAB
$meraki_jobs_tab_adplaces = array(
    'title' => esc_html__('MT AdPlaces', 'meraki') ,
    'id' => 'mt_adplaces',
    'icon' => 'el el-cogs'
);
// On Single job
$meraki_jobs_subtab_adplace_single_listing = array(
    'title' => esc_html__('AdPlace Single Jobs Listing', 'meraki') ,
    'id' => 'mt_adplaces_1',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_adplace_single',
            'type'     => 'button_set',
            'title'    => esc_html__( 'AdPlace - Jobs Listing - Top/Bottom', 'meraki' ),
            'subtitle' => esc_html__( 'Select your "AdPlace Jobs Listing - Top/Bottom"', 'meraki' ),
            //Must provide key => value pairs for radio options
            'options'  => array(
                'on_adsense' => 'Enable AdSense',
                'on'         => 'Enable Banner Ad',
                'off'        => 'Disable Ad'
            ),
            'default'  => 'off'
        ),
        array(
            'id' => 'mt_adplace_single_sidebar_link',
            'type' => 'text',
            'title' => esc_html__('AdPlace Sidebar URL', 'meraki'),
            'subtitle' => esc_html__('Type your AdPlace Jobs Listing - Sidebar URL.', 'meraki'),
            'required' => array( 'mt_adplace_single', '=', 'on' ),
            'desc' => esc_html__('For example: "https://modeltheme.com"', 'meraki'),
            'default' => 'https://'
        ),
        array(
            'id' => 'mt_adplace_single_sidebar_img',
            'type' => 'media',
            'title' => esc_html__('Choose image for AdPlace Sidebar', 'meraki'),
            'subtitle' => esc_html__('Use the upload button to import media.', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_single', '=', 'on' )
        ),
    ),
);
// On Blog post
$meraki_jobs_subtab_adplace_single_post = array(
    'title' => esc_html__('AdPlace Blog Post', 'meraki') ,
    'id' => 'mt_adplaces_blog_post',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_adplace_blog_post',
            'type'     => 'button_set',
            'title'    => esc_html__( 'AdPlace - Blog Post', 'meraki' ),
            'subtitle' => esc_html__( 'Select your "AdPlace content blog post"', 'meraki' ),
            //Must provide key => value pairs for radio options
            'options'  => array(
                'on_adsense' => 'Enable AdSense',
                'on'         => 'Enable Banner Ad',
                'off'        => 'Disable Ad'
            ),
            'default'  => 'off'
        ),
        array(
            'id' => 'mt_adplace_blog_post_link',
            'type' => 'text',
            'title' => esc_html__('AdPlace URL', 'meraki'),
            'subtitle' => esc_html__('Type your AdPlace blog post URL.', 'meraki'),
            'required' => array( 'mt_adplace_blog_post', '=', 'on' ),
            'desc' => esc_html__('For example: "https://modeltheme.com"', 'meraki'),
            'default' => 'https://'
        ),
        array(
            'id' => 'mt_adplace_blog_post_img',
            'type' => 'media',
            'title' => esc_html__('Choose image for AdPlace Blog Post', 'meraki'),
            'subtitle' => esc_html__('Use the upload button to import media.', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_blog_post', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_blog_post_adsense_code',
            'type' => 'textarea',
            'title' => esc_html__('AdSense code', 'meraki'),
            'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'meraki'),
            'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'meraki'),
            'required' => array( 'mt_adplace_blog_post', '=', 'on_adsense' ),
            'default' => ''
        ),
    ),
);
// On search
$meraki_jobs_subtab_adplace_search = array(
    'title' => esc_html__('AdPlace Search', 'meraki') ,
    'id' => 'mt_adplaces_search',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_adplace_search',
            'type'     => 'button_set',
            'title'    => esc_html__( 'AdPlace - Search', 'meraki' ),
            'subtitle' => esc_html__( 'Select your "AdPlace Search"', 'meraki' ),
            //Must provide key => value pairs for radio options
            'options'  => array(
                'on_adsense' => 'Enable AdSense',
                'on'         => 'Enable Banner Ad',
                'off'        => 'Disable Ad'
            ),
            'default'  => 'off'
        ),
        array(
            'id' => 'mt_adplace_search_link',
            'type' => 'text',
            'title' => esc_html__('AdPlace URL', 'meraki'),
            'subtitle' => esc_html__('Type your AdPlace Search URL.', 'meraki'),
            'required' => array( 'mt_adplace_search', '=', 'on' ),
            'desc' => esc_html__('For example: "https://modeltheme.com"', 'meraki'),
            'default' => 'https://'
        ),
        array(
            'id' => 'mt_adplace_search_img',
            'type' => 'media',
            'title' => esc_html__('Choose image for AdPlace Search', 'meraki'),
            'subtitle' => esc_html__('Use the upload button to import media.', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_search', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_search_adsense_code',
            'type' => 'textarea',
            'title' => esc_html__('AdSense code', 'meraki'),
            'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'meraki'),
            'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'meraki'),
            'required' => array( 'mt_adplace_search', '=', 'on_adsense' ),
            'default' => ''
        ),
    ),
);
// On categories
$meraki_jobs_subtab_adplace_categories = array(
    'title' => esc_html__('AdPlace Category', 'meraki') ,
    'id' => 'mt_adplaces_category',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_adplace_category',
            'type'     => 'button_set',
            'title'    => esc_html__( 'AdPlace - Category', 'meraki' ),
            'subtitle' => esc_html__( 'Select your "AdPlace Category"', 'meraki' ),
            //Must provide key => value pairs for radio options
            'options'  => array(
                'on_adsense' => 'Enable AdSense',
                'on'         => 'Enable Banner Ad',
                'off'        => 'Disable Ad'
            ),
            'default'  => 'off'
        ),
        array(
            'id' => 'mt_adplace_category_link',
            'type' => 'text',
            'title' => esc_html__('AdPlace URL', 'meraki'),
            'subtitle' => esc_html__('Type your AdPlace Category URL.', 'meraki'),
            'required' => array( 'mt_adplace_category', '=', 'on' ),
            'desc' => esc_html__('For example: "https://modeltheme.com"', 'meraki'),
            'default' => 'https://'
        ),
        array(
            'id' => 'mt_adplace_category_img',
            'type' => 'media',
            'title' => esc_html__('Choose image for AdPlace Search', 'meraki'),
            'subtitle' => esc_html__('Use the upload button to import media.', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_category', '=', 'on' )
        ),
        array(
            'id' => 'mt_adsense_category_code',
            'type' => 'textarea',
            'title' => esc_html__('AdSense code', 'meraki'),
            'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'meraki'),
            'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'meraki'),
            'required' => array( 'mt_adplace_category', '=', 'on_adsense' ),
            'default' => ''
        ),
    ),
);
// On lists
$meraki_jobs_subtab_adplace_lists = array(
    'title' => esc_html__('AdPlace Jobs List', 'meraki') ,
    'id' => 'mt_adplaces_ico_list',
    'subsection' => true,
    'fields' => array(
        array(
            'id'       => 'mt_adplace_ico_list',
            'type'     => 'button_set',
            'title'    => esc_html__( 'AdPlace - Jobs List', 'meraki' ),
            'subtitle' => esc_html__( 'Select your "AdPlace Jobs List"', 'meraki' ),
            'options'  => array(
                'on_adsense' => 'Enable AdSense',
                'on'         => 'Enable Banner Ad',
                'off'        => 'Disable Ad'
            ),
            'default'  => 'off'
        ),
        array(
            'id' => 'mt_adplace_ico_list_link',
            'type' => 'text',
            'title' => esc_html__('AdPlace URL', 'meraki'),
            'subtitle' => esc_html__('Type your AdPlace Jobs List URL.', 'meraki'),
            'required' => array( 'mt_adplace_ico_list', '=', 'on' ),
            'desc' => esc_html__('For example: "https://modeltheme.com"', 'meraki'),
            'default' => 'https://'
        ),
    
        array(
            'id' => 'mt_adplace_ico_list_img_1_2',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Choose image for AdPlace Jobs List 2 Jobss / Row', 'meraki'),
            'subtitle' => esc_html__('Upload Image (1/2) - When the grid shows 2 Jobss / Row', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_ico_list', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_ico_list_img_1_3',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Choose image for AdPlace Jobs List 3 Jobss / Row', 'meraki'),
            'subtitle' => esc_html__('Upload Image (1/3) - When the grid shows 3 Jobss / Row', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_ico_list', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_ico_list_img_1_4',
            'type' => 'media',
            'url' => true,
            'title' => esc_html__('Choose image for AdPlace Jobs List 4 Jobss / Row', 'meraki'),
            'subtitle' => esc_html__('Upload Image (1/4) - When the grid shows 4 Jobss / Row', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_ico_list', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_ico_list_img_slider',
            'type' => 'media',
            'title' => esc_html__('Choose image for AdPlace Jobs List Slider', 'meraki'),
            'subtitle' => esc_html__('Upload Image When the grid shows 4 Jobs / Row', 'meraki'),
            'compiler' => 'true',
            'required' => array( 'mt_adplace_ico_list', '=', 'on' )
        ),
        array(
            'id' => 'mt_adplace_ico_list_adsense_code',
            'type' => 'textarea',
            'title' => esc_html__('AdSense code', 'meraki'),
            'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'meraki'),
            'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'meraki'),
            'required' => array( 'mt_adplace_ico_list', '=', 'on_adsense' ),
            'default' => ''
        ),
    ),
);