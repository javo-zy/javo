<?php
/**
 * The template for displaying archive pages.
 *
 */
get_header(); 
?>
    <!-- Page content -->
    <div class="high-padding">
        <!-- Blog content -->
        <div class="container">
            <div class="row">
                <div class="col-md-4">
        
                     <div class="mt_listing_content_sidebar_part_author_listing">
                            <?php $author = get_user_by( 'slug', get_query_var( 'author_name' ) ); ?>
                              <div class="mt_listing_content_sidebar_part_author_listing_inner">
                                
                                <a class="author_listing_avatar" href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )); ?>">
                                  <?php echo get_avatar( $author->ID, 350); ?>
                                </a>
                              </div>

                              <?php $phone = get_user_meta(get_the_author_meta( 'ID' ),'billing_phone',true);  ?>
                              <?php $email = get_user_meta(get_the_author_meta( 'ID' ),'billing_email',true);  ?>
                              <?php $mt_user_facebook = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_facebook',true);  ?>
                              <?php $mt_user_instagram = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_instagram',true);  ?>
                              <?php $mt_user_youtube = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_youtube',true);  ?>
                              <?php $mt_listing_company_name = get_user_meta(get_the_author_meta( 'ID' ),'mt_user_youtube',true);  ?>
                              


                              <?php if($phone || $email) { ?>

                                <div class="mt_listing_content_sidebar_bottompart_author_listing_inner">
                                  <h4 class="mt_listing_content_heading">
                                    <h3><?php echo esc_html($author->display_name); ?></h3>  
                                  </h4>
                                  <ul class="listing-details-author-info">
                                    <li><i class="fa fa-phone" aria-hidden="true"></i> <?php echo esc_html($phone); ?></li>
                                    <li><i class="fa fa-envelope"></i><a href="mailto:<?php echo esc_url($email); ?>"><?php echo esc_html($email); ?></a></li>
                                  </ul>
                                </div>
                              <?php } ?>


                    </div>
                    <div class="mt_listing_content_sidebar_part_contact_info">
                    <?php if(function_exists('modeltheme_framework')){ ?>
                        <!-- MAP LOCATION -->
                        <div class="mt_listings_page mt_listing_map_location">
                        <?php 

                            $gmap_pin = '';

                            $api_key = '';
                            $api_key = meraki_redux('mt_listings_api_key');
                        // Start Map
                        $gmap_pin .= '[sbvcgmap map_width="100" map_height="340" zoom="12" scrollwheel="no" pancontrol="no" scalecontrol="no" scalecontrol="no" streetviewcontrol="no" zoomcontrol="yes"  maptypecontrol="no" overviewmapcontrol="no" searchradius="500"  scrollwheel="no sbvcgmap_title="Google Maps" mapstyles="style-55"   sbvcgmap_apikey="'.$api_key.'"]';

                            while ( have_posts() ) : the_post();

                                $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'meraki_listing_archive_thumbnail' );
                      
                                if ($thumbnail_src) {
                                    $listing_img_pin = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.get_the_title().'" />';
                                } else {
                                    $listing_img_pin = '';
                                }

                                $mt_listing_location_address = get_post_meta( get_the_ID(), 'mt_listing_location_address', true );
                                $mt_listing_location_address_pin = '';
                                if($mt_listing_location_address) { 
                                    $mt_listing_location_address_pin = $mt_listing_location_address;
                                } 

                                // Get the current category ID, e.g. if we're on a category archive page
                                $categories = wp_get_post_terms(get_the_ID(), 'mt-listing-category2', array("fields" => "all"));
                                foreach($categories as $category) {
                                    if ($category) {
                                        $image_id = get_term_meta ( $category->term_id, 'category-image-id-v3', true );
                                        $mt_map_coordinates = get_post_meta( get_the_ID(), 'mt_map_coordinates', true );
                                        if (isset($mt_map_coordinates) && !empty($mt_map_coordinates)) {
                                            if (isset($image_id) && !empty($image_id)) {
                                                $gmap_pin .= '[sbvcgmap_marker animation="DROP" address="'.esc_attr($mt_map_coordinates).'" icon="'.esc_attr($image_id).'"]'.$listing_img_pin.'<a href="'.get_the_permalink().'">'.get_the_title().'</a><p>'.$mt_listing_location_address_pin.'</p>[/sbvcgmap_marker]';
                                            }
                                        }
                                    }
                                }
                            endwhile;
                        // End Map
                        $gmap_pin .= '[/sbvcgmap]';
                        echo do_shortcode($gmap_pin);
                    ?>
                </div>
            <?php } ?>
            <div class="mt_listing_content_sidebar_part_contact_info_details">
              <?php $locations = wp_get_post_terms( get_the_ID() , 'mt-listing-category', array("fields" => "all")); ?>

              <?php foreach ($locations as $location) { ?>
                <h3 class="mt_listing_content_heading""><?php echo esc_html($location->name); ?></h3>
              <?php } ?>

              <?php $mt_listing_location_address = get_post_meta( get_the_ID(), 'mt_listing_location_address', true ); ?>
              <?php $mt_listing_phone_number = get_post_meta( get_the_ID(), 'mt_listing_phone_number', true ); ?>
              <?php $mt_listing_mail_address = get_post_meta( get_the_ID(), 'mt_listing_mail_address', true ); ?>
              <?php $mt_listing_website_listing = get_post_meta( get_the_ID(), 'mt_listing_website_listing', true ); ?>

              <?php if($mt_listing_location_address) { ?>
                <p><?php echo esc_html($mt_listing_location_address); ?></p>
              <?php } ?>

              <?php if(empty($mt_listing_phone_number) || empty($mt_listing_mail_address) || empty($mt_listing_website_listing)) { ?>
                <div class="alert alert-success">
                    <strong><?php esc_html_e('This Listing has no contact details! ', 'meraki') ?></strong>
                    <?php esc_html_e(' Please add contact details to this specify listing.', 'meraki'); ?>
                </div>
              <?php } ?>

            </div>

          </div>
                </div>
                <?php if(!empty($author->description)) { ?>
                <div class="col-md-8 about-author">
                    <h3><?php esc_html_e('About ','meraki') ?><?php echo esc_html($author->display_name); ?></h3>
                    <p><?php echo esc_html($author->description); ?></p>
                </div>
            <?php } ?>
                <div class="col-md-8 author-listings">
                    <h3><?php esc_html_e('Jobs','meraki') ?></h3>
                    <?php if ( have_posts() ) : ?>
                        <div class="listings-dashboard">
                            <?php /* Start the Loop */ ?>
                            <?php while ( have_posts() ) : the_post(); 
                                $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),'meraki_dashboard_listing' );                       
                                if ($thumbnail_src) {
                                    $listing_img = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.esc_attr(the_title_attribute( 'echo=0' )).'" />';
                                } else {
                                    $listing_img = '';
                                } ?>
                                <?php $mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); ?>
                                <?php $mt_listing_salary = get_post_meta( get_the_ID(), 'mt_listing_salary', true ); ?> 
                                <?php $mt_listing_sponsored_status_clss = ''; ?>
                                <?php if($mt_listing_sponsored_status == 'sponsored_listing') { ?>
                                    <?php $mt_listing_sponsored_status_clss = 'is_sponsored'; ?>
                                <?php } ?>
                                <div id="listing-<?php the_ID(); ?>" class="<?php echo esc_attr($mt_listing_sponsored_status_clss); ?> dashboard-single-listing"> 
                                    
                                    <div class="row">
                                    
                                        <div class="col-md-5 col-xs-5 single_list_info">
                                            <div class="thumbnail-name">
                                                <h4 class="listing-name">
                                                  <a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" title="<?php echo esc_attr(the_title_attribute( 'echo=0' )); ?>"><?php echo get_the_title(); ?></a>
                                                </h4>
                                                
                                            </div>
                                            <div class="subtitle-section">
                                                <div class="row">
                                                    <?php if ($mt_listing_salary){ ?>
                                                        <div class="categories-name"><i class="fa fa-money"></i><?php echo esc_attr($mt_listing_salary) ?></div>
                                                     <?php } ?> 
                                                </div>
                                            </div>                     
                                        </div>
                                        <div class="col-md-5 col-xs-7 single_list_buttons">
                                            <div class="row">
                                                <div class="list_category">
                                                    <span class="status-listing status-<?php echo get_post_status(get_the_ID()); ?>">
                                                        
                                                        <?php if(get_post_status(get_the_ID()) == 'publish' ) {
                                                            echo esc_html__('active','meraki');
                                                        } elseif(get_post_status(get_the_ID()) == 'draft' || get_post_status(get_the_ID()) == 'pending' ) {
                                                            echo esc_html__('pending','meraki');
                                                        }
                                                        ?>
                                                            
                                                    </span>
                                                </div>
                                                <?php 
                    
                                                    $terms = get_the_term_list( $post->ID, 'mt-listing-type' );
                                                    $terms = strip_tags( $terms );
                                                    if (get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', ')){ ?>
                                                    <div class="list_category" id="<?php echo esc_html($terms ); ?>">
                                                         <span><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', '); ?></span>
                                                    </div>
                                                  <?php } ?>
                                            
                                        </div>
                                    </div>
                                        <div class="col-md-2">
                                            <div class="listing-actions">
                                                <?php $page_ad_listing_url = '#';
                                                $page_ad_listing = get_page_by_title( 'Listing' ); ?>
                                                <a class="btn-view" href="<?php echo esc_url(the_permalink()); ?>"><?php echo esc_html__(' View','meraki'); ?></a>                                              
                                            </div>
                                        </div>
                                    
                                    </div>
                                </div>
                            <?php endwhile; ?>
                            <div class="modeltheme-pagination-holder col-md-12">             
                                <div class="modeltheme-pagination pagination">             
                                    <?php the_posts_pagination(); ?>
                                </div>
                            </div>
                            
                        </div>
                    <?php else : ?>
                        <?php wp_reset_query(); ?>
                    <?php endif; ?>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
<?php get_footer(); ?>