<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php 
	global $current_user;
	wp_get_current_user();
	$wordpress_loop_argument_listings = array('post_type' => 'mt_listing', 'author' => $current_user->ID, 'posts_per_page' => -1);
	$wordpress_loop_listings = new WP_Query( $wordpress_loop_argument_listings );
	if($wordpress_loop_listings->have_posts() ) {
		$wordpress_loop_argument = array(
		  'post_type'      => 'mt_application',
		  'author'         =>  $current_user->ID,
		  'posts_per_page' => -1,
		  'orderby'        => 'date',
		  'order'          => 'ASC'
		);
		$wordpress_loop = new WP_Query( $wordpress_loop_argument );
		if( $wordpress_loop->have_posts() ) { ?>
			
		<div class="listings-dashboard listings-dashboard-template">
		<?php $applications_query_arg = array('post_type' => 'mt_application', 
		'author' => -$current_user->ID,
		'posts_per_page' => 3);
			$applications_query = new WP_Query( $applications_query_arg );
			$mt_application_date = get_post_meta( get_the_ID(), 'mt_application_date', true ); ?>	
			<?php $mt_application_location = get_post_meta( get_the_ID(), 'mt_application_location', true );

	if( $applications_query->have_posts() ) { ?>
		<div class="applications-dashboard">
			<h1 class="title-my-account"><?php echo esc_html__('Received applications','meraki'); ?> (<?php echo wp_kses_post($applications_query->post_count); ?>)</h1>
			<?php while ( $applications_query->have_posts() ) : $applications_query->the_post(); ?>
			<?php $mt_application_listing = get_post_meta( get_the_ID(), 'mt_application_listing', true ); ?>
			<?php $mt_applicant_phone = get_post_meta( get_the_ID(), 'mt_applicant_phone', true ); ?>
			<?php $mt_applicant_email = get_post_meta( get_the_ID(), 'mt_applicant_email', true ); ?>
			<?php $mt_applicant_attach = get_post_meta( get_the_ID(), 'mt_applicant_attach', true ); ?>
			<div id="application-<?php the_ID(); ?>" class="dashboard-single-listing"> 
				
				<div class="row">
					
						<div class="col-md-3">
							<div class="thumbnail-name">
								
								<h4 class="listing-name">
						          <a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" title="<?php echo esc_attr(the_title_attribute( 'echo=0' )); ?>"><?php echo get_the_title(); ?></a>
						          <span class="listing-date"><a href="mailto:<?php echo esc_html($mt_applicant_email) ?>"><?php echo esc_html($mt_applicant_email) ?></a></span>
						        </h4>

					        </div>				        
				        </div>
				        <div class="col-md-3">
				        	<div class="listing-job">
				        		<span class="status-title"><?php echo esc_html__('Job: ','meraki'); ?></span>

				        		<span><a href="<?php echo esc_url(get_the_permalink($mt_application_listing)) ?>"><?php echo get_the_title($mt_application_listing); ?></a></span>
				        	</div>
				        </div>
				        <div class="col-md-3">
				        	<div class="listing-status">
				        		<span class="status-title"><?php echo esc_html__('Phone Number: ','meraki'); ?></span>	        		
				        		<span class="listing-date"><a href="tel:<?php echo esc_html($mt_applicant_phone) ?>"><?php echo esc_html($mt_applicant_phone) ?></a></span>

				        	</div>
				        </div>
				        <div class="col-md-3">
                   			 <div class="listing-actions">
                   			 	<?php if (!empty($mt_applicant_attach)) { ?>
                          		<a class="button-winona btn btn-sm" href="<?php echo esc_html($mt_applicant_attach); ?>"><?php echo esc_html__('Check CV','meraki'); ?></a>            
                    		 
                    		<?php } else { ?>
                    		
                          		<a class="button-winona btn btn-sm" href="#"><?php echo esc_html__('Check CV','meraki'); ?></a>          
                    		
                    		<?php } ?>
                    		 </div>
                 		</div>
				    </div>
			</div>

			<?php endwhile;
			wp_reset_query(); ?>

		</div>
	<?php } ?>
				</div>
	<?php } else { ?>
		<div class="alert alert-warning">
		  <strong><?php echo esc_html__('There are no applicants here','meraki') ?></strong>
		</div>
	<?php }
} else { ?>
	<div class="alert alert-warning">
		<strong><?php echo esc_html__('Please submit a job first','meraki') ?></strong>
	</div>
<?php }