<?php
//GET HEADER TITLE/BREADCRUMBS AREA
function meraki_delete_post($postid, $devmode){

    $html = '';


    if (isset($_GET['delete']) && isset($_GET['postid']) && $_GET['delete'] == 'yes') {
        $postid = $_GET['postid'];
        $postUserId = get_post_field( 'post_author', $postid );
        $loggedInUser = get_current_user_id();

        // Prevent other users from deleting other listings
        // Only Listing Author can remove it (from frontend)
        // Security check #1
        if ($postUserId == $loggedInUser) {
            //Prevent users to remove other post or pages than mt_listings
            //Security check #2
            if (get_post_type( $postid ) == 'mt_listing' || get_post_type( $postid ) == 'mt_application' ) {

                $postTypeLabel = esc_html__('Job', 'meraki');
                if (get_post_type( $postid ) == 'mt_listing') {
                    $postTypeLabel = esc_html__('job', 'meraki');
                }elseif (get_post_type( $postid ) == 'mt_application') {
                    $postTypeLabel = esc_html__('Applications', 'meraki');
                }

                if ($devmode == true) {
                    $html .= '<div class="alert alert-warning alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>'.esc_html__('Warning!', 'meraki').'</strong> '.esc_html__('Developer Mode Enabled. Selected ', 'meraki').$postTypeLabel.esc_html__(' will not be disabled. In order to enable it, please go to Theme Panel -> MT Listings Settings -> Developer Mode Status -> Off', 'meraki').'
                              </div>';
                }else{
                    wp_trash_post($postid);
                    $html .= '<div class="alert alert-success alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>'.esc_html__('Success!', 'meraki').'</strong> '.esc_html__('Selected ', 'meraki').$postTypeLabel.esc_html__(' is now Disabled.', 'meraki').'
                              </div>';
                }
            }else{
                $html .= '<div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>'.esc_html__('Error!', 'meraki').'</strong> '.esc_html__('You are not allowed to do this action.', 'meraki').'
                          </div>';
            }
        }else{
            $html .= '<div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>'.esc_html__('Error!', 'meraki').'</strong> '.esc_html__('You are not allowed to do this action.', 'meraki').'
                      </div>';
        }
    }


    return $html;
}