<?php
//GET HEADER TITLE/BREADCRUMBS AREA
function meraki_header_title_breadcrumbs(){

    $html = '';
    $html .= '<div class="header-title-breadcrumb relative">';
        $html .= '<div class="header-title-breadcrumb-overlay text-center">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12 text-center">';
                                    if (is_singular('post')) {
                                        $html .= '<h1>'.esc_html__( 'Blog', 'meraki' ) . get_search_query().'</h1>';
                                    }elseif (class_exists( 'WooCommerce' ) && is_shop()) {
                                        $html .= '<h1>'.esc_html__( 'Shop', 'meraki' ).'</h1>';
                                    }elseif (is_page()) {
                                        $html .= '<h1>'.get_the_title().'</h1>';
                                    }elseif (is_search()) {
                                        $html .= '<h1>'.esc_html__( 'Search Results for: ', 'meraki' ) . get_search_query().'</h1>';
                                    }elseif (is_category()) {
                                        $html .= '<h1>'.esc_html__( 'Category: ', 'meraki' ).' <span>'.single_cat_title( '', false ).'</span></h1>';
                                    }elseif (is_tag()) {
                                        $html .= '<h1>'.esc_html__( 'Tag Archives: ', 'meraki' ) . single_tag_title( '', false ).'</h1>';
                                    }elseif (is_author() || is_archive()) {
                                        $html .= '<h1>'.get_the_archive_title().'</h1>';
                                    }elseif (is_home()) {
                                        $html .= '<h1>'.esc_html__( 'From the Blog', 'meraki' ).'</h1>';
                                    }else {
                                        $html .= '<h1>'.get_the_title().'</h1>';
                                    }
                            $html .= '<ol class="breadcrumb text-center">'.meraki_breadcrumb().'</ol>                    
                                </div>
                            </div>
                        </div>
                    </div>';

    $html .= '</div>';
    $html .= '<div class="clearfix"></div>';

    return $html;
}



//GET Social Floating button
if (!function_exists('meraki_floating_social_button')) {
    function meraki_floating_social_button(){

        $html = '';
        $link = '';
        $fa_class = '';

        if (meraki_redux('mt_fixed_social_btn_status') == true) {
            if (meraki_redux('mt_fixed_social_btn_social_select') == 'telegram') {
                $link = meraki_redux('mt_social_telegram');
                $fa_class = 'fa fa-telegram';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'facebook') {
                $link = meraki_redux('mt_social_fb');
                $fa_class = 'fa fa-facebook';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'twitter') {
                $link = meraki_redux('mt_social_tw');
                $fa_class = 'fa fa-twitter';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'googleplus') {
                $link = meraki_redux('mt_social_gplus');
                $fa_class = 'fa fa-google-plus';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'youtube') {
                $link = meraki_redux('mt_social_youtube');
                $fa_class = 'fa fa-youtube-play';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'pinterest') {
                $link = meraki_redux('mt_social_pinterest');
                $fa_class = 'fa fa-pinterest-p';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'pinterest') {
                $link = meraki_redux('mt_social_pinterest');
                $fa_class = 'fa fa-pinterest-p';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'linkedin') {
                $link = meraki_redux('mt_social_linkedin');
                $fa_class = 'fa fa-linkedin';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'skype') {
                $link = meraki_redux('mt_social_skype');
                $fa_class = 'fa fa-skype';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'instagram') {
                $link = meraki_redux('mt_social_instagram');
                $fa_class = 'fa fa-instagram';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'dribbble') {
                $link = meraki_redux('mt_social_dribbble');
                $fa_class = 'fa fa-dribbble';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'deviantart') {
                $link = meraki_redux('mt_social_deviantart');
                $fa_class = 'fa fa-deviantart';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'digg') {
                $link = meraki_redux('mt_social_digg');
                $fa_class = 'fa fa-digg';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'flickr') {
                $link = meraki_redux('mt_social_flickr');
                $fa_class = 'fa fa-flickr';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'stumbleupon') {
                $link = meraki_redux('mt_social_stumbleupon');
                $fa_class = 'fa fa-stumbleupon';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'tumblr') {
                $link = meraki_redux('mt_social_tumblr');
                $fa_class = 'fa fa-tumblr';
            }elseif (meraki_redux('mt_fixed_social_btn_social_select') == 'vimeo') {
                $link = meraki_redux('mt_social_vimeo');
                $fa_class = 'fa fa-vimeo';
            }


            $html .= '<a data-toggle="tooltip" data-placement="top" title="'.esc_attr__('Connect on Telegram','meraki').'" class="floating-social-btn" target="_blank" href="'.esc_url($link).'">';
                $html .= '<i class="'.esc_attr($fa_class).'"></i>';
            $html .= '</a>';
        }

        return $html;
    }
}



