<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $current_user;
wp_get_current_user(); 
$listings_loop_argument = array('post_type' => 'mt_listing', 'author' => $current_user->ID, 'posts_per_page' => -1);
$listings_loop = new WP_Query( $listings_loop_argument );
$applications_loop_argument = array('post_type' => 'mt_application', 'author' => $current_user->ID, 'posts_per_page' => -1);
$applications_loop = new WP_Query( $applications_loop_argument );
?>

<?php 
	// Check if $_GET isset
    if ( class_exists( 'ReduxFrameworkPlugin' )  && function_exists('mtlisitings_framework')) {
	    if (isset($_GET['postid'])) {
	    	// disable the post.
	    	// this sends the post to trash.
			echo meraki_delete_post($_GET['postid'], $devmode = meraki_redux('mt_listings_devmode'));
		}
    }
?>


<div class="my-account-dashboard">
	<div class="statistics-dashboard">
		<h1 class="title-my-account"><?php echo esc_html__('Dashboard','meraki'); ?></h1>
		<div class="row">

			<div class="col-md-6 count-statistics count-listings">
				<div class="count-statistics-inner">	
					<?php if($listings_loop->post_count > 0) { ?>								
						<h3 class="statistics-count-number"><?php echo wp_kses_post($listings_loop->post_count); ?></h3>
					<?php }  else { ?>
						<h3 class="statistics-count-number"><?php echo esc_html__('0','meraki'); ?></h3>
					<?php } ?>	
					<h4 class="statistics-title"><?php echo esc_html__('Jobs','meraki'); ?></h4>
				</div>
			</div>	

			<div class="col-md-6 count-statistics count-applications">
				<div class="count-statistics-inner">	
					<?php if($applications_loop->post_count > 0) { ?>								
						<h3 class="statistics-count-number"><?php echo wp_kses_post($applications_loop->post_count); ?></h3>
					<?php }  else { ?>
						<h3 class="statistics-count-number"><?php echo esc_html__('0','meraki'); ?></h3>
					<?php } ?>	
					<h4 class="statistics-title"><?php echo esc_html__('Sent Applications','meraki'); ?></h4>
				</div>
			</div>		



		</div>
	</div>
	<?php $listings_query_arg = array('post_type' => 'mt_listing', 
		'author' => $current_user->ID,
		'posts_per_page' => 3,
		'post_status' => array('publish', 'draft', 'pending'));
	$listings_query = new WP_Query( $listings_query_arg );
	if( $listings_query->have_posts() ) { ?>
		<div class="listings-dashboard">
			<h1 class="title-my-account"><?php echo esc_html__('My Jobs','meraki'); ?> (<?php echo wp_kses_post($listings_loop->post_count); ?>)</h1>
			<?php while ( $listings_query->have_posts() ) : $listings_query->the_post(); 
		 	$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),'meraki_dashboard_listing' );			              
			if ($thumbnail_src) {
			    $listing_img = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.esc_attr(the_title_attribute( 'echo=0' )).'" />';
			} else {
			    $listing_img = '';
			} ?>

			<?php $mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); ?>	
			<?php $mt_listing_sponsored_status_clss = ''; ?>
			<?php $mt_listing_salary = get_post_meta( get_the_ID(), 'mt_listing_salary', true ); ?>
			<?php $mt_listing_category = get_post_meta( get_the_ID(), 'mt_listing_category', true ); ?>
			<?php $mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); 
                      $mt_listing_sponsored_status_clss = '';
                      if($mt_listing_sponsored_status == 'sponsored_listing') { 
                          $mt_listing_sponsored_status_clss = 'is_sponsored';
                      }  ?>
			<?php if($mt_listing_sponsored_status == 'sponsored_listing') { ?>
			    <?php $mt_listing_sponsored_status_clss = 'is_sponsored'; ?>
			<?php } ?>


			<div id="listing-<?php the_ID(); ?>" class="<?php echo esc_attr($mt_listing_sponsored_status_clss); ?> dashboard-single-listing"> 
                                    
                                    <div class="row">
                                    
                                        <div class="single_job_info col-md-5 col-xs-6">
                                            <div class="thumbnail-name">
                                                <h4 class="listing-name">
                                                  <a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" title="<?php echo esc_attr(the_title_attribute( 'echo=0' )); ?>"><?php echo get_the_title(); ?></a>

                                                </h4>
                                                
                                            </div>
                                            <div class="subtitle-section">
		        									<div class="row">
				        								<div class="categories-name"><i class="fa fa-map-marker"></i><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-category', '', ', '); ?></div>
                										<?php if ($mt_listing_salary){ ?>
				        								<div class="categories-name"><i class="fa fa-money"></i><?php echo esc_attr($mt_listing_salary) ?></div>
              											<?php } ?>
				    									</div>
			   										 </div>
                                                
                                                                
                                        </div>
                                        <div class="single_dashboard_buttons col-md-4">
                                            <div class="row">

                                                <div class="list_category">
                                                    <span class="status-listing status-<?php echo get_post_status(get_the_ID()); ?>">
                                                        
                                                        <?php if(get_post_status(get_the_ID()) == 'publish' ) {
                                                            echo esc_html__('active','meraki');
                                                        } elseif(get_post_status(get_the_ID()) == 'draft' || get_post_status(get_the_ID()) == 'pending' ) {
                                                            echo esc_html__('disabled','meraki');
                                                        }
                                                        ?>
                                                            
                                                    </span>
                                                </div>
                                                <?php 
                    
                                                    $terms = get_the_term_list( $post->ID, 'mt-listing-type' );
                                                    $terms = strip_tags( $terms );
                                                    if (get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', ')){ ?>
                                                    <div class="list_category" id="<?php echo esc_html($terms ); ?>">
                                                         <span><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', '); ?></span>
                                                    </div>
                                                  <?php } ?>
                                            	
                                       		 </div>
                                    		</div>
                                         <div class="single_job_edit col-md-3 col-xs-6">
												        	<div class="listing-actions">
												        		<?php $page_ad_listing_url = '#';
													    		$page_ad_listing = get_page_by_title( 'Listing' );
															    if(!empty($page_ad_listing)) {
															    	if ( get_post_status ( $page_ad_listing->ID ) != 'trash' ) {
															    		$page_ad_listing_url = get_site_url() . '/listing/?listing_id=' . get_the_ID();
															    	}
															    } ?>
												        		<a class="btn-edit" href="<?php echo esc_url($page_ad_listing_url); ?>"><span class="lnr lnr-cog"></span> <?php echo esc_html__('Edit','meraki'); ?></a>
												        		<a class="btn-delete" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>dashboard_acc/?delete=yes&postid=<?php echo esc_attr(get_the_ID()); ?>"><span class="lnr lnr-cross-circle"></span> <?php echo esc_html__('Delete','meraki'); ?></a>
												        		
												        	</div>
												        </div>
                                    
                                    </div>
                                </div>



			
			<?php endwhile;
			wp_reset_query();
			?>
			<a class="button-view-more-listings" href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id')).'listings'); ?>">
				<?php esc_html__('View more Jobs','meraki'); ?>
			</a>
		</div>
	<?php } ?>


		<?php $applications_query_arg = array('post_type' => 'mt_application', 
		'author' => $current_user->ID,
		'posts_per_page' => 3);
	$applications_query = new WP_Query( $applications_query_arg );


			$mt_application_location = get_post_meta( get_the_ID(), 'mt_application_location', true ); 

	if( $applications_query->have_posts() ) { ?>
		<div class="listings-dashboard">
			<h1 class="title-my-account"><?php echo esc_html__('My submited applications','meraki'); ?> (<?php echo wp_kses_post($applications_query->post_count); ?>)</h1>
			<?php while ( $applications_query->have_posts() ) : $applications_query->the_post(); ?>
			<?php $mt_application_listing = get_post_meta( get_the_ID(), 'mt_application_listing', true ); ?>
			<?php $mt_applicant_phone = get_post_meta( get_the_ID(), 'mt_applicant_phone', true ); ?>
			<?php $mt_applicant_email = get_post_meta( get_the_ID(), 'mt_applicant_email', true ); ?>
			<?php $mt_applicant_attach = get_post_meta( get_the_ID(), 'mt_applicant_attach', true ); ?>
			<div id="application-<?php the_ID(); ?>" class="dashboard-single-listing"> 
				
				<div class="row">
					
						<div class="col-md-3">
							<div class="thumbnail-name">
								
								<h4 class="listing-name">
						          <a href="<?php echo esc_url(get_permalink(get_the_ID())); ?>" title="<?php echo esc_attr(the_title_attribute( 'echo=0' )); ?>"><?php echo get_the_title(); ?></a>
						          <span class="listing-date"><a href="mailto:<?php echo esc_attr($mt_applicant_email) ?>"><?php echo esc_html($mt_applicant_email) ?></a></span>
						        </h4>

					        </div>				        
				        </div>
				        <div class="col-md-3">
				        	<div class="listing-job">
				        		<span class="status-title"><?php echo esc_html__('Job: ','meraki'); ?></span>

				        		<span><a href="<?php echo esc_url(get_the_permalink($mt_application_listing)) ?>"><?php echo get_the_title($mt_application_listing); ?></a></span>
				        	</div>
				        </div>
				        <div class="col-md-3">
				        	<div class="listing-status">
				        		<span class="status-title"><?php echo esc_html__('Phone Number: ','meraki'); ?></span>	        		
				        		<span class="listing-date"><a href="tel:<?php echo esc_html($mt_applicant_phone) ?>"><?php echo esc_html($mt_applicant_phone) ?></a></span>

				        	</div>
				        </div>
				        <div class="col-md-3">
                   			 <div class="listing-actions">
                          		<a class="button-winona btn btn-sm" href="<?php echo esc_html($mt_applicant_attach); ?>"><?php echo esc_html__('Check CV','meraki'); ?></a>          
                    		 </div>
                 		</div>
				    </div>
			</div>

			<?php endwhile;
			wp_reset_query(); ?>

		</div>
	<?php } ?>

	
	

</div>
