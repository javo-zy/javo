<?php 
/**
* Template for Listings
* Used in: search.php
**/


$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ) );
$mt_listing_salary = get_post_meta( get_the_ID(), 'mt_listing_salary', true );
$mt_listing_category = get_post_meta( get_the_ID(), 'mt_listing_category', true );
$mt_listing_company_img = get_post_meta(  get_the_ID(), 'mt_listing_company_img', true );
$mt_listing_sponsored_status = get_post_meta( get_the_ID(), 'mt_listing_sponsored_status', true ); 
                      $mt_listing_sponsored_status_clss = '';
                      if($mt_listing_sponsored_status == 'sponsored_listing') { 
                          $mt_listing_sponsored_status_clss = 'is_sponsored';
                      }            

if (empty($mt_listing_company_img)) {
                      $listing_img = '<img class="listing_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.get_the_title().'" />';
                  } else  {
                      $listing_img = '<img class="listing_post_image" src="'. esc_url($mt_listing_company_img) . '" alt="'.get_the_title().'" />';
                  }
$listing_term_style = get_term_meta( get_queried_object_id(), 'listing_term_style', true );
$term_column_single_listing = '';
if(empty($listing_term_style) || $listing_term_style == 'style1') {
    $term_column_single_listing = 'col-md-12';
} elseif($listing_term_style == 'style2') {
    $term_column_single_listing = 'col-md-4';
}

?>

<div class="<?php echo esc_attr($term_column_single_listing); ?> single-listing list-view listing-taxonomy-shortcode">
    <div class="listings_custom">
      

      <div class=" col-md-2 <?php echo esc_attr($mt_listing_sponsored_status_clss); ?>">
       <div class="blog_custom_listings thumbnail-name">
          <div class="listing-thumbnail">
              <a class="relative" href="<?php echo get_permalink(get_the_ID()); ?>">
              <img class="listing_post_image" src="<?php echo esc_url($thumbnail_src[0]); ?>"></a>
          </div>
     </div>
   </div>

      <div class="title-n-categories <?php echo esc_attr($mt_listing_sponsored_status_clss); ?> col-md-10">
        <div class="row">

          <div class="col-md-5">
            <h4 class="post-name">
              <a href="<?php echo get_permalink(get_the_ID()); ?>" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a>
            </h4>
            <div class="subtitle-section">
              <div class="row">
                <div class="categories-name"><i class="fa fa-map-marker"></i><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-category', '', ', '); ?></div>
                <?php if ($mt_listing_salary){ ?>
                <div class="categories-name"><i class="fa fa-money"></i><?php echo esc_attr($mt_listing_salary) ?></div>
              <?php } ?>
            </div>
          </div>
        </div>

        <div class="col-md-4">
              <div class="single_list_buttons">
                  <div class="row">
                    <div class="list_category">
                         <span><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-category2', '', ', '); ?></span>
                    </div>


                    <?php  
                    $terms = get_the_term_list( $post->ID, 'mt-listing-type' );
                    $terms = strip_tags( $terms );
                    if (get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', ')){ ?>
                    <div class="list_category" id="<?php echo esc_attr( $terms ); ?>">
                         <span><?php  echo get_the_term_list( get_the_ID(), 'mt-listing-type', '', ', '); ?></span>
                    </div>

                    <?php if($mt_listing_sponsored_status == 'sponsored_listing') {  ?>
                      <div class="listing_sponsored_bolt">
                        <span class="listing_sponsored_status" title="Sponsored Listing"><i class="fa fa-bolt" aria-hidden="true"></i></span>
                      </div>    
                    <?php } ?>
                  <?php } ?>
                  </div>
              </div>
         </div>

                 <div class="col-md-3">
                    <div class="listing-actions">
                          <a class="button-winona btn btn-sm" href="<?php echo get_permalink(get_the_ID()); ?>"> Apply Now</a>          
                    </div>
                 </div>

        </div>
      </div>

    </div>
</div>
